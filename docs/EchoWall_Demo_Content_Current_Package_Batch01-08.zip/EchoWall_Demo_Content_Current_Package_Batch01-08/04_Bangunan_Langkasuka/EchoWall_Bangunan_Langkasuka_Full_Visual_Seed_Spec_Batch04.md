# EchoWall 演示便贴视觉配置完整版

## 批次 04：Bangunan Langkasuka

> 状态：42条内容、照片槽位、形状、颜色与旋转已完成；尚未导入网站。

## 1. 总体判断

- 任务类型：`DOC + DATA`
- 风险等级：`L2`
- 变更规模：`S1`（本阶段仅完善文档）
- 准备状态：`READY`
- 执行模式：`DIRECT`

## 2. 地点与代码映射

- 建筑名称：**Bangunan Langkasuka**
- `placeId`：`B_LANGKASUKA`
- `wallKey`：`building:B_LANGKASUKA`
- 大建筑归档：课程、实验室、系办公室与讲师办公室内容统一归入本建筑墙，不另建小区域留言墙。

## 3. 来源边界

- 学生指南可确认：Bangunan Langkasuka用于上课或考试，靠近图书馆、Dataran与A1/A2区域。
- 网站建筑注册表补充：该建筑包含附加讲堂、实验室、系办公室与讲师办公室，记录为3层。
- 当前来源不可靠地确认固定开放时间，因此便贴不写死营业或开放时段。
- 具体课程、房间、实验、考试和办公室安排必须以正式课表、现场门牌及学校通知为准。
- 所有姓名、账号及留言均为虚构演示数据，不代表42条真实学生证言。

## 4. 数据摘要

- 便贴：42条
- 具名：23条；匿名：19条
- BM：24条；English：13条；中文：5条
- 带照片：9条（21.4%）
- 使用全部10种现有形状和全部10个现有颜色预设

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：5条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：3条
- `torn`（撕边）：3条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：6条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：5条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：5条
- `#FFF7ED`（Warm cream）：5条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：4条
- `#CFFAFE`（Soft cyan）：4条
- `#FDE68A`（Golden yellow）：3条

## 5. 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `langkasuka-exterior-location-01.webp` | Bangunan Langkasuka外观或从图书馆／Dataran方向看到的建筑定位照；不拍清晰人脸。 | 可参考 school-environment PDF 第5及25页；建议用户自行补拍 | `cover` | 1.12 |
| 8 | `langkasuka-classroom-01.webp` | 空教室、讲堂或整齐桌椅的4:3横向照片，避免出现学生资料。 | 可参考 school-environment PDF 第25页；建议用户自行补拍 | `cover` | 1.10 |
| 13 | `langkasuka-lecture-note-margin-01.webp` | 通用讲义与留有“问题栏”的笔记摆拍，不复制真实课件或姓名。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 17 | `langkasuka-lab-bench-01.webp` | 整洁实验台、通用器材和安全标识局部；不显示危险操作、学生名单或清晰人脸。 | 需拍摄／用户自有；须先确认该区域实际允许拍摄 | `cover` | 1.08 |
| 24 | `langkasuka-consultation-folder-01.webp` | 整理好的问题清单、草稿和文件夹桌面摆拍，不出现真实讲师或学生资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 28 | `langkasuka-office-corridor-01.webp` | 办公室或系办公室外走廊的空景；避开姓名牌、门牌个人姓名和清晰人脸。 | 需拍摄／用户自有；拍摄前确认场地许可 | `cover` | 1.10 |
| 30 | `langkasuka-exam-hall-01.webp` | 空考试／上课空间的整齐桌椅，不显示真实考试题、座位表或学生。 | 可参考 school-environment PDF 第25页；建议用户自行补拍 | `cover` | 1.10 |
| 34 | `langkasuka-exam-checklist-01.webp` | 虚构考试准备清单、文具和普通计算器摆拍；不显示真实时间表或学生卡资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 39 | `langkasuka-clear-corridor-01.webp` | 整洁走廊、楼梯或出口，画面强调通道无障碍；不拍清晰人脸。 | 需拍摄／用户自有 | `cover` | 1.08 |

照片统一要求：4:3横向优先、WebP、单张目标不超过450KB；不得出现清晰人脸、学生名单、真实考试资料、姓名、学号或账号信息。跨设备展示优先使用批准后的Cloudinary HTTPS URL。

## 6. 42条完整视觉字段

| No. | 分区 | 语言 | 显示 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Arrival & Navigation | ms | Naim A.<br>`demo_langkasuka_001` | `campus_life` | `polaroid` | -2° | `#BFDBFE` Soft blue | `langkasuka-exterior-location-01.webp` | `cover` / 1.12 | Bangunan Langkasuka berada berhampiran kawasan perpustakaan dan Dataran. Simpan peta atau titik lokasi sebelum bergerak supaya tidak tersalah blok. |
| 2 | Arrival & Navigation | ms | 匿名<br>`demo_langkasuka_002` | `campus_life` | `rounded` | 1° | `#FEF08A` Soft yellow | 无 | — | Semak nama bangunan pada papan tanda, bukan hanya warna dinding. Beberapa blok di kawasan ini kelihatan hampir sama dari jauh. |
| 3 | Arrival & Navigation | en | Bryan C.<br>`demo_langkasuka_003` | `campus_life` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | Use the building name and room code together. A screenshot of the timetable is more reliable than following a crowd. |
| 4 | Arrival & Navigation | zh | 匿名<br>`demo_langkasuka_004` | `campus_life` | `square` | 2° | `#FBCFE8` Soft pink | 无 | — | 第一次来Langkasuka时先确认建筑名称和课室编号，不要只跟着人群走，因为附近还有其他教学楼。 |
| 5 | Arrival & Navigation | ms | Khairul E.<br>`demo_langkasuka_005` | `campus_life` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Jika perlu bertukar kelas, kenal pasti satu tangga dan satu pintu utama sebagai rujukan. Cara ini mengurangkan masa mencari laluan. |
| 6 | Arrival & Navigation | en | 匿名<br>`demo_langkasuka_006` | `campus_life` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | Stand at the side when checking directions. Corridors become crowded when several classes end at the same time. |
| 7 | Arrival & Navigation | ms | Nureen G.<br>`demo_langkasuka_007` | `campus_life` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Datang lebih awal pada minggu pertama. Waktu tambahan beberapa minit cukup untuk semak tingkat, pintu dan susunan bilik. |
| 8 | Classes & Lecture Rooms | en | Darren H.<br>`demo_langkasuka_008` | `academic` | `polaroid` | 2° | `#CBD5E1` Grey blue | `langkasuka-classroom-01.webp` | `cover` / 1.10 | Download lecture files before class. Mobile coverage or nearby power points should not be treated as guaranteed. |
| 9 | Classes & Lecture Rooms | ms | 匿名<br>`demo_langkasuka_009` | `academic` | `torn` | 0° | `#CFFAFE` Soft cyan | 无 | — | Sebelum kelas bermula, tulis tajuk dan tarikh pada nota. Banyak bahan kuliah akan kelihatan serupa selepas beberapa minggu. |
| 10 | Classes & Lecture Rooms | ms | Lionel J.<br>`demo_langkasuka_010` | `academic` | `rounded` | -1° | `#FDE68A` Golden yellow | 无 | — | Pilih tempat duduk yang jelas melihat skrin dan papan putih. Jangan tunggu kelas bermula baru hendak berpindah-pindah. |
| 11 | Classes & Lecture Rooms | zh | 匿名<br>`demo_langkasuka_011` | `academic` | `square` | 2° | `#BFDBFE` Soft blue | 无 | — | 如果讲师讲得很快，先记关键词和不明白的部分，不需要把每一句话全部抄下来。 |
| 12 | Classes & Lecture Rooms | en | Mohan L.<br>`demo_langkasuka_012` | `academic` | `envelope` | -2° | `#E9D5FF` Soft purple | 无 | — | Keep one margin for questions in your notes. It makes post-class consultation much more focused. |
| 13 | Classes & Lecture Rooms | ms | 匿名<br>`demo_langkasuka_013` | `campus_life` | `rect` | 1° | `#BBF7D0` Soft green | `langkasuka-lecture-note-margin-01.webp` | `contain` / 1.00 | Letakkan telefon dalam mod senyap dan simpan beg di tempat yang tidak menghalang laluan atau kerusi orang lain. |
| 14 | Classes & Lecture Rooms | ms | Aidan N.<br>`demo_langkasuka_014` | `academic` | `speech` | 0° | `#FED7AA` Soft orange | 无 | — | Selepas kelas, tulis satu ayat yang merumuskan idea utama. Jika ayat itu sukar ditulis, tandakan topik untuk disemak semula. |
| 15 | Classes & Lecture Rooms | en | Kamil O.<br>`demo_langkasuka_015` | `campus_life` | `circle` | -1° | `#FFF7ED` Warm cream | 无 | — | Leave the room in an orderly way. Blocking the doorway makes the next class change slower for everyone. |
| 16 | Laboratories & Practical Work | ms | Mikayla P.<br>`demo_langkasuka_016` | `academic` | `polaroid` | 2° | `#CFFAFE` Soft cyan | 无 | — | Untuk sesi amali, baca objektif dan langkah keselamatan sebelum datang. Jangan mula menyentuh peralatan tanpa arahan. |
| 17 | Laboratories & Practical Work | ms | 匿名<br>`demo_langkasuka_017` | `academic` | `ticket` | -2° | `#FDE68A` Golden yellow | `langkasuka-lab-bench-01.webp` | `cover` / 1.08 | Bawa buku amali yang lengkap dan tandakan bahagian pengiraan yang perlu disediakan awal. Ini mengelakkan kerja tergesa-gesa. |
| 18 | Laboratories & Practical Work | en | Farzana R.<br>`demo_langkasuka_018` | `academic` | `rounded` | 1° | `#BFDBFE` Soft blue | 无 | — | Record observations before writing conclusions. Mixing both too early can make the report sound more certain than the actual result. |
| 19 | Laboratories & Practical Work | zh | 匿名<br>`demo_langkasuka_019` | `academic` | `hexagon` | 0° | `#FBCFE8` Soft pink | 无 | — | 做实验时先记录真正看到的现象，再写解释。不要为了配合预期答案而改变观察结果。 |
| 20 | Laboratories & Practical Work | ms | Azreen T.<br>`demo_langkasuka_020` | `academic` | `square` | -1° | `#E9D5FF` Soft purple | 无 | — | Semak unit, label sampel dan susunan data semasa eksperimen masih berjalan. Membetulkan semuanya selepas kelas jauh lebih susah. |
| 21 | Laboratories & Practical Work | en | 匿名<br>`demo_langkasuka_021` | `campus_life` | `torn` | 2° | `#CBD5E1` Grey blue | 无 | — | Use only the assigned equipment and return it as instructed. Report damaged items instead of hiding the problem. |
| 22 | Laboratories & Practical Work | ms | Lauren V.<br>`demo_langkasuka_022` | `campus_life` | `rect` | -2° | `#BBF7D0` Soft green | 无 | — | Jika tumpahan atau kerosakan berlaku, maklumkan segera kepada pensyarah atau pembantu makmal. Jangan cuba menyelesaikan risiko sendiri. |
| 23 | Lecturer & Department Consultation | ms | 匿名<br>`demo_langkasuka_023` | `academic` | `speech` | 1° | `#FED7AA` Soft orange | 无 | — | Sebelum berjumpa pensyarah, sediakan soalan khusus dan bawa kerja yang sudah dicuba. Jangan datang hanya dengan soalan “saya tidak faham”. |
| 24 | Lecturer & Department Consultation | en | Aqmal X.<br>`demo_langkasuka_024` | `academic` | `polaroid` | 0° | `#FFF7ED` Warm cream | `langkasuka-consultation-folder-01.webp` | `contain` / 1.00 | Email or message first when appropriate. Lecturer availability and office arrangements can change from day to day. |
| 25 | Lecturer & Department Consultation | ms | 匿名<br>`demo_langkasuka_025` | `academic` | `envelope` | -1° | `#CFFAFE` Soft cyan | 无 | — | Susun dokumen mengikut topik sebelum datang ke pejabat jabatan. Masa konsultasi tidak patut habis untuk mencari halaman. |
| 26 | Lecturer & Department Consultation | zh | Selena Z.<br>`demo_langkasuka_026` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | 来咨询前先把题目、自己的步骤和卡住的位置整理好，讲师会更容易看出问题在哪里。 |
| 27 | Lecturer & Department Consultation | ms | 匿名<br>`demo_langkasuka_027` | `campus_life` | `ticket` | -2° | `#FEF08A` Soft yellow | 无 | — | Bercakap perlahan di koridor pejabat kerana mungkin ada perbincangan atau kerja sedang berlangsung di bilik berdekatan. |
| 28 | Lecturer & Department Consultation | en | Khadijah B.<br>`demo_langkasuka_028` | `academic` | `circle` | 1° | `#E9D5FF` Soft purple | `langkasuka-office-corridor-01.webp` | `cover` / 1.10 | After consultation, write down the agreed next step. A useful discussion can be wasted if nothing is recorded. |
| 29 | Lecturer & Department Consultation | ms | 匿名<br>`demo_langkasuka_029` | `emotional` | `hexagon` | 0° | `#CBD5E1` Grey blue | 无 | — | Saya dulu takut bertanya kerana rasa soalan terlalu mudah. Apabila datang dengan usaha sendiri, perbincangan sebenarnya lebih selesa. |
| 30 | Exam & Assessment | ms | Marissa D.<br>`demo_langkasuka_030` | `academic` | `polaroid` | -1° | `#BBF7D0` Soft green | `langkasuka-exam-hall-01.webp` | `cover` / 1.10 | Untuk ujian atau peperiksaan, gunakan jadual rasmi sebagai sumber utama. Pengalaman semester lalu tidak menjamin bilik yang sama. |
| 31 | Exam & Assessment | en | 匿名<br>`demo_langkasuka_031` | `academic` | `square` | 2° | `#FED7AA` Soft orange | 无 | — | Prepare stationery and permitted materials the night before. Do not rely on borrowing items after entering the room. |
| 32 | Exam & Assessment | ms | Claire F.<br>`demo_langkasuka_032` | `academic` | `rounded` | -2° | `#FFF7ED` Warm cream | 无 | — | Tulis nama bangunan, kod bilik, masa dan subjek dalam satu nota ringkas. Ini membantu apabila fikiran mula cemas. |
| 33 | Exam & Assessment | en | 匿名<br>`demo_langkasuka_033` | `emotional` | `torn` | 1° | `#CFFAFE` Soft cyan | 无 | — | Arriving early gave me time to settle down and read instructions carefully. Rushing made simple details harder to notice. |
| 34 | Exam & Assessment | ms | Yvonne H.<br>`demo_langkasuka_034` | `academic` | `ticket` | 0° | `#FDE68A` Golden yellow | `langkasuka-exam-checklist-01.webp` | `contain` / 1.02 | Jika nombor tempat duduk ditetapkan, ikut arahan pengawas dan jangan mengubah label atau susunan kerusi. |
| 35 | Exam & Assessment | zh | 匿名<br>`demo_langkasuka_035` | `academic` | `rect` | -1° | `#BFDBFE` Soft blue | 无 | — | 考试地点和时间必须以正式通知为准。留言墙只能分享经验，不能代替学校安排。 |
| 36 | Exam & Assessment | ms | Cedric J.<br>`demo_langkasuka_036` | `emotional` | `speech` | 2° | `#FBCFE8` Soft pink | 无 | — | Selepas penilaian, catat topik yang paling sukar semasa ingatan masih jelas. Fokus pada pembaikan, bukan hanya membandingkan jawapan. |
| 37 | Exam & Assessment | en | 匿名<br>`demo_langkasuka_037` | `academic` | `envelope` | -2° | `#E9D5FF` Soft purple | 无 | — | Before submitting written work, check the required format, page order and identification fields. Small omissions can be avoidable. |
| 38 | Shared Space & Safety | ms | Evangeline L.<br>`demo_langkasuka_038` | `campus_life` | `polaroid` | 1° | `#CBD5E1` Grey blue | 无 | — | Pastikan kerusi, meja dan peralatan ditinggalkan dalam keadaan kemas. Ruang ini digunakan semula oleh ramai kumpulan. |
| 39 | Shared Space & Safety | en | 匿名<br>`demo_langkasuka_039` | `campus_life` | `circle` | 0° | `#BBF7D0` Soft green | `langkasuka-clear-corridor-01.webp` | `cover` / 1.08 | Keep stairs, doors and corridors clear. Bags left in walkways become a safety problem during class changes. |
| 40 | Shared Space & Safety | ms | Nisa N.<br>`demo_langkasuka_040` | `campus_life` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Jika terjumpa barang tertinggal, serahkan kepada pensyarah atau unit yang ditetapkan. Jangan siarkan maklumat terperinci secara terbuka. |
| 41 | Shared Space & Safety | ms | 匿名<br>`demo_langkasuka_041` | `campus_life` | `square` | 2° | `#FFF7ED` Warm cream | 无 | — | Ambil gambar hanya di kawasan yang dibenarkan, dan elakkan senarai pelajar, notis terhad atau wajah yang boleh dikenal pasti. |
| 42 | Shared Space & Safety | ms | Anusha P.<br>`demo_langkasuka_042` | `campus_life` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Laporkan masalah lampu, pendingin hawa, kerusi atau peralatan kepada pihak bertanggungjawab. Jangan membuka atau membaiki sendiri. |

## 7. Codex导入契约

- `contextType: "building"`、`placeId: "B_LANGKASUKA"`。
- 使用本表指定的shape、color、rotation，不得重新随机。
- 匿名便贴的authorNickname必须为null；具名便贴使用表内displayName。
- 演示用户统一 `isDemoSeed: true`、`role: "user"`。
- 照片URL未批准前不得写入虚假链接或普通相对路径。
- 本批尚未批准导入；不得修改网站、commit、push或创建PR。

## 8. 验收、停止条件与回滚

- 42条全部归入B_LANGKASUKA；9条照片便贴与指定编号一致。
- 10种形状和10个颜色预设全部至少出现一次。
- 42个作者ID全部对应演示注册用户；本批显示名不与前三批重复。
- 刷新、新设备首次打开及重复执行均不产生重复数据。
- 页面不显示内部邮箱、用户ID、isDemoSeed或资产管理字段。
- 照片缺失、字段不兼容、种子不幂等或页面明显卡顿时停止。
- 回滚只移除本批演示便贴和对应演示用户，不影响原有数据。
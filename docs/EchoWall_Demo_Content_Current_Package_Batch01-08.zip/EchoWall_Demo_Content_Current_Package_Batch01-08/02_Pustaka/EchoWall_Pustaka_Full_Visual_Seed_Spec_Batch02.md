# EchoWall 演示便贴视觉配置完整版

## 批次 02：Pustaka (Perpustakaan)

> 状态：42 条内容、照片槽位、形状、颜色与旋转已完成；尚未导入网站。

## 1. 总体判断

- 任务类型：`DOC + DATA`
- 风险等级：`L2`
- 变更规模：`S1`（仅完善文档）
- 准备状态：`READY`
- 执行模式：`DIRECT`

## 2. 地点与代码映射

- 建筑名称：**Pustaka (Perpustakaan)**
- `placeId`：`B_PUSTAKA`
- `wallKey`：`building:B_PUSTAKA`
- 区域类型：主图书馆；不新增子留言墙。

## 3. 来源边界

- 已知：KMK 主图书馆设有学术藏书、小组学习区、静音学习区和阅读空间。
- 学生资料指出书包通常不能带入，应放在外部架子，贵重物品随身携带；考试前开放安排可能延长。
- 开放时间属于易变化资料，留言只要求查看最新通告，不写死某天一定开放。
- 不采用旧种子中“图书馆6楼”的说法；当前建筑注册表记录为3层。

## 4. 数据摘要

- 便贴：42 条
- 具名：23 条；匿名：19 条
- BM：24；English：13；中文：5
- 带照片：9 条（21.4%）
- 使用全部10种现有形状和全部10个现有颜色预设
- 所有账号、姓名与留言均为虚构演示数据

### 形状分布
- `rounded`（圆角便贴）：5 条
- `square`（正方形）：5 条
- `rect`（长方形）：4 条
- `circle`（圆形）：4 条
- `envelope`（信封）：4 条
- `torn`（撕边）：4 条
- `speech`（对话框）：4 条
- `polaroid`（拍立得）：4 条
- `ticket`（票券）：4 条
- `hexagon`（六边形）：4 条

### 颜色分布
- `#BFDBFE`（Soft blue）：6 条
- `#FEF08A`（Soft yellow）：3 条
- `#BBF7D0`（Soft green）：4 条
- `#FBCFE8`（Soft pink）：3 条
- `#FED7AA`（Soft orange）：4 条
- `#FFF7ED`（Warm cream）：4 条
- `#E9D5FF`（Soft purple）：5 条
- `#CBD5E1`（Grey blue）：5 条
- `#CFFAFE`（Soft cyan）：5 条
- `#FDE68A`（Golden yellow）：3 条

## 5. 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 2 | `pustaka-bag-rack-01.webp` | 图书馆入口外的书包架，画面只显示整齐摆放的书包，不出现姓名牌、学号或清晰人脸。 | 可参考 school-environment PDF 第10页；建议用户自行补拍 | `cover` | 1.12 |
| 6 | `pustaka-notice-board-01.webp` | 入口处最新通告或开放时间牌，裁切掉电话号码、姓名和任何个人资料。 | 需拍摄／用户自有 | `contain` | 1.00 |
| 10 | `pustaka-silent-study-01.webp` | 整洁的静音学习区或空桌椅，避免拍到可辨认学生正脸。 | 需拍摄／用户自有 | `cover` | 1.08 |
| 15 | `pustaka-study-checklist-01.webp` | 两小时学习清单、计时器和笔记本的桌面摆拍，不出现真实姓名或课程账号。 | 需拍摄／用户自有摆拍 | `contain` | 1.03 |
| 20 | `pustaka-group-study-01.webp` | 小组学习桌上的分题笔记和白纸，可只拍手部或物品，避免清晰人脸。 | 需拍摄／用户自有摆拍 | `cover` | 1.10 |
| 24 | `pustaka-group-summary-01.webp` | 写有 understood / uncertain / verify 三栏的总结纸张，不使用真实作业内容。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 29 | `pustaka-book-shelf-01.webp` | 学术藏书书架或书本局部，避免拍到借阅记录、条码对应信息或学生。 | 可参考 school-environment PDF 第10页；建议用户自行补拍 | `cover` | 1.12 |
| 35 | `pustaka-exam-revision-01.webp` | 桌面上的复习题、荧光笔和简短计划；内容必须是通用摆拍，不显示真实学生资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 40 | `pustaka-library-cafe-break-01.webp` | 图书馆附近休息区或饮料小吃的局部，不拍清晰人脸、价格承诺或固定菜单。 | 可参考 school-environment PDF 第15页；实际照片需确认 | `cover` | 1.10 |

照片统一要求：4:3横向优先、WebP、单张目标不超过450KB；不出现清晰人脸、姓名、学号、借阅记录或账号资料。跨设备展示优先使用批准后的Cloudinary HTTPS URL。

## 6. 42条完整视觉字段

| No. | 分区 | 语言 | 显示 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Orientation & Entry | ms | Nabila K.<br>`demo_pustaka_001` | `campus_life` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Sebelum masuk, semak notis terkini di pintu. Waktu operasi boleh berubah, terutama menjelang minggu peperiksaan atau cuti kolej. |
| 2 | Orientation & Entry | ms | 匿名<br>`demo_pustaka_002` | `campus_life` | `ticket` | 1° | `#FEF08A` Soft yellow | `pustaka-bag-rack-01.webp` | `cover` / 1.12 | Beg biasanya perlu diletakkan di rak luar. Bawa telefon, dompet dan barang berharga bersama; jangan tinggalkan dalam beg tanpa pengawasan. |
| 3 | Orientation & Entry | en | Olivia M.<br>`demo_pustaka_003` | `campus_life` | `square` | 0° | `#BBF7D0` Soft green | 无 | — | Take only the materials you need before entering. Going back repeatedly to the bag rack breaks your study flow. |
| 4 | Orientation & Entry | zh | 匿名<br>`demo_pustaka_004` | `campus_life` | `envelope` | 2° | `#FBCFE8` Soft pink | 无 | — | 进入图书馆前先把电脑、充电器和笔记拿好，贵重物品不要留在外面的书包里。 |
| 5 | Orientation & Entry | ms | Rayyan S.<br>`demo_pustaka_005` | `campus_life` | `rect` | -1° | `#FED7AA` Soft orange | 无 | — | Kalau datang berkumpulan, tentukan tempat berjumpa terlebih dahulu. Kawasan pintu masuk mudah sesak apabila ramai orang keluar serentak. |
| 6 | Orientation & Entry | en | Hannah Y.<br>`demo_pustaka_006` | `campus_life` | `polaroid` | 1° | `#FFF7ED` Warm cream | `pustaka-notice-board-01.webp` | `contain` / 1.00 | A quick photo of the current notice board is useful, but avoid capturing other students or personal information. |
| 7 | Orientation & Entry | ms | Afiq H.<br>`demo_pustaka_007` | `campus_life` | `speech` | -2° | `#E9D5FF` Soft purple | 无 | — | Simpan kad matrik di tempat yang mudah dicapai. Jangan letak bersama barang yang sukar diambil semula dari rak beg. |
| 8 | Orientation & Entry | ms | 匿名<br>`demo_pustaka_008` | `campus_life` | `torn` | 2° | `#CBD5E1` Grey blue | 无 | — | Kalau rak beg penuh, susun beg dengan kemas dan jangan menutup laluan. Ambil gambar lokasi rak supaya senang dicari semula. |
| 9 | Quiet Study | en | Noah P.<br>`demo_pustaka_009` | `academic` | `hexagon` | 0° | `#CFFAFE` Soft cyan | 无 | — | The silent zone works best when you prepare one clear task before sitting down. I usually write a two-hour checklist first. |
| 10 | Quiet Study | ms | 匿名<br>`demo_pustaka_010` | `academic` | `circle` | -1° | `#FDE68A` Golden yellow | `pustaka-silent-study-01.webp` | `cover` / 1.08 | Zon senyap sangat sesuai untuk latihan pengiraan. Letakkan telefon dalam mod senyap supaya tidak terganggu setiap beberapa minit. |
| 11 | Quiet Study | ms | Dhia F.<br>`demo_pustaka_011` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | Saya guna teknik 45 minit belajar dan 10 minit rehat. Lebih mudah kekal fokus berbanding duduk terlalu lama tanpa sasaran. |
| 12 | Quiet Study | zh | 匿名<br>`demo_pustaka_012` | `academic` | `square` | -2° | `#CFFAFE` Soft cyan | 无 | — | 安静区适合做需要专注的题目，但记得把手机调成静音，不要一直震动影响别人。 |
| 13 | Quiet Study | ms | Aarav D.<br>`demo_pustaka_013` | `emotional` | `envelope` | 1° | `#E9D5FF` Soft purple | 无 | — | Bila ulang kaji terasa terlalu berat, pilih satu bab kecil dan siapkan dahulu. Satu tugas yang selesai lebih baik daripada rancangan yang sempurna. |
| 14 | Quiet Study | ms | 匿名<br>`demo_pustaka_014` | `academic` | `rect` | 0° | `#CBD5E1` Grey blue | 无 | — | Tempat yang paling selesa belum tentu tempat paling produktif. Pilih meja yang kurang lalu-lalang jika mudah hilang fokus. |
| 15 | Quiet Study | en | Megan J.<br>`demo_pustaka_015` | `academic` | `polaroid` | -1° | `#FEF08A` Soft yellow | `pustaka-study-checklist-01.webp` | `contain` / 1.03 | Bring headphones only for offline audio or noise reduction. Keep the volume low enough that it cannot be heard by nearby students. |
| 16 | Quiet Study | ms | 匿名<br>`demo_pustaka_016` | `campus_life` | `speech` | 2° | `#BBF7D0` Soft green | 无 | — | Jangan tinggalkan buku dan alat tulis untuk 'menempah' meja terlalu lama. Beri peluang kepada orang lain menggunakan ruang belajar. |
| 17 | Group Study | ms | Harith Z.<br>`demo_pustaka_017` | `academic` | `ticket` | -2° | `#FBCFE8` Soft pink | 无 | — | Untuk belajar berkumpulan, setiap orang perlu bawa satu topik untuk diterangkan. Jangan datang hanya untuk menyalin jawapan kawan. |
| 18 | Group Study | en | 匿名<br>`demo_pustaka_018` | `academic` | `torn` | 1° | `#FED7AA` Soft orange | 无 | — | Group discussion is more effective when one person keeps time and another records unanswered questions for later consultation. |
| 19 | Group Study | ms | Yasmin B.<br>`demo_pustaka_019` | `academic` | `rounded` | 0° | `#FFF7ED` Warm cream | 无 | — | Kami bahagikan meja kepada tiga bahagian: nota, soalan, dan kesilapan biasa. Cara ini buat perbincangan lebih teratur. |
| 20 | Group Study | zh | 匿名<br>`demo_pustaka_020` | `academic` | `hexagon` | -1° | `#CFFAFE` Soft cyan | `pustaka-group-study-01.webp` | `cover` / 1.10 | 小组讨论前先分配题目，每个人讲一个部分，比大家一起看同一页更有效率。 |
| 21 | Group Study | en | Isaac N.<br>`demo_pustaka_021` | `campus_life` | `circle` | 2° | `#BFDBFE` Soft blue | 无 | — | Use the group zone for discussion and move to the silent area for individual work. Mixing both usually frustrates everyone. |
| 22 | Group Study | ms | 匿名<br>`demo_pustaka_022` | `academic` | `square` | -2° | `#E9D5FF` Soft purple | 无 | — | Kalau perbincangan mula lari topik, kembali kepada senarai soalan. Satu sesi yang pendek tetapi fokus lebih berguna. |
| 23 | Group Study | ms | Adam E.<br>`demo_pustaka_023` | `emotional` | `envelope` | 1° | `#CBD5E1` Grey blue | 无 | — | Belajar dengan kawan membantu saya sedar bahawa ramai orang juga keliru. Rasa kurang tertekan apabila masalah dibincang bersama. |
| 24 | Group Study | en | 匿名<br>`demo_pustaka_024` | `academic` | `rect` | 0° | `#FDE68A` Golden yellow | `pustaka-group-summary-01.webp` | `contain` / 1.00 | End every group session with a short summary: what is understood, what is uncertain, and who will verify each point. |
| 25 | Books & Resources | ms | Luqman T.<br>`demo_pustaka_025` | `academic` | `polaroid` | -1° | `#BBF7D0` Soft green | 无 | — | Cari nombor panggilan buku sebelum berjalan di antara rak. Catat tajuk dan lokasi supaya tidak perlu mengulang carian. |
| 26 | Books & Resources | en | 匿名<br>`demo_pustaka_026` | `academic` | `speech` | 2° | `#FED7AA` Soft orange | 无 | — | Compare two textbooks when one explanation feels too abstract. Different diagrams often make the same concept much clearer. |
| 27 | Books & Resources | ms | Haziqah P.<br>`demo_pustaka_027` | `academic` | `ticket` | -2° | `#FFF7ED` Warm cream | 无 | — | Jangan ambil terlalu banyak buku serentak. Pilih satu buku utama dan satu rujukan tambahan supaya tidak membazir masa. |
| 28 | Books & Resources | zh | 匿名<br>`demo_pustaka_028` | `academic` | `torn` | 1° | `#CFFAFE` Soft cyan | 无 | — | 找不到资料时先记下书名、作者和关键词，再去询问，比只说“我要那本蓝色的书”清楚很多。 |
| 29 | Books & Resources | en | Ethan C.<br>`demo_pustaka_029` | `academic` | `rounded` | 0° | `#BFDBFE` Soft blue | `pustaka-book-shelf-01.webp` | `cover` / 1.12 | Photograph only the pages you are allowed to use, and record the book title so you can cite the source later. |
| 30 | Books & Resources | ms | 匿名<br>`demo_pustaka_030` | `academic` | `hexagon` | -1° | `#E9D5FF` Soft purple | 无 | — | Selepas guna buku, ikut arahan perpustakaan untuk pemulangan atau susunan semula. Jangan letak secara rawak di rak lain. |
| 31 | Books & Resources | ms | Viknesh K.<br>`demo_pustaka_031` | `academic` | `circle` | 2° | `#CBD5E1` Grey blue | 无 | — | Saya tulis rujukan penuh terus semasa membaca. Menangguhkan citation sampai akhir biasanya menyebabkan sumber hilang. |
| 32 | Books & Resources | en | 匿名<br>`demo_pustaka_032` | `academic` | `square` | -2° | `#FDE68A` Golden yellow | 无 | — | A useful reading method is to write one question before each section. It stops me from highlighting entire pages without thinking. |
| 33 | Exam Season | ms | Syamil J.<br>`demo_pustaka_033` | `academic` | `envelope` | 1° | `#BBF7D0` Soft green | 无 | — | Menjelang peperiksaan, datang dengan rancangan alternatif. Jika tempat pilihan penuh, terus gunakan zon lain tanpa membuang masa menunggu. |
| 34 | Exam Season | en | 匿名<br>`demo_pustaka_034` | `academic` | `rect` | 0° | `#FED7AA` Soft orange | 无 | — | During busy weeks, arrive with downloaded notes and a charged device. Do not depend entirely on Wi-Fi or a nearby power point. |
| 35 | Exam Season | ms | Alyaana R.<br>`demo_pustaka_035` | `emotional` | `polaroid` | -1° | `#FFF7ED` Warm cream | `pustaka-exam-revision-01.webp` | `contain` / 1.02 | Saya pernah duduk lama tetapi tidak banyak belajar kerana terlalu risau. Sekarang saya mula dengan lima soalan mudah untuk bina momentum. |
| 36 | Exam Season | ms | 匿名<br>`demo_pustaka_036` | `academic` | `speech` | 2° | `#CFFAFE` Soft cyan | 无 | — | Gunakan masa terakhir untuk menyemak kesilapan sendiri, bukan membuka terlalu banyak topik baharu. Meja perpustakaan mudah jadi penuh dengan nota yang tidak digunakan. |
| 37 | Exam Season | en | Sophie K.<br>`demo_pustaka_037` | `emotional` | `ticket` | -2° | `#BFDBFE` Soft blue | 无 | — | If you cannot focus, take a short walk outside and return with one specific task. Staying seated while panicking rarely helps. |
| 38 | Exam Season | ms | 匿名<br>`demo_pustaka_038` | `academic` | `torn` | 1° | `#E9D5FF` Soft purple | 无 | — | Bawa air secukupnya mengikut peraturan semasa, tetapi elakkan makanan yang boleh mengotorkan meja atau menarik serangga. |
| 39 | Exam Season | ms | Faris Y.<br>`demo_pustaka_039` | `academic` | `rounded` | 0° | `#CBD5E1` Grey blue | 无 | — | Sebelum pulang, ambil lima minit untuk susun bahan esok. Permulaan sesi berikutnya akan jadi lebih cepat dan kurang kelam-kabut. |
| 40 | Exam Season | en | 匿名<br>`demo_pustaka_040` | `campus_life` | `hexagon` | -1° | `#FBCFE8` Soft pink | `pustaka-library-cafe-break-01.webp` | `cover` / 1.10 | The nearby café can be convenient for a short break, but menus, prices and operating hours may change. Check the current stall notice. |
| 41 | Shared Space Etiquette | ms | Zara H.<br>`demo_pustaka_041` | `campus_life` | `circle` | 2° | `#FEF08A` Soft yellow | 无 | — | Pastikan kerusi dikembalikan ke tempat asal dan sampah dibawa keluar. Ruang yang kemas memudahkan pengguna selepas kita. |
| 42 | Shared Space Etiquette | zh | Daniela P.<br>`demo_pustaka_042` | `campus_life` | `square` | -2° | `#BFDBFE` Soft blue | 无 | — | 需要接电话时请到学习区外面。即使说话声音不大，在安静空间里也会影响附近的人。 |

## 7. Codex导入契约

- `contextType: "building"`、`placeId: "B_PUSTAKA"`。
- 使用本表指定的shape、color、rotation，不得重新随机。
- 匿名便贴的authorNickname必须为null；具名便贴使用表内displayName。
- 演示用户统一 `isDemoSeed: true`、`role: "user"`。
- 照片URL未批准前不得填入虚假链接；不得用普通相对路径冒充跨设备图片。
- 本批尚未批准导入；不得修改网站、commit、push或创建PR。

## 8. 验收、停止条件与回滚

- 42条全部归入B_PUSTAKA；9条照片便贴与指定编号一致。
- 10种形状、10个颜色预设全部至少出现一次。
- 刷新、新设备首次打开及重复执行均不产生重复数据。
- 页面不显示内部邮箱、用户ID、isDemoSeed或资产管理字段。
- 照片缺失、字段不兼容、种子不幂等或页面明显卡顿时停止。
- 回滚只移除本批演示便贴和对应演示用户，不影响原有数据。
# EchoWall KMPP 社区留言墙视觉配置完整版

## 批次 07：Kolej Matrikulasi Pulau Pinang（KMPP）

> 状态：2个community walls、84条便贴、72个虚构演示用户、16个照片槽位，以及全部形状/颜色配置已完成；尚未导入网站。

## 1. 总体判断

- 任务类型：`DOC + DATA`
- 风险等级：`L2`
- 变更规模：`S2`（2个相关community walls与共享用户池）
- 准备状态：`READY`
- 执行模式：`STANDARD`
- 工具：当前使用Chat生成与审核；所有学院内容完成后再交Codex导入。

## 2. 网站映射

- 机构：**KMPP**；`orgId: 3`
- Community wall按`orgId + majorId`过滤，不按batch建立重复留言墙。

| Major ID | 社区留言墙 | 便贴 | 照片槽位 |
|---:|---|---:|---:|
| 8 | Sains | 42 | 8 |
| 9 | Akaun | 42 | 8 |

KMPP对应的batchId为：`7`（Batch 06）、`8`（Batch 07）、`9`（Batch 08）。

## 3. 内容边界

- Sains内容围绕学习规划、科学计算、跨模块概念、实验记录、tutorial、复习与wellbeing。
- Akaun内容围绕账户分类、复式记录、ledger、adjustment、financial statements、economics/business links、tutorial与复习。
- 不编造KMPP特定建筑、讲师、实验室设备、开放时间、课程规则、考试格式或真实学生经历。
- 具体模块组合、课程深度、实验安全和考核要求必须以学院及讲师正式资料为准。
- 所有用户、姓名、邮箱和留言均为虚构演示数据；不得宣称为真实注册、真实采用或真实学生反馈。

## 4. 学院级数据摘要

- Community walls：2
- 便贴：84（每墙42）
- 每墙具名23、匿名19
- 每墙BM 24、English 13、中文5
- 演示用户：72；60人出现1次，12人跨两个墙各出现1次
- 同一用户在同一墙最多出现一次
- 照片槽位：16（每墙8，约19.0%）
- 每墙均使用全部10种现有形状和全部10个颜色预设

## 5. KMPP演示注册用户池

> 所有账户必须设为`isDemoSeed: true`、`role: user`。`.invalid`邮箱不可用于真实投递。匿名便贴仍保留内部authorUserId。

| User ID | 显示名 | 演示邮箱 | Primary major | Batch ID / Label | 使用次数 |
|---|---|---|---|---|---:|
| `demo_kmpp_001` | Adriana M. | `kmpp.demo.001@echowall.invalid` | Sains | `7` / Batch 06 | 2 |
| `demo_kmpp_002` | Akmal R. | `kmpp.demo.002@echowall.invalid` | Sains | `8` / Batch 07 | 2 |
| `demo_kmpp_003` | Bawani S. | `kmpp.demo.003@echowall.invalid` | Sains | `9` / Batch 08 | 2 |
| `demo_kmpp_004` | Bryan T. | `kmpp.demo.004@echowall.invalid` | Sains | `7` / Batch 06 | 2 |
| `demo_kmpp_005` | Camelia H. | `kmpp.demo.005@echowall.invalid` | Sains | `8` / Batch 07 | 2 |
| `demo_kmpp_006` | Dzulqarnain F. | `kmpp.demo.006@echowall.invalid` | Sains | `9` / Batch 08 | 2 |
| `demo_kmpp_007` | Elvina K. | `kmpp.demo.007@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_008` | Fariha N. | `kmpp.demo.008@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_009` | Ganesh P. | `kmpp.demo.009@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_010` | Hui Shan L. | `kmpp.demo.010@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_011` | Ikram J. | `kmpp.demo.011@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_012` | Janani V. | `kmpp.demo.012@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_013` | Khadijah O. | `kmpp.demo.013@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_014` | Loke Jun Y. | `kmpp.demo.014@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_015` | Mahirah C. | `kmpp.demo.015@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_016` | Naqib U. | `kmpp.demo.016@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_017` | Omar Z. | `kmpp.demo.017@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_018` | Pearly G. | `kmpp.demo.018@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_019` | Rania B. | `kmpp.demo.019@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_020` | Sarvesh D. | `kmpp.demo.020@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_021` | Tania E. | `kmpp.demo.021@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_022` | Umar I. | `kmpp.demo.022@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_023` | Vishali Q. | `kmpp.demo.023@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_024` | Wen Hao A. | `kmpp.demo.024@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_025` | Yaqin M. | `kmpp.demo.025@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_026` | Zulaifa T. | `kmpp.demo.026@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_027` | Aariz N. | `kmpp.demo.027@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_028` | Brinda K. | `kmpp.demo.028@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_029` | Carmen J. | `kmpp.demo.029@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_030` | Dzulfiqar S. | `kmpp.demo.030@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_031` | Evelyn P. | `kmpp.demo.031@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_032` | Fawzi H. | `kmpp.demo.032@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_033` | Gayathri R. | `kmpp.demo.033@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_034` | Haziem W. | `kmpp.demo.034@echowall.invalid` | Sains | `7` / Batch 06 | 1 |
| `demo_kmpp_035` | Isabel C. | `kmpp.demo.035@echowall.invalid` | Sains | `8` / Batch 07 | 1 |
| `demo_kmpp_036` | Junaid L. | `kmpp.demo.036@echowall.invalid` | Sains | `9` / Batch 08 | 1 |
| `demo_kmpp_037` | Kareena M. | `kmpp.demo.037@echowall.invalid` | Akaun | `7` / Batch 06 | 2 |
| `demo_kmpp_038` | Lutfi V. | `kmpp.demo.038@echowall.invalid` | Akaun | `8` / Batch 07 | 2 |
| `demo_kmpp_039` | Maisarah G. | `kmpp.demo.039@echowall.invalid` | Akaun | `9` / Batch 08 | 2 |
| `demo_kmpp_040` | Naveen O. | `kmpp.demo.040@echowall.invalid` | Akaun | `7` / Batch 06 | 2 |
| `demo_kmpp_041` | Ophelia Y. | `kmpp.demo.041@echowall.invalid` | Akaun | `8` / Batch 07 | 2 |
| `demo_kmpp_042` | Pritam A. | `kmpp.demo.042@echowall.invalid` | Akaun | `9` / Batch 08 | 2 |
| `demo_kmpp_043` | Qaira F. | `kmpp.demo.043@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_044` | Ridhwan K. | `kmpp.demo.044@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_045` | Sangeetha N. | `kmpp.demo.045@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_046` | Taufik P. | `kmpp.demo.046@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_047` | Uma S. | `kmpp.demo.047@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_048` | Vernon J. | `kmpp.demo.048@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_049` | Wai Kit D. | `kmpp.demo.049@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_050` | Yumna H. | `kmpp.demo.050@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_051` | Zackary L. | `kmpp.demo.051@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_052` | Ameera V. | `kmpp.demo.052@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_053` | Benedict C. | `kmpp.demo.053@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_054` | Citra R. | `kmpp.demo.054@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_055` | Danishka M. | `kmpp.demo.055@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_056` | Ezzati A. | `kmpp.demo.056@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_057` | Faheem Q. | `kmpp.demo.057@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_058` | Giselle T. | `kmpp.demo.058@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_059` | Husna I. | `kmpp.demo.059@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_060` | Imad B. | `kmpp.demo.060@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_061` | Jeevan S. | `kmpp.demo.061@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_062` | Kezia W. | `kmpp.demo.062@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_063` | Liyana Z. | `kmpp.demo.063@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_064` | Mohan R. | `kmpp.demo.064@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_065` | Nashwa K. | `kmpp.demo.065@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_066` | Ooi Mei F. | `kmpp.demo.066@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_067` | Prakash H. | `kmpp.demo.067@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_068` | Qaisara D. | `kmpp.demo.068@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_069` | Rauf N. | `kmpp.demo.069@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |
| `demo_kmpp_070` | Sharmila J. | `kmpp.demo.070@echowall.invalid` | Akaun | `7` / Batch 06 | 1 |
| `demo_kmpp_071` | Tisha G. | `kmpp.demo.071@echowall.invalid` | Akaun | `8` / Batch 07 | 1 |
| `demo_kmpp_072` | Uwais M. | `kmpp.demo.072@echowall.invalid` | Akaun | `9` / Batch 08 | 1 |

## 6. Sains（majorId 8）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 3 + majorId`的community wall，不创建建筑或地图地点。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmpp-sains-weekly-study-plan-01.webp` | 理科一周学习计划、科目文件夹和待完成清单的桌面摆拍；不显示真实姓名或课程账号。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 8 | `kmpp-sains-calculation-working-01.webp` | 通用科学计算working，显示given、wanted、formula和unit四部分；不使用正式考题。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 15 | `kmpp-sains-concept-diagram-01.webp` | 通用Chemistry粒子图、Biology流程图或Physics受力草图之一；不冒充正式课件。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 22 | `kmpp-sains-practical-preparation-01.webp` | 空白观察表、护目镜或实验衣的安全摆拍；实际要求以讲师和实验室规定为准。 | 需拍摄／用户自有摆拍 | `contain` | 1.03 |
| 25 | `kmpp-sains-observation-graph-01.webp` | 虚构观察数据与标有轴、单位和趋势线的图表；不得使用真实实验报告。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 29 | `kmpp-sains-tutorial-question-list-01.webp` | 已圈出疑问步骤的通用练习纸和问题清单；不显示真实姓名、测验标题或分数。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 36 | `kmpp-sains-error-map-01.webp` | 按concept、calculation、unit和question reading分类的错误记录卡。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 40 | `kmpp-sains-balanced-revision-plan-01.webp` | 包含练习、睡眠和短休息的通用复习计划；不显示个人日程或账号。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |

### 42条完整视觉字段

| No. | 分区 | Batch ID | 语言 | 显示 | Author ID | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Planning & Subject Balance | `7` | ms | Adriana M. | `demo_kmpp_001` | `academic` | `polaroid` | -2° | `#BFDBFE` Soft blue | `kmpp-sains-weekly-study-plan-01.webp` | `contain` / 1.02 | Sebelum minggu bermula, bahagi masa mengikut topik yang perlu dikuasai, bukan sekadar jumlah halaman yang mahu dibaca. |
| 2 | Planning & Subject Balance | `8` | ms | 匿名 | `demo_kmpp_002` | `academic` | `rounded` | 1° | `#FEF08A` Soft yellow | 无 | — | Jangan cuba memberi masa yang sama kepada setiap subjek. Tambah masa pada topik yang masih lemah dan kekalkan latihan ringkas untuk topik yang sudah stabil. |
| 3 | Planning & Subject Balance | `9` | en | Bawani S. | `demo_kmpp_003` | `academic` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | A weekly plan works better when every block has a clear output, such as completing five questions or explaining one process without notes. |
| 4 | Planning & Subject Balance | `7` | zh | 匿名 | `demo_kmpp_004` | `academic` | `square` | 2° | `#FBCFE8` Soft pink | 无 | — | 理科科目很多时，可以每天安排一个主要目标和一个较轻的复习目标，不要把所有难题都挤在同一天。 |
| 5 | Planning & Subject Balance | `8` | ms | Camelia H. | `demo_kmpp_005` | `campus_life` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Simpan nota setiap subjek dalam folder berasingan dan gunakan nama fail yang konsisten. Bahan yang tersusun mengurangkan masa mencari semasa ulang kaji. |
| 6 | Planning & Subject Balance | `9` | en | 匿名 | `demo_kmpp_006` | `emotional` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | Falling behind in one science subject does not mean the whole semester is lost. Identify the earliest missing concept and rebuild from there. |
| 7 | Planning & Subject Balance | `7` | ms | Elvina K. | `demo_kmpp_007` | `academic` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Pada akhir minggu, semak apa yang benar-benar boleh diterangkan tanpa melihat nota. Itu lebih jujur daripada hanya menanda jadual sebagai selesai. |
| 8 | Mathematics & Calculations | `8` | ms | 匿名 | `demo_kmpp_008` | `academic` | `envelope` | 2° | `#CBD5E1` Grey blue | `kmpp-sains-calculation-working-01.webp` | `contain` / 1.00 | Untuk soalan pengiraan, asingkan maklumat diberi, perkara yang dicari, formula dan unit sebelum menggantikan nombor. |
| 9 | Mathematics & Calculations | `9` | ms | Ganesh P. | `demo_kmpp_009` | `academic` | `torn` | 0° | `#CFFAFE` Soft cyan | 无 | — | Tulis hubungan simbolik terlebih dahulu. Langkah ini memudahkan anda melihat sama ada pemboleh ubah dan susunan formula sudah betul. |
| 10 | Mathematics & Calculations | `7` | en | Hui Shan L. | `demo_kmpp_010` | `academic` | `circle` | -1° | `#FDE68A` Golden yellow | 无 | — | Estimate the expected size and sign of an answer before using the calculator. A sensible estimate catches many input mistakes. |
| 11 | Mathematics & Calculations | `8` | zh | 匿名 | `demo_kmpp_011` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | 画图时把坐标轴、单位和方向写清楚。很多计算错误其实来自图像解读和正负号，而不是公式本身。 |
| 12 | Mathematics & Calculations | `9` | ms | Janani V. | `demo_kmpp_012` | `academic` | `polaroid` | -2° | `#E9D5FF` Soft purple | 无 | — | Jika kalkulator memberi jawapan pelik, semak mod, kurungan dan penukaran unit sebelum mengulang seluruh penyelesaian. |
| 13 | Mathematics & Calculations | `7` | en | 匿名 | `demo_kmpp_013` | `academic` | `square` | 1° | `#CBD5E1` Grey blue | 无 | — | Keep an error log that separates algebra, unit, graph and concept mistakes. Different errors need different revision methods. |
| 14 | Mathematics & Calculations | `8` | ms | Loke Jun Y. | `demo_kmpp_014` | `academic` | `ticket` | 0° | `#FED7AA` Soft orange | 无 | — | Latihan bermasa hanya berguna selepas kaedah difahami. Jangan mempercepat proses yang masih kabur kerana kesilapan akan menjadi lebih banyak. |
| 15 | Science Concepts Across Modules | `9` | ms | Mahirah C. | `demo_kmpp_015` | `academic` | `speech` | -1° | `#FFF7ED` Warm cream | `kmpp-sains-concept-diagram-01.webp` | `contain` / 1.02 | Untuk topik Chemistry, kaitkan persamaan dengan zarah dan perubahan yang berlaku. Menghafal simbol sahaja mudah menyebabkan konsep bercampur. |
| 16 | Science Concepts Across Modules | `7` | ms | 匿名 | `demo_kmpp_016` | `academic` | `rect` | 2° | `#CFFAFE` Soft cyan | 无 | — | Dalam Biology, lukis proses sebagai urutan dan tandakan tempat setiap perubahan berlaku. Gambar rajah membantu melihat hubungan antara langkah. |
| 17 | Science Concepts Across Modules | `8` | en | Omar Z. | `demo_kmpp_017` | `academic` | `hexagon` | -2° | `#FDE68A` Golden yellow | 无 | — | For Physics topics, draw the situation and choose a reference direction before calculating. The sign convention should remain consistent. |
| 18 | Science Concepts Across Modules | `9` | zh | 匿名 | `demo_kmpp_018` | `academic` | `envelope` | 1° | `#BBF7D0` Soft green | 无 | — | 遇到相似术语时，做一个对比表：定义、发生地点、条件和结果。这样比反复背整段文字更容易分清。 |
| 19 | Science Concepts Across Modules | `7` | ms | Rania B. | `demo_kmpp_019` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Bina peta konsep yang menghubungkan skala kecil dengan pemerhatian besar, contohnya zarah, perubahan bahan dan hasil eksperimen. |
| 20 | Science Concepts Across Modules | `8` | en | 匿名 | `demo_kmpp_020` | `academic` | `torn` | -1° | `#BFDBFE` Soft blue | 无 | — | Explain a concept aloud using ordinary words before adding technical terms. If the simple explanation fails, the idea is not stable yet. |
| 21 | Science Concepts Across Modules | `9` | ms | Tania E. | `demo_kmpp_021` | `academic` | `polaroid` | 2° | `#E9D5FF` Soft purple | 无 | — | Bezakan pemerhatian, inferens dan penerangan. Ketiga-tiganya berkaitan tetapi tidak boleh ditulis seolah-olah perkara yang sama. |
| 22 | Practical & Laboratory Reports | `7` | ms | 匿名 | `demo_kmpp_022` | `academic` | `circle` | -2° | `#CBD5E1` Grey blue | `kmpp-sains-practical-preparation-01.webp` | `contain` / 1.03 | Baca prosedur sebelum amali dan tandakan data yang perlu direkodkan. Jangan tunggu eksperimen bermula untuk memahami jadual pemerhatian. |
| 23 | Practical & Laboratory Reports | `8` | ms | Vishali Q. | `demo_kmpp_023` | `academic` | `square` | 1° | `#CFFAFE` Soft cyan | 无 | — | Sediakan jadual kosong dengan tajuk, unit dan ruang ulangan. Rekod terus semasa amali supaya maklumat tidak bergantung pada ingatan. |
| 24 | Practical & Laboratory Reports | `9` | en | Wen Hao A. | `demo_kmpp_024` | `campus_life` | `ticket` | 0° | `#FEF08A` Soft yellow | 无 | — | Follow the lecturer and laboratory instructions for clothing, apparatus and disposal. A community post cannot replace official safety rules. |
| 25 | Practical & Laboratory Reports | `7` | zh | 匿名 | `demo_kmpp_025` | `academic` | `rect` | -1° | `#FED7AA` Soft orange | `kmpp-sains-observation-graph-01.webp` | `contain` / 1.00 | 实验结果不符合预期时，先记录真实观察，再检查步骤和仪器。不要为了得到“正确答案”修改数据。 |
| 26 | Practical & Laboratory Reports | `8` | ms | Zulaifa T. | `demo_kmpp_026` | `academic` | `speech` | 2° | `#FFF7ED` Warm cream | 无 | — | Apabila melukis graf, semak pemboleh ubah pada paksi, unit, skala dan titik luar biasa sebelum membuat kesimpulan. |
| 27 | Practical & Laboratory Reports | `9` | en | 匿名 | `demo_kmpp_027` | `academic` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | A good discussion explains patterns, uncertainty and possible limitations. It should not simply repeat the observation table. |
| 28 | Practical & Laboratory Reports | `7` | ms | Brinda K. | `demo_kmpp_028` | `campus_life` | `hexagon` | 1° | `#E9D5FF` Soft purple | 无 | — | Bahagikan peranan kumpulan dengan jelas, tetapi semua ahli perlu memahami prosedur dan keputusan, bukan hanya tugas sendiri. |
| 29 | Tutorial, Group Study & Resources | `8` | ms | Carmen J. | `demo_kmpp_029` | `academic` | `envelope` | 0° | `#CBD5E1` Grey blue | `kmpp-sains-tutorial-question-list-01.webp` | `contain` / 1.02 | Cuba soalan sebelum tutorial dan bulatkan langkah pertama yang tidak difahami. Pensyarah boleh membantu dengan lebih tepat apabila working tersedia. |
| 30 | Tutorial, Group Study & Resources | `9` | ms | 匿名 | `demo_kmpp_030` | `academic` | `polaroid` | -1° | `#CFFAFE` Soft cyan | 无 | — | Dalam kumpulan, setiap orang terangkan satu konsep atau satu soalan. Perbincangan kurang berguna jika hanya seorang bercakap sepanjang masa. |
| 31 | Tutorial, Group Study & Resources | `7` | en | Evelyn P. | `demo_kmpp_031` | `academic` | `torn` | 2° | `#FDE68A` Golden yellow | 无 | — | Compare explanations from two reliable sources when one diagram feels unclear, but keep the lecturer's course requirements as the reference. |
| 32 | Tutorial, Group Study & Resources | `8` | zh | 匿名 | `demo_kmpp_032` | `academic` | `circle` | -2° | `#BBF7D0` Soft green | 无 | — | 把不会的问题整理成清单，并写下自己已经尝试过的方法。这样提问时不会只剩下一句“我不懂”。 |
| 33 | Tutorial, Group Study & Resources | `9` | ms | Gayathri R. | `demo_kmpp_033` | `academic` | `square` | 1° | `#FBCFE8` Soft pink | 无 | — | Apabila berkongsi sumber, tambah satu ayat tentang topik dan sebab ia membantu. Pautan tanpa konteks mudah diabaikan. |
| 34 | Tutorial, Group Study & Resources | `7` | en | 匿名 | `demo_kmpp_034` | `campus_life` | `rounded` | 0° | `#FED7AA` Soft orange | 无 | — | Check whether a resource matches your module and current syllabus before sharing it widely. Similar course names may cover different depth. |
| 35 | Tutorial, Group Study & Resources | `8` | ms | Isabel C. | `demo_kmpp_035` | `koko` | `ticket` | -1° | `#FFF7ED` Warm cream | 无 | — | Sertai sesi perkongsian atau aktiviti sains jika ada peluang, tetapi datang dengan soalan dan catatan supaya pengalaman itu menyokong pembelajaran. |
| 36 | Assessment, Wellbeing & Pathway | `9` | ms | 匿名 | `demo_kmpp_036` | `academic` | `rect` | 2° | `#BFDBFE` Soft blue | `kmpp-sains-error-map-01.webp` | `contain` / 1.00 | Selepas kuiz, susun kesilapan mengikut konsep, pengiraan, unit dan salah baca soalan. Corak kesilapan lebih berguna daripada markah sahaja. |
| 37 | Assessment, Wellbeing & Pathway | `7` | ms | Kareena M. | `demo_kmpp_037` | `emotional` | `speech` | -2° | `#E9D5FF` Soft purple | 无 | — | Apabila terlalu banyak topik belum siap, pilih satu tugas kecil yang boleh diselesaikan dalam masa singkat untuk membina semula momentum. |
| 38 | Assessment, Wellbeing & Pathway | `8` | en | 匿名 | `demo_kmpp_038` | `academic` | `hexagon` | 1° | `#CBD5E1` Grey blue | 无 | — | Use past practice to test retrieval, not to memorise answer patterns. Explain why each option or step is correct. |
| 39 | Assessment, Wellbeing & Pathway | `9` | en | Maisarah G. | `demo_kmpp_039` | `emotional` | `envelope` | 0° | `#CFFAFE` Soft cyan | 无 | — | A difficult week in science does not define your ability. Ask for help early and reduce the problem to one manageable concept. |
| 40 | Assessment, Wellbeing & Pathway | `7` | ms | 匿名 | `demo_kmpp_040` | `academic` | `polaroid` | -1° | `#FDE68A` Golden yellow | `kmpp-sains-balanced-revision-plan-01.webp` | `contain` / 1.02 | Pada minggu peperiksaan, seimbangkan latihan, tidur dan semakan ringan. Jadual yang terlalu padat biasanya gagal selepas satu atau dua hari. |
| 41 | Assessment, Wellbeing & Pathway | `8` | en | Ophelia Y. | `demo_kmpp_041` | `emotional` | `torn` | 2° | `#BBF7D0` Soft green | 无 | — | When considering a future field, notice which questions keep you curious after the assessment is over, not only which subject gives the highest mark. |
| 42 | Assessment, Wellbeing & Pathway | `9` | ms | 匿名 | `demo_kmpp_042` | `campus_life` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Bezakan pengalaman rakan daripada peraturan rasmi. Hal peperiksaan, modul dan penilaian mesti disemak melalui kolej atau pensyarah. |

## 7. Akaun（majorId 9）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 3 + majorId`的community wall，不创建建筑或地图地点。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmpp-akaun-account-classification-01.webp` | 资产、负债、权益、收入和费用的通用分类卡片；不使用真实公司资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 8 | `kmpp-akaun-ledger-posting-01.webp` | 虚构journal到ledger的posting working，显示日期和reference但不含真实交易。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 15 | `kmpp-akaun-financial-statement-layout-01.webp` | 通用财务报表结构草稿与小计标记；不出现真实企业名称或金额。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 22 | `kmpp-akaun-economics-graph-01.webp` | 带完整轴标签和变化箭头的通用经济图，不对应真实市场数据。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 24 | `kmpp-akaun-percentage-working-01.webp` | 百分比、rate和base value检查表，使用虚构数字。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 29 | `kmpp-akaun-full-working-01.webp` | 从交易分析到最终答案的完整通用working，标出第一处错误。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 33 | `kmpp-akaun-timed-practice-01.webp` | 计时器、混合练习和错误清单的桌面摆拍；不使用正式考试卷。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 40 | `kmpp-akaun-rest-checklist-01.webp` | imbalance检查清单、短休息提示和重新检查步骤的摆拍。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |

### 42条完整视觉字段

| No. | 分区 | Batch ID | 语言 | 显示 | Author ID | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Accounting Foundations & Classification | `7` | ms | Kareena M. | `demo_kmpp_037` | `academic` | `envelope` | 2° | `#E9D5FF` Soft purple | `kmpp-akaun-account-classification-01.webp` | `contain` / 1.00 | Sebelum merekod transaksi, tentukan dahulu akaun yang terlibat dan jenisnya. Klasifikasi yang salah akan menjejaskan langkah seterusnya. |
| 2 | Accounting Foundations & Classification | `8` | ms | Lutfi V. | `demo_kmpp_038` | `academic` | `torn` | 0° | `#CBD5E1` Grey blue | 无 | — | Gunakan persamaan perakaunan sebagai semakan logik. Setiap transaksi perlu mempunyai kesan yang boleh diterangkan, bukan hanya debit dan kredit yang dihafal. |
| 3 | Accounting Foundations & Classification | `9` | en | 匿名 | `demo_kmpp_039` | `academic` | `circle` | -1° | `#FED7AA` Soft orange | 无 | — | Describe the business meaning of a transaction before writing the entry. The accounting treatment becomes clearer when the event is understood. |
| 4 | Accounting Foundations & Classification | `7` | zh | Naveen O. | `demo_kmpp_040` | `academic` | `rounded` | 2° | `#FFF7ED` Warm cream | 无 | — | 学习借方和贷方时，不要只背左右位置。先判断账户类别和增加或减少，记录会更稳定。 |
| 5 | Accounting Foundations & Classification | `8` | ms | 匿名 | `demo_kmpp_041` | `academic` | `polaroid` | -2° | `#CFFAFE` Soft cyan | 无 | — | Baca dokumen sumber dengan teliti dan tandakan tarikh, pihak terlibat, amaun serta tujuan transaksi sebelum merekod. |
| 6 | Accounting Foundations & Classification | `9` | en | Pritam A. | `demo_kmpp_042` | `academic` | `square` | 1° | `#FDE68A` Golden yellow | 无 | — | Keep narration and working concise but complete. A correct entry is easier to review when the reason can still be traced. |
| 7 | Accounting Foundations & Classification | `7` | ms | 匿名 | `demo_kmpp_043` | `academic` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | Selepas selesai satu set transaksi, semak semula daripada sudut perniagaan. Tanya sama ada baki dan perubahan itu masuk akal. |
| 8 | Ledger, Trial Balance & Adjustments | `8` | ms | Ridhwan K. | `demo_kmpp_044` | `academic` | `speech` | -1° | `#FBCFE8` Soft pink | `kmpp-akaun-ledger-posting-01.webp` | `contain` / 1.02 | Semasa memindahkan catatan ke lejar, gunakan rujukan dan tarikh secara konsisten supaya kesilapan boleh dijejaki. |
| 9 | Ledger, Trial Balance & Adjustments | `9` | ms | 匿名 | `demo_kmpp_045` | `academic` | `rect` | 2° | `#BFDBFE` Soft blue | 无 | — | Imbangan duga yang seimbang belum membuktikan semua catatan betul. Kesilapan klasifikasi atau transaksi tertinggal masih boleh berlaku. |
| 10 | Ledger, Trial Balance & Adjustments | `7` | en | Taufik P. | `demo_kmpp_046` | `academic` | `hexagon` | -2° | `#E9D5FF` Soft purple | 无 | — | For adjusting entries, identify the period affected and the economic reason before choosing the accounts. |
| 11 | Ledger, Trial Balance & Adjustments | `8` | zh | 匿名 | `demo_kmpp_047` | `academic` | `envelope` | 1° | `#CBD5E1` Grey blue | 无 | — | 处理应计和预付项目时，可以先画时间线，标出已经发生、已经支付和属于本期的部分。 |
| 12 | Ledger, Trial Balance & Adjustments | `9` | ms | Vernon J. | `demo_kmpp_048` | `academic` | `rounded` | 0° | `#CFFAFE` Soft cyan | 无 | — | Jika baki tidak sama, cari perbezaan secara sistematik: semak jumlah, pemindahan, tanda dan catatan yang mungkin tertinggal. |
| 13 | Ledger, Trial Balance & Adjustments | `7` | en | 匿名 | `demo_kmpp_049` | `academic` | `torn` | -1° | `#FEF08A` Soft yellow | 无 | — | Correct an error by showing the original effect and the required effect. Guessing a balancing amount hides the real problem. |
| 14 | Ledger, Trial Balance & Adjustments | `8` | ms | Yumna H. | `demo_kmpp_050` | `academic` | `polaroid` | 2° | `#FED7AA` Soft orange | 无 | — | Bandingkan baki awal, pergerakan dan baki akhir. Hubungan ini membantu mengesan nombor yang tidak konsisten. |
| 15 | Financial Statements & Interpretation | `9` | ms | Zackary L. | `demo_kmpp_051` | `academic` | `circle` | -2° | `#FFF7ED` Warm cream | `kmpp-akaun-financial-statement-layout-01.webp` | `contain` / 1.00 | Pelajari struktur penyata kewangan sebagai aliran maklumat, bukan sebagai format kosong yang perlu dihafal. |
| 16 | Financial Statements & Interpretation | `7` | ms | 匿名 | `demo_kmpp_052` | `academic` | `square` | 1° | `#BFDBFE` Soft blue | 无 | — | Jejak bagaimana satu pelarasan mempengaruhi lebih daripada satu penyata. Ini membantu mengelakkan perubahan yang hanya dibuat pada satu tempat. |
| 17 | Financial Statements & Interpretation | `8` | en | Benedict C. | `demo_kmpp_053` | `academic` | `ticket` | 0° | `#E9D5FF` Soft purple | 无 | — | Use consistent labels, subtotals and presentation. Clear structure makes calculation errors easier to find. |
| 18 | Financial Statements & Interpretation | `9` | zh | 匿名 | `demo_kmpp_054` | `academic` | `rect` | -1° | `#CBD5E1` Grey blue | 无 | — | 分析比率时要结合背景和期间。一个数字变高或变低，并不自动代表表现一定更好或更差。 |
| 19 | Financial Statements & Interpretation | `7` | ms | Danishka M. | `demo_kmpp_055` | `academic` | `speech` | 2° | `#CFFAFE` Soft cyan | 无 | — | Catat andaian dan maklumat tambahan yang digunakan. Penyata yang kemas tetapi tanpa asas yang jelas sukar disemak. |
| 20 | Financial Statements & Interpretation | `8` | en | 匿名 | `demo_kmpp_056` | `academic` | `rounded` | -2° | `#FDE68A` Golden yellow | 无 | — | Reconcile related figures before finalising the statement. Numbers that should connect across sections must tell the same story. |
| 21 | Financial Statements & Interpretation | `9` | ms | Faheem Q. | `demo_kmpp_057` | `academic` | `hexagon` | 1° | `#BBF7D0` Soft green | 无 | — | Selepas mengira, tulis satu ayat tafsiran. Perakaunan bukan hanya mendapatkan nombor tetapi memahami maksudnya. |
| 22 | Economics, Business & Mathematics Links | `7` | ms | 匿名 | `demo_kmpp_058` | `academic` | `envelope` | 0° | `#FBCFE8` Soft pink | `kmpp-akaun-economics-graph-01.webp` | `contain` / 1.00 | Untuk graf ekonomi, label paksi, lengkung dan arah perubahan sebelum menulis huraian. Graf tanpa label mudah disalah tafsir. |
| 23 | Economics, Business & Mathematics Links | `8` | ms | Husna I. | `demo_kmpp_059` | `academic` | `polaroid` | -1° | `#FED7AA` Soft orange | 无 | — | Dalam kajian kes perniagaan, bezakan masalah, bukti, punca dan cadangan. Jangan terus melompat kepada penyelesaian. |
| 24 | Economics, Business & Mathematics Links | `9` | en | 匿名 | `demo_kmpp_060` | `academic` | `torn` | 2° | `#FFF7ED` Warm cream | `kmpp-akaun-percentage-working-01.webp` | `contain` / 1.02 | Check percentages, rates and time periods carefully. A correct formula can still give a misleading answer when the base value is wrong. |
| 25 | Economics, Business & Mathematics Links | `7` | zh | Jeevan S. | `demo_kmpp_061` | `academic` | `circle` | -2° | `#BFDBFE` Soft blue | 无 | — | 讨论商业案例时，把事实和假设分开记录。没有证据的推测不能写成已经确认的结论。 |
| 26 | Economics, Business & Mathematics Links | `8` | ms | 匿名 | `demo_kmpp_062` | `academic` | `square` | 1° | `#E9D5FF` Soft purple | 无 | — | Gunakan definisi ekonomi sebagai permulaan, kemudian hubungkan dengan perubahan, pihak terlibat dan kesan terhadap keputusan. |
| 27 | Economics, Business & Mathematics Links | `9` | en | Liyana Z. | `demo_kmpp_063` | `academic` | `rounded` | 0° | `#CBD5E1` Grey blue | 无 | — | Accounting information becomes useful when it supports a decision. State what the number suggests and what it cannot prove. |
| 28 | Economics, Business & Mathematics Links | `7` | ms | 匿名 | `demo_kmpp_064` | `campus_life` | `ticket` | -1° | `#CFFAFE` Soft cyan | 无 | — | Untuk tugasan kumpulan, tetapkan satu format data dan tarikh tutup dalaman supaya semua bahagian boleh digabung tanpa kekeliruan. |
| 29 | Tutorial, Group Work & Study Systems | `8` | ms | Nashwa K. | `demo_kmpp_065` | `academic` | `rect` | 2° | `#FDE68A` Golden yellow | `kmpp-akaun-full-working-01.webp` | `contain` / 1.02 | Bawa working penuh ke tutorial, bukan hanya jawapan akhir. Kesilapan pertama biasanya lebih penting daripada angka terakhir. |
| 30 | Tutorial, Group Work & Study Systems | `9` | ms | 匿名 | `demo_kmpp_066` | `academic` | `speech` | -2° | `#BBF7D0` Soft green | 无 | — | Dalam sesi kumpulan, setiap orang bentangkan satu transaksi atau pelarasan dan terangkan sebab catatan tersebut. |
| 31 | Tutorial, Group Work & Study Systems | `7` | en | Prakash H. | `demo_kmpp_067` | `academic` | `hexagon` | 1° | `#BFDBFE` Soft blue | 无 | — | Keep an error log for classification, posting, adjustment and presentation mistakes. Review the pattern before the next exercise. |
| 32 | Tutorial, Group Work & Study Systems | `8` | zh | 匿名 | `demo_kmpp_068` | `academic` | `envelope` | 0° | `#BFDBFE` Soft blue | 无 | — | 使用外部资料时记下来源和日期，不要把没有核实的答案直接复制进小组文件。 |
| 33 | Tutorial, Group Work & Study Systems | `9` | ms | Rauf N. | `demo_kmpp_069` | `academic` | `polaroid` | -1° | `#FEF08A` Soft yellow | `kmpp-akaun-timed-practice-01.webp` | `contain` / 1.00 | Selepas memahami format, buat latihan bermasa secara berperingkat. Kelajuan perlu dibina tanpa mengorbankan ketepatan. |
| 34 | Tutorial, Group Work & Study Systems | `7` | en | 匿名 | `demo_kmpp_070` | `campus_life` | `torn` | 2° | `#BBF7D0` Soft green | 无 | — | When using a shared spreadsheet, agree on labels and protect formulas from accidental editing. Keep a clean backup version. |
| 35 | Tutorial, Group Work & Study Systems | `8` | ms | Tisha G. | `demo_kmpp_071` | `koko` | `rounded` | -2° | `#FBCFE8` Soft pink | 无 | — | Sesi perkongsian akademik atau aktiviti keusahawanan boleh membantu jika anda mencatat keputusan, soalan dan perkara yang masih perlu disahkan. |
| 36 | Assessment, Wellbeing & Pathway | `9` | ms | 匿名 | `demo_kmpp_072` | `academic` | `polaroid` | -2° | `#FED7AA` Soft orange | 无 | — | Sebelum peperiksaan, campurkan soalan klasifikasi, pelarasan dan penyata supaya latihan tidak terlalu bergantung pada satu pola. |
| 37 | Assessment, Wellbeing & Pathway | `7` | ms | Adriana M. | `demo_kmpp_001` | `emotional` | `rounded` | 1° | `#FFF7ED` Warm cream | 无 | — | Apabila imbangan tidak sama, berhenti seketika dan kembali dengan senarai semakan. Menatap nombor yang sama terlalu lama biasanya tidak membantu. |
| 38 | Assessment, Wellbeing & Pathway | `8` | en | Akmal R. | `demo_kmpp_002` | `academic` | `ticket` | 0° | `#E9D5FF` Soft purple | 无 | — | After an assessment, redo one difficult question without the marking guide and explain every correction. |
| 39 | Assessment, Wellbeing & Pathway | `9` | en | 匿名 | `demo_kmpp_003` | `emotional` | `square` | 2° | `#CBD5E1` Grey blue | 无 | — | One weak topic does not mean you are unsuitable for accounting. Accuracy improves through a repeatable checking process. |
| 40 | Assessment, Wellbeing & Pathway | `7` | ms | Bryan T. | `demo_kmpp_004` | `academic` | `hexagon` | -1° | `#CFFAFE` Soft cyan | `kmpp-akaun-rest-checklist-01.webp` | `contain` / 1.00 | Jaga tidur dan masa rehat ketika minggu peperiksaan. Kesilapan kecil mudah bertambah apabila terlalu letih. |
| 41 | Assessment, Wellbeing & Pathway | `8` | en | 匿名 | `demo_kmpp_005` | `emotional` | `speech` | 1° | `#FDE68A` Golden yellow | 无 | — | When exploring future pathways, notice whether you enjoy analysing records, explaining decisions or understanding how organisations operate. |
| 42 | Assessment, Wellbeing & Pathway | `9` | ms | Dzulqarnain F. | `demo_kmpp_006` | `campus_life` | `rect` | -2° | `#BFDBFE` Soft blue | 无 | — | Nasihat di dinding komuniti ialah pengalaman umum. Format peperiksaan, kursus dan peraturan rasmi mesti dirujuk kepada kolej atau pensyarah. |

## 8. Codex导入契约

- 当前不要修改网站；本文件先供人工审核。
- Sains固定使用`orgId: 3`、`majorId: 8`；Akaun固定使用`orgId: 3`、`majorId: 9`。
- 每条note使用表内batchId、authorUserId、匿名状态、category、shape、color和rotation，不得重新随机。
- 匿名便贴的authorNickname必须为null；具名便贴使用用户池中的displayName。
- 演示用户统一`isDemoSeed: true`、`role: "user"`，并保留primary major与batchId。
- 照片URL未批准前不得写入虚假Cloudinary链接、Base64占位内容或普通相对路径。
- 不得按Batch 06、07、08建立三套重复community walls。
- 不得自动commit、push、创建PR或改写Git历史。

## 9. 验收与测试

- Sains与Akaun各42条，总计84条。
- 每墙具名23、匿名19；BM 24、English 13、中文5。
- 每墙8条照片、全部10种形状和全部10个颜色预设。
- 72个作者ID全部存在于演示用户池；同一墙无重复作者。
- 60个用户出现1次，12个用户分别在两个墙各出现1次。
- 全部84条正文无重复。
- 刷新、新设备首次载入及重复执行均不产生重复数据。
- 页面不显示演示邮箱、内部用户ID、isDemoSeed或资产管理字段。
- 不把演示内容描述成真实注册、真实使用或真实学生反馈。

## 10. 风险、停止条件与回滚

- 找不到orgId或majorId、batchId不匹配、schema不兼容、种子不幂等或页面明显卡顿时停止。
- 课程模块、实验规则、考试格式与实时学院安排不得由演示留言替代。
- 照片文件未拍摄或未批准时保持为空，不得加入假URL。
- 回滚只移除Batch 07的84条演示便贴及72个KMPP演示用户，不影响原有数据。
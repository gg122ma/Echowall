# EchoWall 演示便贴视觉配置完整版

## 批次 01：Bangunan Seri Jerai｜CUBIC 区域

> 状态：42 条便贴的内容、照片槽位、形状、颜色与旋转已完成。尚未导入网站。

## 1. 总体判断

- 任务类型：`DOC + DATA`
- 风险等级：`L2`
- 变更规模：`S1`（本阶段仅完善文档，不修改网站）
- 准备状态：`READY`
- 执行模式：`DIRECT`

## 2. 地点与代码映射

- 仓库实际建筑名称：**Bangunan Seri Jerai**
- `placeId`：`B_SERI_JERAI`
- `wallKey`：`building:B_SERI_JERAI`
- 内部区域：`CUBIC`
- 不建立独立 CUBIC 建筑、留言墙或路由。

## 3. 数据摘要

- 便贴：42 条
- 具名：23 条；匿名：19 条
- 带照片：9 条（21.4%）；无照片：33 条
- 使用全部 10 种现有形状
- 使用全部 10 个现有颜色预设
- 所有用户、留言及摆拍说明均为演示数据，不取自学生名单

### 形状分布

- `rounded`（圆角便贴）：6 条
- `square`（正方形）：5 条
- `rect`（长方形）：5 条
- `circle`（圆形）：3 条
- `envelope`（信封）：4 条
- `torn`（撕边）：4 条
- `speech`（对话框）：4 条
- `polaroid`（拍立得）：4 条
- `ticket`（票券）：4 条
- `hexagon`（六边形）：3 条

### 颜色分布

- `#BFDBFE`（Soft blue）：8 条
- `#FEF08A`（Soft yellow）：2 条
- `#BBF7D0`（Soft green）：3 条
- `#FBCFE8`（Soft pink）：2 条
- `#FED7AA`（Soft orange）：2 条
- `#FFF7ED`（Warm cream）：3 条
- `#E9D5FF`（Soft purple）：6 条
- `#CBD5E1`（Grey blue）：5 条
- `#CFFAFE`（Soft cyan）：8 条
- `#FDE68A`（Golden yellow）：3 条

## 4. 照片资产清单

> 当前只完成照片槽位和拍摄规范。除第 28 条有现有来源参考外，其余照片文件仍须拍摄/批准。现有代码只接受安全的 `imageDataUrl` 或 Cloudinary HTTPS URL；不能把普通相对路径直接写入 `imageUrl`。

| Note | 部门 | 资产文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---|---:|
| 3 | Pengajian Am | `seri-jerai-cubic-pa-draft-01.webp` | A4 Pengajian Am draft with a handwritten three-point outline on a consultation desk; no student name visible. | 需拍摄／用户自有摆拍 | `contain` | 1.05 |
| 5 | Sains Komputer | `seri-jerai-cubic-cs-code-01.webp` | Laptop showing generic code and one error message beside handwritten pseudocode; hide accounts, filenames and personal data. | 需拍摄／用户自有摆拍 | `cover` | 1.10 |
| 9 | English | `seri-jerai-cubic-english-script-01.webp` | Printed English presentation script with simple annotations and a pen; no identifiable handwriting or names. | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 12 | Pengurusan Perniagaan | `seri-jerai-cubic-business-case-grid-01.webp` | Notebook table labelled problem, cause and suggestion for a generic business case; no real assignment cover page. | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 18 | Perakaunan | `seri-jerai-cubic-accounting-working-01.webp` | Generic accounting working with coloured markings; remove student name, matric number and lecturer comments. | 需拍摄／用户自有摆拍 | `contain` | 1.05 |
| 24 | Ekonomi | `seri-jerai-cubic-economics-graph-01.webp` | Hand-drawn demand-and-supply graph with clearly labelled axes and arrows; no personal identifiers. | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 28 | Umum CUBIC | `seri-jerai-cubic-location-01.webp` | CUBIC / Bangunan Seri Jerai exterior, corridor or department sign. Crop or blur any recognisable face. | 来源参考可用：school-environment PDF 第8页；导入前需裁切并确认版权/人脸 | `cover` | 1.15 |
| 32 | Biology | `seri-jerai-cubic-biology-diagram-01.webp` | A student-made generic Biology diagram with labels, photographed from above; no name or class code. | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 40 | Physics | `seri-jerai-cubic-physics-force-01.webp` | A clear hand-drawn force diagram beside a pencil and calculator-free working; no personal identifiers. | 需拍摄／用户自有摆拍 | `contain` | 1.00 |

### 照片统一规范

- 画幅：4:3 横向优先。
- 格式：WebP；导入后单张目标不超过 450 KB。
- 不出现清晰学生正脸；无法避免时先裁切或模糊。
- 不展示姓名、学号、邮箱、账号、聊天内容或真实作业封面。
- 为跨设备演示，最终优先使用已批准的 Cloudinary HTTPS URL；不把大量 Base64 图片塞入 localStorage。

## 5. 42 条完整视觉字段

| No. | 楼层/部门 | 显示 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 便贴内容 |
|---:|---|---|---|---|---:|---|---|---|---|
| 1 | Tingkat 1 / Pengajian Am | Alya N.<br>`demo_cubic_001` | `academic` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Kalau mahu jumpa pensyarah Pengajian Am, lebih baik mesej dahulu dan datang dengan soalan yang sudah disusun. Perbincangan jadi jauh lebih cepat. |
| 2 | Tingkat 1 / Pengajian Am | 匿名<br>`demo_cubic_002` | `academic` | `square` | 1° | `#CFFAFE` Soft cyan | 无 | — | Saya selalu tulis tiga isi utama sebelum datang ke CUBIC. Bila berjumpa pensyarah, senang terus semak bahagian yang masih lemah. |
| 3 | Tingkat 1 / Pengajian Am | Daniel T.<br>`demo_cubic_003` | `academic` | `polaroid` | 0° | `#E9D5FF` Soft purple | `seri-jerai-cubic-pa-draft-01.webp` | `contain` / 1.05 | Consultation here helped me turn a very broad Pengajian Am topic into a clearer outline. Bring your draft, not only the question. |
| 4 | Tingkat 1 / Pengajian Am | 匿名<br>`demo_cubic_004` | `academic` | `speech` | 2° | `#CBD5E1` Grey blue | 无 | — | 来问Pengajian Am之前先把资料和题目整理好，不然到了这里只会突然忘记自己要问什么。 |
| 5 | Tingkat 1 / Sains Komputer | Arun K.<br>`demo_cubic_005` | `academic` | `rect` | -1° | `#BFDBFE` Soft blue | `seri-jerai-cubic-cs-code-01.webp` | `cover` / 1.10 | For programming questions, show the exact error and the part of the code you already tried. A screenshot alone is usually not enough. |
| 6 | Tingkat 1 / Sains Komputer | 匿名<br>`demo_cubic_006` | `academic` | `torn` | 3° | `#CFFAFE` Soft cyan | 无 | — | Datang dengan laptop yang sudah dicas. Pernah sekali saya tunggu giliran, tetapi bateri habis sebelum sempat tunjuk masalah kod. |
| 7 | Tingkat 1 / Sains Komputer | Haziq R.<br>`demo_cubic_007` | `academic` | `hexagon` | -2° | `#E9D5FF` Soft purple | 无 | — | Bahagian Sains Komputer paling berguna bila saya bawa pseudokod dan terangkan logik sendiri. Pensyarah boleh nampak terus di mana saya tersilap. |
| 8 | Tingkat 1 / Sains Komputer | 匿名<br>`demo_cubic_008` | `academic` | `envelope` | 1° | `#CBD5E1` Grey blue | 无 | — | 如果是coding问题，最好把完整题目、input、expected output一起带来。只说“不能run”真的很难检查。 |
| 9 | Tingkat 1 / English | Sarah I.<br>`demo_cubic_009` | `academic` | `polaroid` | -1° | `#FBCFE8` Soft pink | `seri-jerai-cubic-english-script-01.webp` | `contain` / 1.00 | I came here to check a presentation script and learned that simpler sentences sounded more confident than complicated vocabulary. |
| 10 | Tingkat 1 / English | 匿名<br>`demo_cubic_010` | `academic` | `ticket` | 2° | `#BFDBFE` Soft blue | 无 | — | Bawa satu perenggan yang sudah ditulis sendiri. Lebih mudah untuk pensyarah tunjuk kesalahan sebenar berbanding meminta contoh umum. |
| 11 | Tingkat 1 / English | Priya S.<br>`demo_cubic_011` | `emotional` | `rounded` | 0° | `#FEF08A` Soft yellow | 无 | — | The English consultation area felt less intimidating than I expected. Asking one small question was enough to start improving my speaking. |
| 12 | Tingkat 1 / Pengurusan Perniagaan | Amirul F.<br>`demo_cubic_012` | `academic` | `torn` | -2° | `#FED7AA` Soft orange | `seri-jerai-cubic-business-case-grid-01.webp` | `contain` / 1.00 | Untuk kajian kes, saya bawa jadual yang membezakan masalah, punca dan cadangan. Pensyarah terus boleh semak sama ada hujah saya masuk akal. |
| 13 | Tingkat 1 / Pengurusan Perniagaan | 匿名<br>`demo_cubic_013` | `academic` | `speech` | 2° | `#E9D5FF` Soft purple | 无 | — | A useful tip: do not memorise management terms without linking them to the case. The consultation here made that weakness very obvious. |
| 14 | Tingkat 1 / Pengurusan Perniagaan | Sofia A.<br>`demo_cubic_014` | `academic` | `rect` | 1° | `#CFFAFE` Soft cyan | 无 | — | Kalau tugasan berkumpulan, datang dengan keputusan yang sudah dipersetujui. Jangan habiskan masa konsultasi untuk berdebat semula sesama ahli. |
| 15 | Tingkat 1 / Pengurusan Perniagaan | 匿名<br>`demo_cubic_015` | `campus_life` | `circle` | -1° | `#FFF7ED` Warm cream | 无 | — | Aras ini agak sibuk sebelum tarikh hantar tugasan. Datang lebih awal supaya tidak perlu menunggu terlalu lama. |
| 16 | Tingkat 1 / Perakaunan | Kavitha R.<br>`demo_cubic_016` | `academic` | `envelope` | 2° | `#BFDBFE` Soft blue | 无 | — | Bring the full working, not only the final balance. The lecturer can usually identify the first wrong entry much faster that way. |
| 17 | Tingkat 1 / Perakaunan | 匿名<br>`demo_cubic_017` | `academic` | `square` | -2° | `#FDE68A` Golden yellow | 无 | — | Saya tandakan transaksi yang tidak pasti dengan pen warna lain sebelum datang. Senang untuk terus fokus pada bahagian yang bermasalah. |
| 18 | Tingkat 1 / Perakaunan | Xin Yi W.<br>`demo_cubic_018` | `academic` | `polaroid` | 0° | `#CFFAFE` Soft cyan | `seri-jerai-cubic-accounting-working-01.webp` | `contain` / 1.05 | 来问会计题时不要只带答案，working一定要完整。很多时候错的不是最后一步，而是前面的classification。 |
| 19 | Tingkat 1 / Perakaunan | 匿名<br>`demo_cubic_019` | `emotional` | `speech` | 1° | `#FBCFE8` Soft pink | 无 | — | Pernah rasa sangat kecewa sebab imbangan tidak sama. Selepas semak satu demi satu di sini, rupanya hanya satu angka tersalah salin. |
| 20 | Tingkat 1 / Matematik Sains dan Akaun | Aiman Q.<br>`demo_cubic_020` | `academic` | `rounded` | -1° | `#BFDBFE` Soft blue | 无 | — | Sebelum konsultasi Matematik, saya bulatkan langkah pertama yang saya tidak faham. Itu lebih membantu daripada membawa satu muka surat yang kosong. |
| 21 | Tingkat 1 / Matematik Sains dan Akaun | 匿名<br>`demo_cubic_021` | `academic` | `hexagon` | 2° | `#E9D5FF` Soft purple | 无 | — | Write down the formula you chose and why. Even when the answer is wrong, the lecturer can still correct the reasoning. |
| 22 | Tingkat 1 / Matematik Sains dan Akaun | Fatin M.<br>`demo_cubic_022` | `academic` | `ticket` | -2° | `#CFFAFE` Soft cyan | 无 | — | Untuk soalan panjang, asingkan maklumat diberi, apa yang dicari dan formula. Cara ini buat sesi semakan lebih tersusun. |
| 23 | Tingkat 1 / Matematik Sains dan Akaun | 匿名<br>`demo_cubic_023` | `academic` | `envelope` | 1° | `#CBD5E1` Grey blue | 无 | — | 数学不会做时先写出你看得懂的部分。完全空白地来问，反而很难知道你卡在哪里。 |
| 24 | Tingkat 1 / Ekonomi | Aqilah S.<br>`demo_cubic_024` | `academic` | `square` | 0° | `#FDE68A` Golden yellow | `seri-jerai-cubic-economics-graph-01.webp` | `contain` / 1.00 | Bila belajar ekonomi, saya bawa graf yang dilukis sendiri. Pensyarah boleh terus semak paksi, label dan arah perubahan. |
| 25 | Tingkat 1 / Ekonomi | 匿名<br>`demo_cubic_025` | `academic` | `rounded` | -1° | `#BFDBFE` Soft blue | 无 | — | The best consultations were the ones where I explained the graph aloud. It exposed the parts I had only memorised. |
| 26 | Tingkat 1 / Ekonomi | Danish P.<br>`demo_cubic_026` | `academic` | `rect` | 2° | `#E9D5FF` Soft purple | 无 | — | Untuk soalan esei, saya sediakan definisi, huraian dan contoh berasingan. Di sini saya baru sedar contoh saya tidak menjawab kehendak soalan. |
| 27 | Tingkat 1 / Umum CUBIC | 匿名<br>`demo_cubic_027` | `campus_life` | `circle` | -2° | `#CBD5E1` Grey blue | 无 | — | Sila bercakap perlahan di koridor kerana banyak bilik pensyarah sedang digunakan untuk perbincangan atau kerja. |
| 28 | Tingkat 1 / Umum CUBIC | Marcus Y.<br>`demo_cubic_028` | `campus_life` | `rect` | 1° | `#FFF7ED` Warm cream | `seri-jerai-cubic-location-01.webp` | `cover` / 1.15 | Check the department sign before knocking. The offices on this floor cover several subjects, so it is easy to stop at the wrong section. |
| 29 | Tingkat 2 / Kokurikulum | Hannah R.<br>`demo_cubic_029` | `campus_life` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | Datang ke bahagian Kokurikulum dengan nama program, tarikh dan dokumen yang lengkap. Urusan jadi lebih mudah apabila maklumat asas sudah jelas. |
| 30 | Tingkat 2 / Kokurikulum | 匿名<br>`demo_cubic_030` | `academic` | `torn` | -1° | `#CFFAFE` Soft cyan | 无 | — | Kalau mahu semak laporan aktiviti, bawa versi yang sudah disusun mengikut bahagian. Jangan tunggu pensyarah menyusun semula semuanya. |
| 31 | Tingkat 2 / Kokurikulum | Ravi P.<br>`demo_cubic_031` | `campus_life` | `circle` | 2° | `#FED7AA` Soft orange | 无 | — | For club matters, note down the person in charge and the exact issue before coming. It prevents repeated trips. |
| 32 | Tingkat 2 / Biology | Emily C.<br>`demo_cubic_032` | `academic` | `polaroid` | 0° | `#BBF7D0` Soft green | `seri-jerai-cubic-biology-diagram-01.webp` | `contain` / 1.00 | For Biology, bring the diagram you drew yourself. It is much easier to correct labels and relationships than to discuss from memory. |
| 33 | Tingkat 2 / Biology | 匿名<br>`demo_cubic_033` | `academic` | `square` | -2° | `#CFFAFE` Soft cyan | 无 | — | Saya guna sticky tab pada halaman nota yang hendak ditanya. Tidak perlu buang masa mencari bab apabila sudah sampai. |
| 34 | Tingkat 2 / Biology | Adam N.<br>`demo_cubic_034` | `academic` | `rounded` | 1° | `#BBF7D0` Soft green | 无 | — | Untuk topik proses biologi, cuba terangkan urutan langkah tanpa melihat nota dahulu. Bahagian yang tersekat itulah yang patut ditanya. |
| 35 | Tingkat 2 / Biology | 匿名<br>`demo_cubic_035` | `emotional` | `speech` | -1° | `#FEF08A` Soft yellow | 无 | — | Biology内容很多，但来这里把一个process慢慢画出来后，感觉没有之前那么乱了。 |
| 36 | Tingkat 2 / Chemistry | Balqis T.<br>`demo_cubic_036` | `academic` | `envelope` | 2° | `#E9D5FF` Soft purple | 无 | — | Bawa persamaan yang sudah cuba diseimbangkan. Pensyarah lebih mudah tunjuk bahagian atom atau cas yang tidak konsisten. |
| 37 | Tingkat 2 / Chemistry | 匿名<br>`demo_cubic_037` | `academic` | `rect` | -1° | `#CFFAFE` Soft cyan | 无 | — | For calculation questions, include units at every step. My mistake was not the formula but an unnoticed unit conversion. |
| 38 | Tingkat 2 / Chemistry | Shreya V.<br>`demo_cubic_038` | `academic` | `hexagon` | 1° | `#BFDBFE` Soft blue | 无 | — | Semasa bertanya tentang eksperimen, saya tulis pemerhatian sebenar dahulu dan asingkan daripada kesimpulan. Itu mengelakkan jawapan bercampur. |
| 39 | Tingkat 2 / Chemistry | 匿名<br>`demo_cubic_039` | `campus_life` | `ticket` | -2° | `#FFF7ED` Warm cream | 无 | — | Aras dua boleh menjadi sesak selepas kelas amali. Kalau urusan tidak mendesak, pilih waktu yang lebih tenang. |
| 40 | Tingkat 2 / Physics | Lee Ann P.<br>`demo_cubic_040` | `academic` | `torn` | 0° | `#CBD5E1` Grey blue | `seri-jerai-cubic-physics-force-01.webp` | `contain` / 1.00 | Draw the force diagram before asking for help. Even an imperfect diagram gives the lecturer something concrete to correct. |
| 41 | Tingkat 2 / Physics | 匿名<br>`demo_cubic_041` | `academic` | `square` | 2° | `#FDE68A` Golden yellow | 无 | — | Saya selalu semak tanda positif dan negatif sebelum datang. Banyak kesilapan fizik saya sebenarnya berpunca daripada arah yang tidak konsisten. |
| 42 | Tingkat 2 / Physics | Thivya M.<br>`demo_cubic_042` | `academic` | `rounded` | -1° | `#BFDBFE` Soft blue | 无 | — | Untuk soalan pengiraan, tulis andaian yang digunakan. Kadang-kadang jawapan berbeza kerana kita memilih arah atau rujukan yang berlainan. |

## 6. Codex 导入契约

- 本文件确认前，不得改网站。
- `contextType: "building"`、`placeId: "B_SERI_JERAI"`。
- 内部元数据保留 `internalArea: "CUBIC"`；若当前 schema 不支持该字段，先报告，不得自行改架构。
- 使用本表指定的 `shape`、`color`、`rotation`，不得重新随机。
- 匿名便贴：`authorNickname: null`；具名便贴使用表内显示名。
- 所有演示用户：`isDemoSeed: true`、`role: "user"`。
- 照片 URL 未批准前，不得填虚假 Cloudinary URL，也不得使用普通相对路径冒充可用图片。
- 不自动 commit、push、创建 PR 或改写 Git 历史。

## 7. 验收与测试

- 42 条便贴全部归入 `B_SERI_JERAI`。
- 9 条照片便贴与对应 note 编号一致。
- 10 种形状和 10 种颜色全部至少出现一次。
- 刷新及新设备首次打开不会重复插入。
- 页面不显示内部邮箱、用户 ID、`isDemoSeed` 或资产管理字段。
- 带照片便贴在卡片与详情中保持相同颜色、形状、fit 和 crop scale。
- 不把演示数据表述成真实注册、真实试用或真实用户反馈。

## 8. 停止条件与回滚

- 找不到 `B_SERI_JERAI`、字段不兼容、照片 URL 未批准、种子不幂等或页面明显卡顿时立即停止。
- 回滚只删除本批 `isDemoSeed: true` 的 42 条便贴及对应演示用户。
- 不删除原有真实用户留言，不改变管理员或认证架构。
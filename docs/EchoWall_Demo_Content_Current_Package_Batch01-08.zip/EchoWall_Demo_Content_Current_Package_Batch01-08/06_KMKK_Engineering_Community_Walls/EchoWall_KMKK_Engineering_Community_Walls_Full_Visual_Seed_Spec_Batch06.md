# EchoWall KMKK 工程社区留言墙视觉配置完整版

## 批次 06：Kolej Matrikulasi Kejuruteraan Kedah（KMKK）

> 状态：4个community walls、168条便贴、72个虚构演示用户、32个照片槽位，以及全部形状/颜色配置已完成；尚未导入网站。

## 1. 总体判断

- 任务类型：`DOC + DATA`
- 风险等级：`L2`
- 变更规模：`S2`（4个相关community walls）
- 准备状态：`READY`
- 执行模式：`STANDARD`
- 工具：当前使用Chat生成与审核；全部学院内容完成后再交Codex导入。

## 2. 网站映射

- 机构：**KMKK**；`orgId: 2`
- Community wall按`orgId + majorId`过滤，不按batch拆成重复留言墙。

| Major ID | 社区留言墙 | 便贴 | 照片槽位 |
|---:|---|---:|---:|
| 4 | Asas Kejuruteraan | 42 | 8 |
| 5 | Kejuruteraan Awam | 42 | 8 |
| 6 | Kejuruteraan Mekanikal | 42 | 8 |
| 7 | Kejuruteraan Elektrik & Elektronik | 42 | 8 |

## 3. 内容边界

- 内容围绕工程基础学习、问题拆解、图示、计算、设计沟通、低风险实践与复习经验。
- 不编造KMKK特定建筑、讲师、实验室设备、开放时间、课程规则或真实学生经历。
- 具体课程、实验、安全程序及考核要求必须以学院和讲师正式资料为准。
- 所有用户、姓名、邮箱和留言均为虚构演示数据；不得宣称为真实注册、真实采用或真实学生反馈。

## 4. 学院级数据摘要

- Community walls：4
- 便贴：168（每墙42）
- 每墙具名23、匿名19
- 每墙BM 24、English 13、中文5
- 演示用户：72；每人出现1–4次，同一墙最多一次
- 照片槽位：32（每墙8，约19.0%）
- 每墙均使用全部10种现有形状和全部10个颜色预设

## 5. KMKK演示注册用户池

> 所有账户必须设为`isDemoSeed: true`、`role: user`。`.invalid`邮箱不可用于真实投递。匿名便贴仍保留内部authorUserId。

| User ID | 显示名 | 演示邮箱 | Primary major | Batch | 使用次数 |
|---|---|---|---|---:|---:|
| `demo_kmkk_001` | Amani K. | `kmkk.demo.001@echowall.invalid` | Asas Kejuruteraan | 1 | 2 |
| `demo_kmkk_002` | Aqeel J. | `kmkk.demo.002@echowall.invalid` | Asas Kejuruteraan | 2 | 2 |
| `demo_kmkk_003` | Balraj S. | `kmkk.demo.003@echowall.invalid` | Asas Kejuruteraan | 3 | 2 |
| `demo_kmkk_004` | Celine W. | `kmkk.demo.004@echowall.invalid` | Asas Kejuruteraan | 1 | 2 |
| `demo_kmkk_005` | Dzulhilmi F. | `kmkk.demo.005@echowall.invalid` | Asas Kejuruteraan | 2 | 2 |
| `demo_kmkk_006` | Elissa T. | `kmkk.demo.006@echowall.invalid` | Asas Kejuruteraan | 3 | 2 |
| `demo_kmkk_007` | Fadlan R. | `kmkk.demo.007@echowall.invalid` | Asas Kejuruteraan | 1 | 2 |
| `demo_kmkk_008` | Gauri N. | `kmkk.demo.008@echowall.invalid` | Asas Kejuruteraan | 2 | 2 |
| `demo_kmkk_009` | Hakeem B. | `kmkk.demo.009@echowall.invalid` | Asas Kejuruteraan | 3 | 3 |
| `demo_kmkk_010` | Insyirah P. | `kmkk.demo.010@echowall.invalid` | Asas Kejuruteraan | 1 | 3 |
| `demo_kmkk_011` | Jovan M. | `kmkk.demo.011@echowall.invalid` | Asas Kejuruteraan | 2 | 3 |
| `demo_kmkk_012` | Kausalya V. | `kmkk.demo.012@echowall.invalid` | Asas Kejuruteraan | 3 | 3 |
| `demo_kmkk_013` | Maizura H. | `kmkk.demo.013@echowall.invalid` | Asas Kejuruteraan | 1 | 3 |
| `demo_kmkk_014` | Naufal D. | `kmkk.demo.014@echowall.invalid` | Asas Kejuruteraan | 2 | 3 |
| `demo_kmkk_015` | Orked L. | `kmkk.demo.015@echowall.invalid` | Asas Kejuruteraan | 3 | 3 |
| `demo_kmkk_016` | Paramesh C. | `kmkk.demo.016@echowall.invalid` | Asas Kejuruteraan | 1 | 3 |
| `demo_kmkk_017` | Qalisha Y. | `kmkk.demo.017@echowall.invalid` | Asas Kejuruteraan | 2 | 1 |
| `demo_kmkk_018` | Rafiq Z. | `kmkk.demo.018@echowall.invalid` | Asas Kejuruteraan | 3 | 1 |
| `demo_kmkk_019` | Shalini E. | `kmkk.demo.019@echowall.invalid` | Kejuruteraan Awam | 1 | 2 |
| `demo_kmkk_020` | Tarmizi A. | `kmkk.demo.020@echowall.invalid` | Kejuruteraan Awam | 2 | 2 |
| `demo_kmkk_021` | Umairah G. | `kmkk.demo.021@echowall.invalid` | Kejuruteraan Awam | 3 | 2 |
| `demo_kmkk_022` | Vinesh O. | `kmkk.demo.022@echowall.invalid` | Kejuruteraan Awam | 1 | 2 |
| `demo_kmkk_023` | Wafiq U. | `kmkk.demo.023@echowall.invalid` | Kejuruteraan Awam | 2 | 2 |
| `demo_kmkk_024` | Xiu Ying K. | `kmkk.demo.024@echowall.invalid` | Kejuruteraan Awam | 3 | 2 |
| `demo_kmkk_025` | Yusri I. | `kmkk.demo.025@echowall.invalid` | Kejuruteraan Awam | 1 | 2 |
| `demo_kmkk_026` | Zulaikha Q. | `kmkk.demo.026@echowall.invalid` | Kejuruteraan Awam | 2 | 2 |
| `demo_kmkk_027` | Abinesh R. | `kmkk.demo.027@echowall.invalid` | Kejuruteraan Awam | 3 | 3 |
| `demo_kmkk_028` | Batrisyia J. | `kmkk.demo.028@echowall.invalid` | Kejuruteraan Awam | 1 | 3 |
| `demo_kmkk_029` | Calvin H. | `kmkk.demo.029@echowall.invalid` | Kejuruteraan Awam | 2 | 3 |
| `demo_kmkk_030` | Dayana M. | `kmkk.demo.030@echowall.invalid` | Kejuruteraan Awam | 3 | 3 |
| `demo_kmkk_031` | Eshan P. | `kmkk.demo.031@echowall.invalid` | Kejuruteraan Awam | 1 | 3 |
| `demo_kmkk_032` | Ghazali T. | `kmkk.demo.032@echowall.invalid` | Kejuruteraan Awam | 2 | 3 |
| `demo_kmkk_033` | Hema L. | `kmkk.demo.033@echowall.invalid` | Kejuruteraan Awam | 3 | 3 |
| `demo_kmkk_034` | Izzuddin S. | `kmkk.demo.034@echowall.invalid` | Kejuruteraan Awam | 1 | 3 |
| `demo_kmkk_035` | Jayden V. | `kmkk.demo.035@echowall.invalid` | Kejuruteraan Awam | 2 | 1 |
| `demo_kmkk_036` | Kirana N. | `kmkk.demo.036@echowall.invalid` | Kejuruteraan Awam | 3 | 1 |
| `demo_kmkk_037` | Low Wei C. | `kmkk.demo.037@echowall.invalid` | Kejuruteraan Mekanikal | 1 | 3 |
| `demo_kmkk_038` | Mardiana F. | `kmkk.demo.038@echowall.invalid` | Kejuruteraan Mekanikal | 2 | 3 |
| `demo_kmkk_039` | Nazmi W. | `kmkk.demo.039@echowall.invalid` | Kejuruteraan Mekanikal | 3 | 3 |
| `demo_kmkk_040` | Odelia B. | `kmkk.demo.040@echowall.invalid` | Kejuruteraan Mekanikal | 1 | 3 |
| `demo_kmkk_041` | Previn K. | `kmkk.demo.041@echowall.invalid` | Kejuruteraan Mekanikal | 2 | 3 |
| `demo_kmkk_042` | Qaireen D. | `kmkk.demo.042@echowall.invalid` | Kejuruteraan Mekanikal | 3 | 3 |
| `demo_kmkk_043` | Ramesh Y. | `kmkk.demo.043@echowall.invalid` | Kejuruteraan Mekanikal | 1 | 3 |
| `demo_kmkk_044` | Suraya O. | `kmkk.demo.044@echowall.invalid` | Kejuruteraan Mekanikal | 2 | 3 |
| `demo_kmkk_045` | Thaqif H. | `kmkk.demo.045@echowall.invalid` | Kejuruteraan Mekanikal | 3 | 2 |
| `demo_kmkk_046` | Umesh J. | `kmkk.demo.046@echowall.invalid` | Kejuruteraan Mekanikal | 1 | 2 |
| `demo_kmkk_047` | Vivian Q. | `kmkk.demo.047@echowall.invalid` | Kejuruteraan Mekanikal | 2 | 2 |
| `demo_kmkk_048` | Wanis A. | `kmkk.demo.048@echowall.invalid` | Kejuruteraan Mekanikal | 3 | 2 |
| `demo_kmkk_049` | Xander G. | `kmkk.demo.049@echowall.invalid` | Kejuruteraan Mekanikal | 1 | 2 |
| `demo_kmkk_050` | Yasirah T. | `kmkk.demo.050@echowall.invalid` | Kejuruteraan Mekanikal | 2 | 2 |
| `demo_kmkk_051` | Zhen Yu L. | `kmkk.demo.051@echowall.invalid` | Kejuruteraan Mekanikal | 3 | 2 |
| `demo_kmkk_052` | Adlina S. | `kmkk.demo.052@echowall.invalid` | Kejuruteraan Mekanikal | 1 | 2 |
| `demo_kmkk_053` | Boon Kiat M. | `kmkk.demo.053@echowall.invalid` | Kejuruteraan Mekanikal | 2 | 1 |
| `demo_kmkk_054` | Cyrene P. | `kmkk.demo.054@echowall.invalid` | Kejuruteraan Mekanikal | 3 | 1 |
| `demo_kmkk_055` | Diyanah V. | `kmkk.demo.055@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 1 | 3 |
| `demo_kmkk_056` | Ehsan N. | `kmkk.demo.056@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 2 | 3 |
| `demo_kmkk_057` | Faeza C. | `kmkk.demo.057@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 3 | 3 |
| `demo_kmkk_058` | Gokul R. | `kmkk.demo.058@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 1 | 3 |
| `demo_kmkk_059` | Hidayah K. | `kmkk.demo.059@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 2 | 3 |
| `demo_kmkk_060` | Ilham Z. | `kmkk.demo.060@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 3 | 3 |
| `demo_kmkk_061` | Jacintha E. | `kmkk.demo.061@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 1 | 3 |
| `demo_kmkk_062` | Khairi U. | `kmkk.demo.062@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 2 | 3 |
| `demo_kmkk_063` | Lavanya I. | `kmkk.demo.063@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 3 | 2 |
| `demo_kmkk_064` | Muhaimin B. | `kmkk.demo.064@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 1 | 2 |
| `demo_kmkk_065` | Nandini J. | `kmkk.demo.065@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 2 | 2 |
| `demo_kmkk_066` | Othman F. | `kmkk.demo.066@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 3 | 2 |
| `demo_kmkk_067` | Pavithra W. | `kmkk.demo.067@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 1 | 2 |
| `demo_kmkk_068` | Qamarina H. | `kmkk.demo.068@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 2 | 2 |
| `demo_kmkk_069` | Roshan D. | `kmkk.demo.069@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 3 | 2 |
| `demo_kmkk_070` | Salwa Y. | `kmkk.demo.070@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 1 | 2 |
| `demo_kmkk_071` | Tze Wei O. | `kmkk.demo.071@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 2 | 1 |
| `demo_kmkk_072` | Zubair A. | `kmkk.demo.072@echowall.invalid` | Kejuruteraan Elektrik & Elektronik | 3 | 1 |

## 6. Asas Kejuruteraan（majorId 4）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 2 + majorId`的community wall，不创建建筑或地图地点。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmkk-asas-study-plan-01.webp` | 工程基础学习计划、数学和物理笔记的桌面摆拍；不显示真实姓名或课程账号。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 8 | `kmkk-asas-free-body-sketch-01.webp` | 通用free-body diagram与单位检查笔记，不使用真实测验题。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 15 | `kmkk-asas-technical-sketch-01.webp` | 简单机械或结构概念草图、尺和铅笔；不声称为正式设计。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 20 | `kmkk-asas-design-iteration-drafts-01.webp` | 同一设计的两到三个草图版本和简短修改原因，表现保留迭代记录。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 25 | `kmkk-asas-idea-decision-log-01.webp` | 小组“想法／决定／待验证”三栏记录，不出现真实成员资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 30 | `kmkk-asas-symbolic-working-01.webp` | 先写符号关系再代入数字的通用工程计算working，不使用正式考题。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 35 | `kmkk-asas-corrected-example-01.webp` | 一题已订正的通用工程基础例题，标出原错误与正确理由。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 40 | `kmkk-asas-community-resource-card-01.webp` | 学习资源卡片附一行“为何有帮助”的说明，不展示真实群聊或账户。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |

### 42条完整视觉字段

| No. | 分区 | 语言 | 显示 | 用户 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---|---|---|---|---|---:|---|---|---|---|
| 1 | Orientation & Engineering Mindset | ms | Amani K. | `demo_kmkk_001` | `academic` | `polaroid` | -2° | `#BFDBFE` Soft blue | `kmkk-asas-study-plan-01.webp` | `contain` / 1.02 | Pada minggu awal, cuba fahami cara setiap subjek saling berkait. Matematik, fizik dan lakaran bukan topik berasingan apabila digunakan untuk menyelesaikan masalah kejuruteraan. |
| 2 | Orientation & Engineering Mindset | ms | 匿名 | `demo_kmkk_002` | `academic` | `rounded` | 1° | `#FEF08A` Soft yellow | 无 | — | Simpan satu senarai istilah teknikal yang baru ditemui. Tulis maksud, simbol dan satu contoh supaya tidak hanya menghafal perkataan. |
| 3 | Orientation & Engineering Mindset | en | Balraj S. | `demo_kmkk_003` | `academic` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | Engineering becomes easier to approach when a large problem is divided into assumptions, known values, unknown values and a checking step. |
| 4 | Orientation & Engineering Mindset | zh | 匿名 | `demo_kmkk_004` | `academic` | `square` | 2° | `#FBCFE8` Soft pink | 无 | — | 刚开始读工程基础时，不需要马上知道自己最适合哪一个分支。先观察自己比较喜欢计算、设计、实验还是故障分析。 |
| 5 | Orientation & Engineering Mindset | ms | Dzulhilmi F. | `demo_kmkk_005` | `academic` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Gunakan unit dan simbol dengan konsisten sejak awal. Tabiat kecil ini mengurangkan banyak kesilapan apabila soalan menjadi lebih panjang. |
| 6 | Orientation & Engineering Mindset | en | 匿名 | `demo_kmkk_006` | `academic` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | Do not compare only final answers. Compare the model, assumptions and method used to reach the answer. |
| 7 | Orientation & Engineering Mindset | ms | Fadlan R. | `demo_kmkk_007` | `academic` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Selepas setiap kelas, tulis satu ayat tentang bagaimana topik itu boleh digunakan dalam situasi sebenar. Ini membantu konsep kekal lebih lama. |
| 8 | Mathematics & Physics Foundation | ms | Gauri N. | `demo_kmkk_008` | `academic` | `envelope` | 2° | `#CBD5E1` Grey blue | `kmkk-asas-free-body-sketch-01.webp` | `contain` / 1.00 | Untuk soalan pengiraan, asingkan maklumat diberi, perkara yang dicari dan formula yang mungkin sesuai sebelum menggantikan nombor. |
| 9 | Mathematics & Physics Foundation | ms | 匿名 | `demo_kmkk_009` | `academic` | `torn` | 0° | `#CFFAFE` Soft cyan | 无 | — | Jika jawapan kelihatan pelik, semak unit dan anggaran saiz dahulu. Kadang-kadang formula betul tetapi penukaran unit tersilap. |
| 10 | Mathematics & Physics Foundation | en | Insyirah P. | `demo_kmkk_010` | `academic` | `circle` | -1° | `#FDE68A` Golden yellow | 无 | — | Sketching the situation before calculating often reveals directions, constraints and missing information that are not obvious in the text. |
| 11 | Mathematics & Physics Foundation | zh | 匿名 | `demo_kmkk_011` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | 做物理题时先画图和标方向。答案算错不一定是公式问题，也可能是正负号和参考方向不一致。 |
| 12 | Mathematics & Physics Foundation | ms | Kausalya V. | `demo_kmkk_012` | `academic` | `polaroid` | -2° | `#E9D5FF` Soft purple | 无 | — | Bina satu halaman formula sendiri dengan penerangan ringkas tentang bila formula itu boleh digunakan, bukan sekadar menyalin simbol. |
| 13 | Mathematics & Physics Foundation | en | 匿名 | `demo_kmkk_013` | `academic` | `square` | 1° | `#CBD5E1` Grey blue | 无 | — | When using a calculator, estimate the expected order of magnitude first. It makes an accidental key press easier to notice. |
| 14 | Mathematics & Physics Foundation | ms | Naufal D. | `demo_kmkk_014` | `academic` | `ticket` | 0° | `#FED7AA` Soft orange | 无 | — | Ulang soalan yang pernah salah selepas beberapa hari tanpa melihat jawapan. Jika masih tersangkut, konsep itu belum benar-benar kukuh. |
| 15 | Technical Sketching & Communication | ms | Orked L. | `demo_kmkk_015` | `academic` | `speech` | -1° | `#FFF7ED` Warm cream | `kmkk-asas-technical-sketch-01.webp` | `contain` / 1.02 | Lakaran awal tidak perlu cantik, tetapi mesti jelas menunjukkan bentuk, ukuran penting dan idea utama yang hendak diterangkan. |
| 16 | Technical Sketching & Communication | ms | 匿名 | `demo_kmkk_016` | `academic` | `rect` | 2° | `#CFFAFE` Soft cyan | 无 | — | Gunakan garisan, anak panah dan label secara konsisten. Lakaran yang kemas memudahkan ahli kumpulan memahami cadangan tanpa penerangan panjang. |
| 17 | Technical Sketching & Communication | en | Qalisha Y. | `demo_kmkk_017` | `academic` | `hexagon` | -2° | `#FDE68A` Golden yellow | 无 | — | A technical explanation should state the purpose, the main constraint and the reason for choosing a particular option. |
| 18 | Technical Sketching & Communication | zh | 匿名 | `demo_kmkk_018` | `academic` | `envelope` | 1° | `#BBF7D0` Soft green | 无 | — | 工程草图最重要的是让别人看懂。线条、尺寸和标注清楚，比加入太多装饰更有用。 |
| 19 | Technical Sketching & Communication | ms | Shalini E. | `demo_kmkk_019` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Sebelum membentang, cuba terangkan reka bentuk dalam satu minit. Bahagian yang sukar diterangkan biasanya masih belum jelas. |
| 20 | Technical Sketching & Communication | en | 匿名 | `demo_kmkk_020` | `academic` | `torn` | -1° | `#BFDBFE` Soft blue | `kmkk-asas-design-iteration-drafts-01.webp` | `contain` / 1.02 | Keep draft versions instead of overwriting everything. Comparing iterations shows how the idea improved and why changes were made. |
| 21 | Technical Sketching & Communication | ms | Umairah G. | `demo_kmkk_021` | `academic` | `polaroid` | 2° | `#E9D5FF` Soft purple | 无 | — | Apabila menerima komen, catat keputusan yang perlu dibuat. Jangan ubah reka bentuk hanya kerana komen itu kedengaran yakin. |
| 22 | Design Process & Teamwork | ms | Vinesh O. | `demo_kmkk_022` | `campus_life` | `circle` | -2° | `#CBD5E1` Grey blue | 无 | — | Mulakan projek dengan menyatakan masalah pengguna secara khusus. Penyelesaian yang baik sukar dibina jika masalah terlalu umum. |
| 23 | Design Process & Teamwork | ms | 匿名 | `demo_kmkk_023` | `campus_life` | `square` | 1° | `#CFFAFE` Soft cyan | 无 | — | Bahagikan tugas mengikut hasil yang boleh diperiksa, bukan hanya mengikut nama ahli. Setiap orang perlu tahu apa yang mesti siap. |
| 24 | Design Process & Teamwork | en | Xiu Ying K. | `demo_kmkk_024` | `campus_life` | `ticket` | 0° | `#FEF08A` Soft yellow | 无 | — | Before building anything, agree on the criteria for success. A prototype cannot be judged fairly when the team has no shared target. |
| 25 | Design Process & Teamwork | zh | 匿名 | `demo_kmkk_025` | `campus_life` | `rect` | -1° | `#FED7AA` Soft orange | `kmkk-asas-idea-decision-log-01.webp` | `contain` / 1.00 | 小组讨论时把“想法”和“决定”分开记录。很多冲突其实是大家以为一个建议已经被确定了。 |
| 26 | Design Process & Teamwork | ms | Zulaikha Q. | `demo_kmkk_026` | `campus_life` | `speech` | 2° | `#FFF7ED` Warm cream | 无 | — | Gunakan prototaip paling ringkas untuk menguji satu andaian. Tidak semua idea memerlukan model yang lengkap pada percubaan pertama. |
| 27 | Design Process & Teamwork | en | 匿名 | `demo_kmkk_037` | `campus_life` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | When a test fails, record the conditions and result before changing the design. Otherwise the team may repeat the same mistake. |
| 28 | Design Process & Teamwork | ms | Mardiana F. | `demo_kmkk_038` | `campus_life` | `hexagon` | 1° | `#E9D5FF` Soft purple | 无 | — | Akhiri mesyuarat dengan tiga perkara: siapa buat apa, bila perlu siap dan bukti apa yang perlu dibawa pada pertemuan seterusnya. |
| 29 | Assessment & Revision | ms | Nazmi W. | `demo_kmkk_039` | `academic` | `envelope` | 0° | `#CBD5E1` Grey blue | 无 | — | Susun latihan mengikut jenis kesilapan seperti unit, arah, algebra dan konsep. Corak kesilapan lebih berguna daripada jumlah markah sahaja. |
| 30 | Assessment & Revision | ms | 匿名 | `demo_kmkk_040` | `academic` | `polaroid` | -1° | `#CFFAFE` Soft cyan | `kmkk-asas-symbolic-working-01.webp` | `contain` / 1.00 | Jangan ulang kaji hanya dengan membaca nota. Cuba bina semula langkah penyelesaian dan terangkan sebab bagi setiap langkah. |
| 31 | Assessment & Revision | en | Previn K. | `demo_kmkk_041` | `academic` | `torn` | 2° | `#FDE68A` Golden yellow | 无 | — | Timed practice is useful only after the method is understood. Speeding up a confused process usually creates more errors. |
| 32 | Assessment & Revision | zh | 匿名 | `demo_kmkk_042` | `academic` | `circle` | -2° | `#BBF7D0` Soft green | 无 | — | 复习工程基础时，可以把一题完整做完，再用不同颜色检查单位、假设和最后答案是否合理。 |
| 33 | Assessment & Revision | ms | Ramesh Y. | `demo_kmkk_043` | `academic` | `square` | 1° | `#FBCFE8` Soft pink | 无 | — | Sediakan satu senarai soalan yang masih belum selesai untuk ditanya dalam tutorial. Jangan berharap semua kekeliruan hilang sendiri. |
| 34 | Assessment & Revision | en | 匿名 | `demo_kmkk_044` | `academic` | `rounded` | 0° | `#FED7AA` Soft orange | 无 | — | After a test, rewrite one difficult question from memory and solve it again. This turns the assessment into usable revision material. |
| 35 | Assessment & Revision | ms | Diyanah V. | `demo_kmkk_055` | `academic` | `ticket` | -1° | `#FFF7ED` Warm cream | `kmkk-asas-corrected-example-01.webp` | `contain` / 1.02 | Pada minggu peperiksaan, utamakan tidur dan rancangan belajar yang boleh dilakukan. Jadual terlalu padat biasanya tidak bertahan lama. |
| 36 | Pathway, Wellbeing & Community | ms | 匿名 | `demo_kmkk_056` | `emotional` | `speech` | 2° | `#BFDBFE` Soft blue | 无 | — | Tidak pasti memilih cabang kejuruteraan adalah perkara biasa. Perhatikan jenis tugasan yang membuat anda ingin tahu lebih lama. |
| 37 | Pathway, Wellbeing & Community | ms | Faeza C. | `demo_kmkk_057` | `emotional` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Ask students from different streams about the work they actually do, but remember that one person’s experience is not the whole programme. |
| 38 | Pathway, Wellbeing & Community | en | 匿名 | `demo_kmkk_058` | `emotional` | `hexagon` | 1° | `#CBD5E1` Grey blue | 无 | — | Rasa lambat memahami satu topik tidak bermaksud tidak sesuai dengan kejuruteraan. Cari bahagian kecil yang boleh dikuasai dahulu. |
| 39 | Pathway, Wellbeing & Community | en | Hidayah K. | `demo_kmkk_059` | `emotional` | `envelope` | 0° | `#CFFAFE` Soft cyan | 无 | — | Share useful resources with a short explanation of why they helped. A link without context is easy to ignore. |
| 40 | Pathway, Wellbeing & Community | ms | 匿名 | `demo_kmkk_060` | `emotional` | `polaroid` | -1° | `#FDE68A` Golden yellow | `kmkk-asas-community-resource-card-01.webp` | `contain` / 1.00 | Ambil rehat apabila fikiran mula mengulang kesilapan yang sama. Kembali dengan satu sasaran kecil lebih baik daripada memaksa diri tanpa fokus. |
| 41 | Pathway, Wellbeing & Community | en | Jacintha E. | `demo_kmkk_061` | `emotional` | `torn` | 2° | `#BBF7D0` Soft green | 无 | — | Engineering communities improve when questions are specific and responses explain reasoning instead of giving only the final answer. |
| 42 | Pathway, Wellbeing & Community | ms | 匿名 | `demo_kmkk_062` | `emotional` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Sebelum memberi nasihat, bezakan pengalaman sendiri daripada peraturan rasmi. Hal kursus dan penilaian mesti dirujuk kepada pensyarah atau kolej. |

## 7. Kejuruteraan Awam（majorId 5）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 2 + majorId`的community wall，不创建建筑或地图地点。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmkk-awam-force-diagram-01.webp` | 梁或简单结构的通用受力图与支撑符号，不使用真实工程图。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 8 | `kmkk-awam-load-path-model-01.webp` | 纸板或木条小模型，示意load path；明确为教学模型。 | 需拍摄／用户自有摆拍 | `cover` | 1.08 |
| 15 | `kmkk-awam-scale-drawing-01.webp` | 带比例、尺寸和标题栏的虚构工程草图，不使用真实场地数据。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 20 | `kmkk-awam-site-sketch-assumptions-01.webp` | 虚构场地草图，清楚区分measured与assumed values，不使用真实地点数据。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 25 | `kmkk-awam-project-criteria-01.webp` | 安全、材料、使用和维护四栏的设计比较表。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 30 | `kmkk-awam-equilibrium-working-01.webp` | 通用静力计算working，单位与正负方向清晰，不使用正式考题。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 35 | `kmkk-awam-revision-errors-01.webp` | 受力图、单位、代数、概念四类错题清单。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 40 | `kmkk-awam-site-permission-checklist-01.webp` | 测量、拍摄与进入区域前的许可检查清单，不展示真实场地或受限资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |

### 42条完整视觉字段

| No. | 分区 | 语言 | 显示 | 用户 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---|---|---|---|---|---:|---|---|---|---|
| 1 | Statics & Force Diagrams | ms | Shalini E. | `demo_kmkk_019` | `academic` | `polaroid` | -2° | `#BFDBFE` Soft blue | `kmkk-awam-force-diagram-01.webp` | `contain` / 1.00 | Sebelum mengira, lukis objek yang dikaji dan tunjuk semua daya yang diketahui. Gambar rajah daya bebas yang lengkap mengurangkan kesilapan tanda. |
| 2 | Statics & Force Diagrams | ms | 匿名 | `demo_kmkk_020` | `academic` | `rounded` | 1° | `#FEF08A` Soft yellow | 无 | — | Pilih arah positif dan kekalkan pilihan itu hingga akhir. Menukar arah di tengah pengiraan boleh menghasilkan jawapan yang kelihatan betul tetapi tidak konsisten. |
| 3 | Statics & Force Diagrams | en | Umairah G. | `demo_kmkk_021` | `academic` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | Check whether every force has a clear point of application and direction before writing equilibrium equations. |
| 4 | Statics & Force Diagrams | zh | 匿名 | `demo_kmkk_022` | `academic` | `square` | 2° | `#FBCFE8` Soft pink | 无 | — | 做静力题时先分清物体、支点和外力。图画得太复杂时，可以重新画一个只保留必要信息的free-body diagram。 |
| 5 | Statics & Force Diagrams | ms | Wafiq U. | `demo_kmkk_023` | `academic` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Jika reaksi sokongan tidak diketahui, tandakan simbol dahulu dan selesaikan secara sistematik. Jangan meneka arah akhir tanpa semakan. |
| 6 | Statics & Force Diagrams | en | 匿名 | `demo_kmkk_024` | `academic` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | A negative result can simply mean the real direction is opposite to the assumed direction. It is not automatically a failed calculation. |
| 7 | Statics & Force Diagrams | ms | Yusri I. | `demo_kmkk_025` | `academic` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Selepas mendapat jawapan, gantikan semula ke dalam persamaan keseimbangan untuk memastikan jumlah daya dan momen konsisten. |
| 8 | Structures & Material Behaviour | ms | Zulaikha Q. | `demo_kmkk_026` | `academic` | `envelope` | 2° | `#CBD5E1` Grey blue | `kmkk-awam-load-path-model-01.webp` | `cover` / 1.08 | Apabila membandingkan bentuk struktur, fikirkan laluan beban dari tempat daya dikenakan hingga ke sokongan. |
| 9 | Structures & Material Behaviour | ms | 匿名 | `demo_kmkk_027` | `academic` | `torn` | 0° | `#CFFAFE` Soft cyan | 无 | — | Bezakan pemerhatian tentang bahan daripada andaian. Warna atau rupa sahaja tidak cukup untuk menentukan sifat mekanikal. |
| 10 | Structures & Material Behaviour | en | Batrisyia J. | `demo_kmkk_028` | `academic` | `circle` | -1° | `#FDE68A` Golden yellow | 无 | — | A strong-looking member may still be inefficient if its shape does not place material where stress is greatest. |
| 11 | Structures & Material Behaviour | zh | 匿名 | `demo_kmkk_029` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | 讨论结构时不要只说“这个比较坚固”。说明受力方向、支撑方式和可能发生的变形会更有意义。 |
| 12 | Structures & Material Behaviour | ms | Dayana M. | `demo_kmkk_030` | `academic` | `polaroid` | -2° | `#E9D5FF` Soft purple | 无 | — | Catat keadaan sempadan apabila melihat contoh struktur. Sokongan yang berbeza boleh mengubah tindak balas walaupun bentuknya sama. |
| 13 | Structures & Material Behaviour | en | 匿名 | `demo_kmkk_031` | `academic` | `square` | 1° | `#CBD5E1` Grey blue | 无 | — | When reading a material table, record the units and testing conditions. Numbers from different sources may not be directly comparable. |
| 14 | Structures & Material Behaviour | ms | Ghazali T. | `demo_kmkk_032` | `academic` | `ticket` | 0° | `#FED7AA` Soft orange | 无 | — | Gunakan model kecil untuk melihat corak lenturan atau kestabilan, tetapi jangan mendakwa model itu mewakili bangunan sebenar tanpa skala dan analisis. |
| 15 | Measurement, Drawing & Scale | ms | Hema L. | `demo_kmkk_033` | `academic` | `speech` | -1° | `#FFF7ED` Warm cream | `kmkk-awam-scale-drawing-01.webp` | `contain` / 1.02 | Tulis unit pada setiap ukuran dan nyatakan skala dengan jelas. Lukisan tanpa skala yang diketahui mudah disalah tafsir. |
| 16 | Measurement, Drawing & Scale | ms | 匿名 | `demo_kmkk_034` | `academic` | `rect` | 2° | `#CFFAFE` Soft cyan | 无 | — | Semak satu dimensi rujukan sebelum menggunakan semua ukuran daripada lakaran atau imej. Kesilapan awal boleh tersebar ke seluruh pengiraan. |
| 17 | Measurement, Drawing & Scale | en | Jayden V. | `demo_kmkk_035` | `academic` | `hexagon` | -2° | `#FDE68A` Golden yellow | 无 | — | A dimension should be placed where it can be read without guessing which line or feature it belongs to. |
| 18 | Measurement, Drawing & Scale | zh | 匿名 | `demo_kmkk_036` | `academic` | `envelope` | 1° | `#BBF7D0` Soft green | 无 | — | 工程图里的尺寸不要重复标得太多。重复数据一旦不一致，反而不知道哪一个才是正确版本。 |
| 19 | Measurement, Drawing & Scale | ms | Amani K. | `demo_kmkk_001` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Simpan versi lukisan dengan tarikh dan perubahan ringkas. Ini memudahkan kumpulan mengenal pasti fail terkini. |
| 20 | Measurement, Drawing & Scale | en | 匿名 | `demo_kmkk_002` | `academic` | `torn` | -1° | `#BFDBFE` Soft blue | `kmkk-awam-site-sketch-assumptions-01.webp` | `contain` / 1.02 | When estimating from a site sketch, separate measured values from assumed values and label both clearly. |
| 21 | Measurement, Drawing & Scale | ms | Balraj S. | `demo_kmkk_003` | `academic` | `polaroid` | 2° | `#E9D5FF` Soft purple | 无 | — | Sebelum menghantar lukisan, periksa tajuk, skala, unit, label dan arah pandangan sebagai senarai semak tetap. |
| 22 | Project Planning & Team Coordination | ms | Celine W. | `demo_kmkk_004` | `academic` | `circle` | -2° | `#CBD5E1` Grey blue | 无 | — | Untuk projek awam, pecahkan kerja kepada tinjauan masalah, pilihan reka bentuk, semakan dan dokumentasi. Jangan terus memilih bentuk akhir. |
| 23 | Project Planning & Team Coordination | ms | 匿名 | `demo_kmkk_005` | `academic` | `square` | 1° | `#CFFAFE` Soft cyan | 无 | — | Tentukan siapa menyimpan fail utama dan bagaimana nama versi ditulis. Banyak masa hilang apabila kumpulan menggunakan lukisan yang berlainan. |
| 24 | Project Planning & Team Coordination | en | Elissa T. | `demo_kmkk_006` | `academic` | `ticket` | 0° | `#FEF08A` Soft yellow | 无 | — | A design decision should record the constraint it addresses, not only the person who suggested it. |
| 25 | Project Planning & Team Coordination | zh | 匿名 | `demo_kmkk_007` | `academic` | `rect` | -1° | `#FED7AA` Soft orange | `kmkk-awam-project-criteria-01.webp` | `contain` / 1.00 | 小组分工时不要把计算、绘图和报告完全分开。每个人都需要理解设计如何从数据变成决定。 |
| 26 | Project Planning & Team Coordination | ms | Gauri N. | `demo_kmkk_008` | `academic` | `speech` | 2° | `#FFF7ED` Warm cream | 无 | — | Semasa membandingkan pilihan, gunakan kriteria seperti keselamatan, penggunaan bahan, kebolehgunaan dan batas projek yang diberikan. |
| 27 | Project Planning & Team Coordination | en | 匿名 | `demo_kmkk_037` | `academic` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | If field information is incomplete, document the missing data instead of silently inventing a convenient value. |
| 28 | Project Planning & Team Coordination | ms | Mardiana F. | `demo_kmkk_038` | `academic` | `hexagon` | 1° | `#E9D5FF` Soft purple | 无 | — | Akhiri semakan reka bentuk dengan senarai perubahan yang boleh diuji, bukan arahan umum seperti “buat lebih kuat”. |
| 29 | Problem Solving & Assessment | ms | Nazmi W. | `demo_kmkk_039` | `academic` | `envelope` | 0° | `#CBD5E1` Grey blue | 无 | — | Baca soalan hingga jelas sama ada diminta daya, momen, tekanan, ukuran atau penerangan. Banyak langkah salah bermula daripada sasaran yang salah. |
| 30 | Problem Solving & Assessment | ms | 匿名 | `demo_kmkk_040` | `academic` | `polaroid` | -1° | `#CFFAFE` Soft cyan | `kmkk-awam-equilibrium-working-01.webp` | `contain` / 1.00 | Susun persamaan secara simbolik sebelum menggantikan nombor apabila soalan mempunyai banyak data. Ia memudahkan semakan hubungan antara pemboleh ubah. |
| 31 | Problem Solving & Assessment | en | Previn K. | `demo_kmkk_041` | `academic` | `torn` | 2° | `#FDE68A` Golden yellow | 无 | — | Use a quick sketch to test whether the final direction and deformation are physically reasonable. |
| 32 | Problem Solving & Assessment | zh | 匿名 | `demo_kmkk_042` | `academic` | `circle` | -2° | `#BBF7D0` Soft green | 无 | — | 复习土木相关题目时，可以把错误分成受力图、公式、单位和代数四类，比较容易找到真正弱点。 |
| 33 | Problem Solving & Assessment | ms | Ramesh Y. | `demo_kmkk_043` | `academic` | `square` | 1° | `#FBCFE8` Soft pink | 无 | — | Jika jawapan rakan berbeza, bandingkan andaian dan keadaan sokongan sebelum membandingkan nombor akhir. |
| 34 | Problem Solving & Assessment | en | 匿名 | `demo_kmkk_044` | `academic` | `rounded` | 0° | `#FED7AA` Soft orange | 无 | — | Past-paper practice is most useful when you explain why each equation applies, not when you memorise a fixed sequence. |
| 35 | Problem Solving & Assessment | ms | Diyanah V. | `demo_kmkk_055` | `academic` | `ticket` | -1° | `#FFF7ED` Warm cream | `kmkk-awam-revision-errors-01.webp` | `contain` / 1.02 | Selepas penilaian, simpan satu contoh kesilapan yang sudah dibetulkan. Contoh nyata lebih mudah diingati daripada nasihat umum. |
| 36 | Safety, Sustainability & Professional Habits | ms | 匿名 | `demo_kmkk_056` | `campus_life` | `speech` | 2° | `#BFDBFE` Soft blue | 无 | — | Keselamatan bukan bahagian tambahan selepas reka bentuk siap. Had penggunaan, risiko kegagalan dan pengguna perlu difikirkan dari awal. |
| 37 | Safety, Sustainability & Professional Habits | ms | Faeza C. | `demo_kmkk_057` | `campus_life` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | When discussing sustainability, state what is being reduced or improved: material, energy, maintenance, waste or service life. |
| 38 | Safety, Sustainability & Professional Habits | en | 匿名 | `demo_kmkk_058` | `campus_life` | `hexagon` | 1° | `#CBD5E1` Grey blue | 无 | — | Jangan gunakan gambar tapak, pelan atau data sebenar yang tidak dibenarkan hanya untuk membuat projek nampak lebih profesional. |
| 39 | Safety, Sustainability & Professional Habits | en | Hidayah K. | `demo_kmkk_059` | `campus_life` | `envelope` | 0° | `#CFFAFE` Soft cyan | 无 | — | A responsible estimate includes uncertainty and limitations. A precise-looking number is not reliable when the input data is weak. |
| 40 | Safety, Sustainability & Professional Habits | ms | 匿名 | `demo_kmkk_060` | `campus_life` | `polaroid` | -1° | `#FDE68A` Golden yellow | `kmkk-awam-site-permission-checklist-01.webp` | `contain` / 1.00 | Jika aktiviti memerlukan lawatan, pengukuran atau alat, ikut kebenaran dan prosedur rasmi. Jangan masuk kawasan terhad untuk mendapatkan gambar. |
| 41 | Safety, Sustainability & Professional Habits | en | Jacintha E. | `demo_kmkk_061` | `campus_life` | `torn` | 2° | `#BBF7D0` Soft green | 无 | — | Civil engineering discussions are stronger when public use and accessibility are considered alongside structural performance. |
| 42 | Safety, Sustainability & Professional Habits | ms | 匿名 | `demo_kmkk_062` | `campus_life` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Bezakan cadangan pelajar daripada standard atau arahan rasmi. Peraturan teknikal mesti dirujuk kepada sumber yang ditetapkan oleh pensyarah. |

## 8. Kejuruteraan Mekanikal（majorId 6）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 2 + majorId`的community wall，不创建建筑或地图地点。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmkk-mekanikal-motion-sketch-01.webp` | 物体运动、坐标轴和受力方向的通用草图。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 8 | `kmkk-mekanikal-energy-flow-01.webp` | 输入、输出、储存和损失的简单energy-flow diagram。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 15 | `kmkk-mekanikal-cad-sketch-01.webp` | 通用零件草图或自制CAD练习截图；隐藏账户、文件路径和授权信息。 | 需拍摄／用户自有 | `cover` | 1.08 |
| 20 | `kmkk-mekanikal-section-view-sketch-01.webp` | 简单零件外观图与section view对照，使用自制通用练习图。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 25 | `kmkk-mekanikal-zero-unit-check-01.webp` | 测量前零点、量程与单位检查卡片，不示范未经许可的仪器操作。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 30 | `kmkk-mekanikal-failure-notes-01.webp` | 失败位置、条件和观察三栏记录，不展示真实项目机密。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 35 | `kmkk-mekanikal-corrected-working-01.webp` | 一题已订正的机械计算，标出diagram、单位、假设与方向检查。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 40 | `kmkk-mekanikal-simplified-system-sketch-01.webp` | 把复杂机械系统简化成主要组件和相互作用的通用草图。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |

### 42条完整视觉字段

| No. | 分区 | 语言 | 显示 | 用户 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---|---|---|---|---|---:|---|---|---|---|
| 1 | Mechanics & Motion | ms | Low Wei C. | `demo_kmkk_037` | `academic` | `polaroid` | -2° | `#BFDBFE` Soft blue | `kmkk-mekanikal-motion-sketch-01.webp` | `contain` / 1.00 | Mulakan soalan gerakan dengan melukis sistem dan memilih paksi. Arah yang jelas membantu mengelakkan tanda positif dan negatif bercampur. |
| 2 | Mechanics & Motion | ms | 匿名 | `demo_kmkk_038` | `academic` | `rounded` | 1° | `#FEF08A` Soft yellow | 无 | — | Bezakan daya yang bertindak pada objek daripada gerakan yang terhasil. Objek boleh bergerak walaupun jumlah daya pada masa tertentu ialah sifar. |
| 3 | Mechanics & Motion | en | Nazmi W. | `demo_kmkk_039` | `academic` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | Write the known quantities with units before selecting an equation. Similar symbols can represent very different physical values. |
| 4 | Mechanics & Motion | zh | 匿名 | `demo_kmkk_040` | `academic` | `square` | 2° | `#FBCFE8` Soft pink | 无 | — | 做mechanics题时先确认题目讨论的是位移、速度、加速度还是力。把这些量混在一起会导致公式选错。 |
| 5 | Mechanics & Motion | ms | Previn K. | `demo_kmkk_041` | `academic` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Jika menggunakan rajah badan bebas, tunjuk hanya daya luaran pada objek yang dipilih. Jangan masukkan daya yang objek itu kenakan pada benda lain. |
| 6 | Mechanics & Motion | en | 匿名 | `demo_kmkk_042` | `academic` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | A correct numerical answer should still be checked for direction, sign and whether its size makes physical sense. |
| 7 | Mechanics & Motion | ms | Ramesh Y. | `demo_kmkk_043` | `academic` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Ulang penyelesaian dengan susunan langkah yang lebih kemas selepas memahami konsep. Nota yang jelas lebih berguna untuk peperiksaan seterusnya. |
| 8 | Energy, Heat & Systems | ms | Suraya O. | `demo_kmkk_044` | `academic` | `envelope` | 2° | `#CBD5E1` Grey blue | `kmkk-mekanikal-energy-flow-01.webp` | `contain` / 1.00 | Apabila mengkaji sistem tenaga, nyatakan sempadan sistem dan bentuk tenaga yang masuk, keluar atau disimpan. |
| 9 | Energy, Heat & Systems | ms | 匿名 | `demo_kmkk_045` | `academic` | `torn` | 0° | `#CFFAFE` Soft cyan | 无 | — | Jangan anggap semua tenaga berguna. Kehilangan haba, geseran dan kecekapan perlu dikenal pasti mengikut model yang digunakan. |
| 10 | Energy, Heat & Systems | en | Umesh J. | `demo_kmkk_046` | `academic` | `circle` | -1° | `#FDE68A` Golden yellow | 无 | — | A simple energy balance is easier to check when every term is labelled as input, output, storage or loss. |
| 11 | Energy, Heat & Systems | zh | 匿名 | `demo_kmkk_047` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | 学习热和能量时先写清楚system boundary。边界不同，哪些能量要计算也会不同。 |
| 12 | Energy, Heat & Systems | ms | Wanis A. | `demo_kmkk_048` | `academic` | `polaroid` | -2° | `#E9D5FF` Soft purple | 无 | — | Semak perbezaan antara suhu, haba dan tenaga dalaman. Perkataan ini berkait tetapi tidak boleh digunakan secara berganti tanpa sebab. |
| 13 | Energy, Heat & Systems | en | 匿名 | `demo_kmkk_049` | `academic` | `square` | 1° | `#CBD5E1` Grey blue | 无 | — | When assumptions such as steady operation or negligible loss are used, write them explicitly before calculating. |
| 14 | Energy, Heat & Systems | ms | Yasirah T. | `demo_kmkk_050` | `academic` | `ticket` | 0° | `#FED7AA` Soft orange | 无 | — | Gunakan gambarajah aliran untuk sistem yang mempunyai beberapa komponen. Ia membantu melihat urutan dan tempat ukuran diperlukan. |
| 15 | Technical Drawing & CAD Habits | ms | Zhen Yu L. | `demo_kmkk_051` | `academic` | `speech` | -1° | `#FFF7ED` Warm cream | `kmkk-mekanikal-cad-sketch-01.webp` | `cover` / 1.08 | Lakaran tangan masih berguna sebelum membuka perisian. Ia membolehkan idea bentuk dan sambungan diuji dengan cepat. |
| 16 | Technical Drawing & CAD Habits | ms | 匿名 | `demo_kmkk_052` | `academic` | `rect` | 2° | `#CFFAFE` Soft cyan | 无 | — | Dalam lukisan mekanikal, pastikan pandangan, ukuran dan garis tersembunyi digunakan secara konsisten mengikut arahan kursus. |
| 17 | Technical Drawing & CAD Habits | en | Boon Kiat M. | `demo_kmkk_053` | `academic` | `hexagon` | -2° | `#FDE68A` Golden yellow | 无 | — | A CAD model should be constrained with meaningful dimensions instead of being adjusted until it only looks correct. |
| 18 | Technical Drawing & CAD Habits | zh | 匿名 | `demo_kmkk_054` | `academic` | `envelope` | 1° | `#BBF7D0` Soft green | 无 | — | 画机械零件时先确定基准面和主要尺寸。后面所有细节都跟着不稳定的参考点，会很难修改。 |
| 19 | Technical Drawing & CAD Habits | ms | Hakeem B. | `demo_kmkk_009` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Namakan fail dan komponen dengan jelas. Nama seperti final2_baru_terakhir menyukarkan kumpulan mengenal pasti versi sebenar. |
| 20 | Technical Drawing & CAD Habits | en | 匿名 | `demo_kmkk_010` | `academic` | `torn` | -1° | `#BFDBFE` Soft blue | `kmkk-mekanikal-section-view-sketch-01.webp` | `contain` / 1.00 | Use section views only when they reveal information that an exterior view cannot communicate clearly. |
| 21 | Technical Drawing & CAD Habits | ms | Jovan M. | `demo_kmkk_011` | `academic` | `polaroid` | 2° | `#E9D5FF` Soft purple | 无 | — | Sebelum eksport atau cetak, periksa unit model, skala helaian, tajuk dan keterbacaan ukuran. |
| 22 | Practical Work & Measurement | ms | Kausalya V. | `demo_kmkk_012` | `academic` | `circle` | -2° | `#CBD5E1` Grey blue | 无 | — | Sebelum menggunakan alat, fahami julat dan unit bacaannya. Alat yang lebih banyak digit tidak semestinya lebih tepat untuk semua tugas. |
| 23 | Practical Work & Measurement | ms | 匿名 | `demo_kmkk_013` | `academic` | `square` | 1° | `#CFFAFE` Soft cyan | 无 | — | Catat bacaan sebenar dan keadaan eksperimen. Jangan ubah data hanya supaya graf atau jawapan kelihatan lebih kemas. |
| 24 | Practical Work & Measurement | en | Naufal D. | `demo_kmkk_014` | `academic` | `ticket` | 0° | `#FEF08A` Soft yellow | 无 | — | Repeat measurements when instructed and compare the spread, not only the average value. |
| 25 | Practical Work & Measurement | zh | 匿名 | `demo_kmkk_015` | `academic` | `rect` | -1° | `#FED7AA` Soft orange | `kmkk-mekanikal-zero-unit-check-01.webp` | `contain` / 1.00 | 进行practical时先确认仪器零点和读数单位。记录时不要等到最后才凭记忆补数据。 |
| 26 | Practical Work & Measurement | ms | Paramesh C. | `demo_kmkk_016` | `academic` | `speech` | 2° | `#FFF7ED` Warm cream | 无 | — | Jika alat atau sambungan tidak jelas, berhenti dan minta tunjuk ajar. Meneka boleh merosakkan peralatan atau menghasilkan data yang tidak berguna. |
| 27 | Practical Work & Measurement | en | 匿名 | `demo_kmkk_027` | `academic` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | A useful practical report separates observation, calculation, uncertainty and interpretation into distinct parts. |
| 28 | Practical Work & Measurement | ms | Batrisyia J. | `demo_kmkk_028` | `academic` | `hexagon` | 1° | `#E9D5FF` Soft purple | 无 | — | Selepas aktiviti, pulangkan alat dan kemaskan ruang mengikut arahan. Keselamatan kumpulan seterusnya bergantung pada tabiat ini. |
| 29 | Design, Failure & Assessment | ms | Calvin H. | `demo_kmkk_029` | `academic` | `envelope` | 0° | `#CBD5E1` Grey blue | 无 | — | Apabila membandingkan reka bentuk, nyatakan beban, gerakan, bahan dan keadaan penggunaan yang dianggap. |
| 30 | Design, Failure & Assessment | ms | 匿名 | `demo_kmkk_030` | `academic` | `polaroid` | -1° | `#CFFAFE` Soft cyan | `kmkk-mekanikal-failure-notes-01.webp` | `contain` / 1.02 | Kegagalan prototaip perlu direkodkan dengan tempat, keadaan dan tanda yang dilihat. “Tidak menjadi” tidak cukup untuk pembaikan. |
| 31 | Design, Failure & Assessment | en | Eshan P. | `demo_kmkk_031` | `academic` | `torn` | 2° | `#FDE68A` Golden yellow | 无 | — | A design is not improved merely by adding more material. Consider geometry, load path, mass and manufacturability together. |
| 32 | Design, Failure & Assessment | zh | 匿名 | `demo_kmkk_032` | `academic` | `circle` | -2° | `#BBF7D0` Soft green | 无 | — | 复习机械题时，不只检查最后数字，也要检查diagram、单位、假设和结果方向是否合理。 |
| 33 | Design, Failure & Assessment | ms | Hema L. | `demo_kmkk_033` | `academic` | `square` | 1° | `#FBCFE8` Soft pink | 无 | — | Untuk soalan panjang, bina penyelesaian dalam blok kecil dan buat semakan selepas setiap blok. Ini mengurangkan kesilapan yang tersebar. |
| 34 | Design, Failure & Assessment | en | 匿名 | `demo_kmkk_034` | `academic` | `rounded` | 0° | `#FED7AA` Soft orange | 无 | — | Timed practice should include time for a diagram and final physical check, not only calculator work. |
| 35 | Design, Failure & Assessment | ms | Lavanya I. | `demo_kmkk_063` | `academic` | `ticket` | -1° | `#FFF7ED` Warm cream | `kmkk-mekanikal-corrected-working-01.webp` | `contain` / 1.00 | Selepas ujian, pilih satu soalan sukar dan tulis semula penyelesaian yang lebih jelas sebagai rujukan masa depan. |
| 36 | Teamwork, Safety & Wellbeing | ms | 匿名 | `demo_kmkk_064` | `emotional` | `speech` | 2° | `#BFDBFE` Soft blue | 无 | — | Dalam kumpulan mekanikal, orang yang membuat model, kiraan dan laporan perlu berkongsi andaian yang sama. |
| 37 | Teamwork, Safety & Wellbeing | ms | Nandini J. | `demo_kmkk_065` | `emotional` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Keep moving parts, heat sources and tools within the safety limits specified by the lecturer or laboratory. |
| 38 | Teamwork, Safety & Wellbeing | en | 匿名 | `demo_kmkk_066` | `emotional` | `hexagon` | 1° | `#CBD5E1` Grey blue | 无 | — | Jangan merakam mesin, makmal atau projek orang lain tanpa kebenaran. Gambar demonstrasi perlu menggunakan bahan sendiri atau yang diluluskan. |
| 39 | Teamwork, Safety & Wellbeing | en | Pavithra W. | `demo_kmkk_067` | `emotional` | `envelope` | 0° | `#CFFAFE` Soft cyan | 无 | — | When a teammate makes a mistake, identify the process that allowed it instead of turning the review into personal blame. |
| 40 | Teamwork, Safety & Wellbeing | ms | 匿名 | `demo_kmkk_068` | `emotional` | `polaroid` | -1° | `#FDE68A` Golden yellow | `kmkk-mekanikal-simplified-system-sketch-01.webp` | `contain` / 1.00 | Jika buntu terlalu lama, kembali kepada sistem paling ringkas dan lukis semula interaksi komponennya. |
| 41 | Teamwork, Safety & Wellbeing | en | Roshan D. | `demo_kmkk_069` | `emotional` | `torn` | 2° | `#BBF7D0` Soft green | 无 | — | Good engineering notes include failed attempts when they explain why a method was rejected. |
| 42 | Teamwork, Safety & Wellbeing | ms | 匿名 | `demo_kmkk_070` | `emotional` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Bezakan tip komuniti daripada prosedur rasmi. Keselamatan alat dan makmal sentiasa mengikut arahan pensyarah serta kolej. |

## 9. Kejuruteraan Elektrik & Elektronik（majorId 7）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 2 + majorId`的community wall，不创建建筑或地图地点。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmkk-elektrik-circuit-diagram-01.webp` | 使用标准符号的通用低压电路图，不连接市电。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 8 | `kmkk-elektrik-unit-prefix-01.webp` | milli、micro、kilo与基础单位换算卡片。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 15 | `kmkk-elektrik-breadboard-layout-01.webp` | 未上电的breadboard与低风险元件摆拍；不得连接市电或未知电源。 | 需拍摄／用户自有；仅低压安全摆拍 | `cover` | 1.08 |
| 20 | `kmkk-elektrik-power-off-breadboard-01.webp` | 未上电breadboard与“change connections only when power is off”安全卡片；仅低压静态摆拍。 | 需拍摄／用户自有；仅低压安全摆拍 | `cover` | 1.08 |
| 25 | `kmkk-elektrik-troubleshooting-log-01.webp` | 测试点、预期值、实测值和改动记录表。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 30 | `kmkk-elektrik-system-block-diagram-01.webp` | 输入、处理与输出的通用系统block diagram，不含真实项目机密。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 35 | `kmkk-elektrik-corrected-circuit-working-01.webp` | 已订正的通用电路计算与故障排查记录，不包含正式测验内容。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 40 | `kmkk-elektrik-tolerance-check-01.webp` | 理论值、容差、实测值和连接检查四栏的通用比较卡片。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |

### 42条完整视觉字段

| No. | 分区 | 语言 | 显示 | 用户 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---|---|---|---|---|---:|---|---|---|---|
| 1 | Circuit Concepts & Diagrams | ms | Diyanah V. | `demo_kmkk_055` | `academic` | `polaroid` | -2° | `#BFDBFE` Soft blue | `kmkk-elektrik-circuit-diagram-01.webp` | `contain` / 1.00 | Sebelum mengira, lukis litar dengan simbol yang jelas dan tandakan nod atau arah arus yang digunakan. |
| 2 | Circuit Concepts & Diagrams | ms | 匿名 | `demo_kmkk_056` | `academic` | `rounded` | 1° | `#FEF08A` Soft yellow | 无 | — | Bezakan sambungan siri dan selari berdasarkan nod, bukan hanya rupa wayar pada gambar. |
| 3 | Circuit Concepts & Diagrams | en | Faeza C. | `demo_kmkk_057` | `academic` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | A circuit diagram should communicate electrical connections, not imitate the physical shape of the breadboard. |
| 4 | Circuit Concepts & Diagrams | zh | 匿名 | `demo_kmkk_058` | `academic` | `square` | 2° | `#FBCFE8` Soft pink | 无 | — | 看电路图时先找node和电源方向，不要只根据元件画在左边还是右边来判断连接方式。 |
| 5 | Circuit Concepts & Diagrams | ms | Hidayah K. | `demo_kmkk_059` | `academic` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Gunakan satu konvensyen tanda untuk voltan dan arus sepanjang penyelesaian. Perubahan tanpa penjelasan mudah menghasilkan jawapan bercanggah. |
| 6 | Circuit Concepts & Diagrams | en | 匿名 | `demo_kmkk_060` | `academic` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | If a calculated voltage or current has a negative sign, interpret the direction before assuming the calculation is wrong. |
| 7 | Circuit Concepts & Diagrams | ms | Jacintha E. | `demo_kmkk_061` | `academic` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Selepas menyelesaikan litar, semak sama ada kuasa dan nilai komponen berada dalam julat yang masuk akal untuk model soalan. |
| 8 | Units, Calculation & Signals | ms | Khairi U. | `demo_kmkk_062` | `academic` | `envelope` | 2° | `#CBD5E1` Grey blue | `kmkk-elektrik-unit-prefix-01.webp` | `contain` / 1.00 | Tulis awalan unit seperti milli, micro dan kilo dengan teliti. Satu kesilapan kuasa sepuluh boleh mengubah jawapan dengan besar. |
| 9 | Units, Calculation & Signals | ms | 匿名 | `demo_kmkk_063` | `academic` | `torn` | 0° | `#CFFAFE` Soft cyan | 无 | — | Sebelum menekan kalkulator, tukar semua nilai kepada unit yang konsisten dan simpan langkah penukaran dalam working. |
| 10 | Units, Calculation & Signals | en | Muhaimin B. | `demo_kmkk_064` | `academic` | `circle` | -1° | `#FDE68A` Golden yellow | 无 | — | Estimate the expected range of a result before calculating. It helps detect a misplaced decimal point or prefix. |
| 11 | Units, Calculation & Signals | zh | 匿名 | `demo_kmkk_065` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | 计算电路时要特别注意mA、A、kΩ和Ω之间的转换。答案差一千倍通常不是小错误。 |
| 12 | Units, Calculation & Signals | ms | Othman F. | `demo_kmkk_066` | `academic` | `polaroid` | -2° | `#E9D5FF` Soft purple | 无 | — | Apabila melihat graf isyarat, tandakan paksi, unit, tempoh dan amplitud sebelum membuat kesimpulan. |
| 13 | Units, Calculation & Signals | en | 匿名 | `demo_kmkk_067` | `academic` | `square` | 1° | `#CBD5E1` Grey blue | 无 | — | Do not confuse a measured value with an ideal theoretical value. State which one is being discussed. |
| 14 | Units, Calculation & Signals | ms | Qamarina H. | `demo_kmkk_068` | `academic` | `ticket` | 0° | `#FED7AA` Soft orange | 无 | — | Bina senarai kesilapan biasa seperti polariti, unit dan salah baca kod komponen untuk semakan pantas sebelum menghantar jawapan. |
| 15 | Components & Breadboard Practice | ms | Roshan D. | `demo_kmkk_069` | `academic` | `speech` | -1° | `#FFF7ED` Warm cream | `kmkk-elektrik-breadboard-layout-01.webp` | `cover` / 1.08 | Kenal pasti kaki dan orientasi komponen menggunakan sumber kursus sebelum memasang. Jangan meneka hanya daripada bentuk luaran. |
| 16 | Components & Breadboard Practice | ms | 匿名 | `demo_kmkk_070` | `academic` | `rect` | 2° | `#CFFAFE` Soft cyan | 无 | — | Pada breadboard, semak sambungan baris dan rel kuasa dengan meter atau rajah yang betul sebelum menghidupkan bekalan. |
| 17 | Components & Breadboard Practice | en | Tze Wei O. | `demo_kmkk_071` | `academic` | `hexagon` | -2° | `#FDE68A` Golden yellow | 无 | — | A neat layout is easier to troubleshoot because each connection can be traced without moving several wires. |
| 18 | Components & Breadboard Practice | zh | 匿名 | `demo_kmkk_072` | `academic` | `envelope` | 1° | `#BBF7D0` Soft green | 无 | — | 在breadboard上接线前先理解内部连接。看起来很靠近的两个孔，不一定属于同一条导通线。 |
| 19 | Components & Breadboard Practice | ms | Hakeem B. | `demo_kmkk_009` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Gunakan warna wayar secara konsisten jika dibenarkan, contohnya untuk bekalan, bumi dan isyarat. Ini mengurangkan kekeliruan kumpulan. |
| 20 | Components & Breadboard Practice | en | 匿名 | `demo_kmkk_010` | `academic` | `torn` | -1° | `#BFDBFE` Soft blue | `kmkk-elektrik-power-off-breadboard-01.webp` | `cover` / 1.08 | Power should remain off while changing connections unless the lecturer or procedure explicitly requires otherwise. |
| 21 | Components & Breadboard Practice | ms | Jovan M. | `demo_kmkk_011` | `academic` | `polaroid` | 2° | `#E9D5FF` Soft purple | 无 | — | Ambil gambar litar sendiri selepas mendapat kebenaran dan sebelum mencabut wayar. Pastikan gambar tidak menunjukkan data atau projek orang lain. |
| 22 | Troubleshooting & Measurement | ms | Kausalya V. | `demo_kmkk_012` | `academic` | `circle` | -2° | `#CBD5E1` Grey blue | 无 | — | Apabila litar tidak berfungsi, semak bekalan, bumi, orientasi dan satu sambungan pada satu masa. Menukar semuanya serentak menghilangkan punca sebenar. |
| 23 | Troubleshooting & Measurement | ms | 匿名 | `demo_kmkk_013` | `academic` | `square` | 1° | `#CFFAFE` Soft cyan | 无 | — | Catat keadaan sebelum dan selepas setiap perubahan. Troubleshooting tanpa rekod mudah berputar pada kesilapan yang sama. |
| 24 | Troubleshooting & Measurement | en | Naufal D. | `demo_kmkk_014` | `academic` | `ticket` | 0° | `#FEF08A` Soft yellow | 无 | — | Measure at known reference points first, then move through the circuit in a logical order. |
| 25 | Troubleshooting & Measurement | zh | 匿名 | `demo_kmkk_015` | `academic` | `rect` | -1° | `#FED7AA` Soft orange | `kmkk-elektrik-troubleshooting-log-01.webp` | `contain` / 1.00 | 排查故障时先确认电源和ground，再逐段量测。不要一开始就假设最复杂的元件坏了。 |
| 26 | Troubleshooting & Measurement | ms | Paramesh C. | `demo_kmkk_016` | `academic` | `speech` | 2° | `#FFF7ED` Warm cream | 无 | — | Pastikan mod dan julat meter sesuai sebelum menyambung. Sambungan meter yang salah boleh menghasilkan bacaan salah atau risiko keselamatan. |
| 27 | Troubleshooting & Measurement | en | 匿名 | `demo_kmkk_027` | `academic` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | A failed measurement is information when the test point, meter setting and expected value are recorded. |
| 28 | Troubleshooting & Measurement | ms | Batrisyia J. | `demo_kmkk_028` | `academic` | `hexagon` | 1° | `#E9D5FF` Soft purple | 无 | — | Jika terdapat bau, haba luar biasa atau komponen rosak, matikan bekalan dan laporkan segera. Jangan terus mencuba untuk mendapatkan gambar. |
| 29 | Logic, Systems & Assessment | ms | Calvin H. | `demo_kmkk_029` | `academic` | `envelope` | 0° | `#CBD5E1` Grey blue | 无 | — | Untuk masalah logik, tulis input, keadaan dan output secara berasingan sebelum membina jadual atau rajah. |
| 30 | Logic, Systems & Assessment | ms | 匿名 | `demo_kmkk_030` | `academic` | `polaroid` | -1° | `#CFFAFE` Soft cyan | `kmkk-elektrik-system-block-diagram-01.webp` | `contain` / 1.00 | Terangkan fungsi blok sistem dengan satu ayat setiap blok. Ini memudahkan semakan aliran isyarat dan tempat kesilapan mungkin berlaku. |
| 31 | Logic, Systems & Assessment | en | Eshan P. | `demo_kmkk_031` | `academic` | `torn` | 2° | `#FDE68A` Golden yellow | 无 | — | A truth table is useful only when every input combination and the meaning of the output are defined clearly. |
| 32 | Logic, Systems & Assessment | zh | 匿名 | `demo_kmkk_032` | `academic` | `circle` | -2° | `#BBF7D0` Soft green | 无 | — | 复习电子系统时，可以从input一路解释到output。哪一个block讲不清楚，就先回去检查那个部分。 |
| 33 | Logic, Systems & Assessment | ms | Hema L. | `demo_kmkk_033` | `academic` | `square` | 1° | `#FBCFE8` Soft pink | 无 | — | Dalam soalan pengiraan, bezakan nilai diberi, nilai diukur dan nilai yang perlu direka atau dipilih. |
| 34 | Logic, Systems & Assessment | en | 匿名 | `demo_kmkk_034` | `academic` | `rounded` | 0° | `#FED7AA` Soft orange | 无 | — | Practice explaining why a component or block is needed, not only what symbol it uses. |
| 35 | Logic, Systems & Assessment | ms | Thaqif H. | `demo_kmkk_045` | `academic` | `ticket` | -1° | `#FFF7ED` Warm cream | `kmkk-elektrik-corrected-circuit-working-01.webp` | `contain` / 1.00 | Selepas penilaian, simpan satu contoh troubleshooting dan satu contoh pengiraan yang sudah dibetulkan untuk ulang kaji. |
| 36 | Safety, Teamwork & Responsible Sharing | ms | 匿名 | `demo_kmkk_046` | `campus_life` | `speech` | 2° | `#BFDBFE` Soft blue | 无 | — | Bekalan kuasa, alat ukur dan komponen mesti digunakan mengikut had serta arahan makmal. Jangan mencuba sambungan rawak untuk melihat apa berlaku. |
| 37 | Safety, Teamwork & Responsible Sharing | ms | Vivian Q. | `demo_kmkk_047` | `campus_life` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Share diagrams and calculations with labels and context. An unexplained circuit image can be misleading to another student. |
| 38 | Safety, Teamwork & Responsible Sharing | en | 匿名 | `demo_kmkk_048` | `campus_life` | `hexagon` | 1° | `#CBD5E1` Grey blue | 无 | — | Dalam kumpulan, seorang boleh memasang dan seorang lagi menyemak rajah, tetapi kedua-duanya mesti memahami sambungan sebelum kuasa dihidupkan. |
| 39 | Safety, Teamwork & Responsible Sharing | en | Xander G. | `demo_kmkk_049` | `campus_life` | `envelope` | 0° | `#CFFAFE` Soft cyan | 无 | — | Do not post login screens, device identifiers, private network details or other students’ project files as demo photos. |
| 40 | Safety, Teamwork & Responsible Sharing | ms | 匿名 | `demo_kmkk_050` | `campus_life` | `polaroid` | -1° | `#FDE68A` Golden yellow | `kmkk-elektrik-tolerance-check-01.webp` | `contain` / 1.00 | Jika hasil berbeza daripada teori, semak toleransi, sambungan dan kaedah ukur sebelum menyalahkan komponen. |
| 41 | Safety, Teamwork & Responsible Sharing | en | Zhen Yu L. | `demo_kmkk_051` | `campus_life` | `torn` | 2° | `#BBF7D0` Soft green | 无 | — | A calm shutdown and documented check are more professional than repeatedly powering a faulty circuit. |
| 42 | Safety, Teamwork & Responsible Sharing | ms | 匿名 | `demo_kmkk_052` | `campus_life` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Tip komuniti tidak menggantikan prosedur rasmi. Untuk keselamatan elektrik dan peralatan, ikut arahan pensyarah serta makmal. |

## 10. Codex导入契约

- 当前批次尚未批准导入；不得修改网站。
- 每条便贴必须使用`contextType: "community"`、`orgId: 2`以及本文对应的`majorId`。
- 不按Batch 06/07/08复制community wall；batch只属于用户资料。
- 使用文档指定的authorUserId、匿名状态、shape、color、rotation及照片配置，不得重新随机。
- 匿名便贴`authorNickname: null`；具名便贴使用用户池displayName。
- 照片未拍摄/批准前不得写入虚假Cloudinary URL、普通相对路径或Base64占位内容。
- 不自动commit、push、创建PR、改写Git历史或隐藏失败测试。

## 11. 验收、测试、停止条件与回滚

- 总墙数4、总便贴168、总用户72、总照片槽位32。
- 每墙42条、42个不同authorUserId、具名23/匿名19、BM24/EN13/ZH5。
- 每墙10种形状和10个颜色预设全部出现。
- 用户ID、便贴ID及内容不得重复；用户仅属于orgId 2。
- 重复执行必须幂等；刷新与新设备首次载入不得再次追加相同种子。
- 页面不得显示内部邮箱、authorUserId、isDemoSeed或照片资产管理字段。
- 若schema不兼容、图片未批准、数据量导致卡顿、出现跨学院错误或种子不幂等，立即停止。
- 回滚只移除Batch 06的演示用户与便贴，不影响原有数据、管理员或认证架构。
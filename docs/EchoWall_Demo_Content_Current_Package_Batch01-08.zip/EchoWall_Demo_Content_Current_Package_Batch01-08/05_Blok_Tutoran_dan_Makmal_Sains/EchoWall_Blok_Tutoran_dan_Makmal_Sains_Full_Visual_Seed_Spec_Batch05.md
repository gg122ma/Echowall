# EchoWall 演示便贴视觉配置完整版

## 批次 05：Blok Tutoran dan Makmal Sains

> 用户称“Blok Tutorial dan Makmal Sains”；网站建筑注册表使用“Blok Tutoran dan Makmal Sains”。以下以网站实际名称和ID为准。

> 状态：42条内容、照片槽位、形状、颜色与旋转已完成；尚未导入网站。

## 1. 总体判断

- 任务类型：`DOC + DATA`
- 风险等级：`L2`
- 变更规模：`S1`（本阶段仅完善文档）
- 准备状态：`READY`
- 执行模式：`DIRECT`

## 2. 地点与代码映射

- 建筑名称：**Blok Tutoran dan Makmal Sains**
- `placeId`：`B_BLOK_TUTORAN_MAKMAL`
- `wallKey`：`building:B_BLOK_TUTORAN_MAKMAL`
- 网站建筑注册表记录为3层教学建筑。
- CUBIC等其他区域不归入本墙；本墙只整理tutorial room、makmal和共用庭院相关内容。

## 3. 来源边界

- 学生指南确认Bilik Tutorial用于tutorial课程，并提醒中午至下午时段可能较热。
- 学生指南确认Lab/Makmal用于AMALI和实验课程。
- 具体房间、课程、实验室、安全服装和器材规定必须以课表、讲师及现场正式公告为准。
- 网站的开放时间字段缺少可靠外部核验，因此本批留言不写死开放时段。
- 所有姓名、账号和留言均为虚构演示数据，不取自学生名单，也不代表42条真实证言。

## 4. 数据摘要

- 便贴：42条
- 具名：23条；匿名：19条
- BM：24条；English：13条；中文：5条
- 带照片：9条（21.4%）
- 使用全部10种现有形状和全部10个现有颜色预设
- 显示名不与前四批重复

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：3条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：6条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

## 5. 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `tutoran-makmal-exterior-courtyard-01.webp` | Blok Tutoran dan Makmal Sains外观或中央开放庭院，4:3横向，不出现清晰人脸。 | 可参考 school-environment PDF 第23及24页；建议用户自行补拍 | `cover` | 1.12 |
| 4 | `tutoran-makmal-tutorial-corridor-01.webp` | Tutorial room走廊、门牌或外墙局部；避免学生名单、课表详情和清晰人脸。 | 可参考 school-environment PDF 第23页；建议用户自行补拍 | `cover` | 1.10 |
| 8 | `tutoran-makmal-question-sheet-01.webp` | 已圈出疑问步骤的通用练习纸、笔和笔记本摆拍，不使用真实姓名或正式测验卷。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 16 | `tutoran-makmal-afternoon-tutorial-01.webp` | 中午至下午的空tutorial room或有阳光的走廊，表现环境较热；不拍清晰人脸。 | 可参考 school-environment PDF 第23页；建议用户自行补拍 | `cover` | 1.08 |
| 22 | `tutoran-makmal-lab-entrance-01.webp` | Makmal入口、实验室外观或安全告示局部，不显示受限通知、名单或电话号码。 | 可参考 school-environment PDF 第24页；建议用户自行补拍 | `cover` | 1.10 |
| 25 | `tutoran-makmal-practical-kit-01.webp` | 实验前准备的护目镜、实验衣、文具和空白观察表摆拍；实际要求仍以课程指示为准。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 30 | `tutoran-makmal-apparatus-setup-01.webp` | 无危险材料的通用实验器材摆放或学生手部操作；不要展示化学品标签和清晰人脸。 | 需拍摄／用户自有；拍摄前须获实验室许可 | `cover` | 1.08 |
| 36 | `tutoran-makmal-observation-table-01.webp` | 虚构观察表、单位和简短实验记录摆拍；不得使用真实学生实验报告。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 41 | `tutoran-makmal-clean-workbench-01.webp` | 完成清洁后的实验桌、器材归位或通用废弃物分类标志；避免危险材料和学生资料。 | 需拍摄／用户自有；须遵守实验室拍摄许可 | `cover` | 1.08 |

照片统一要求：4:3横向优先、WebP、单张目标不超过450KB；不得出现清晰人脸、学生名单、学号、实验数据身份信息、受限实验材料或账号资料。实验室内部拍摄必须先取得许可。跨设备展示优先使用批准后的Cloudinary HTTPS URL。

## 6. 42条完整视觉字段

| No. | 分区 | 语言 | 显示 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Navigation & Courtyard | ms | Nadira Q.<br>`demo_tutoran_makmal_001` | `campus_life` | `polaroid` | -2° | `#BFDBFE` Soft blue | `tutoran-makmal-exterior-courtyard-01.webp` | `cover` / 1.12 | Semak kod bilik pada jadual sebelum masuk ke blok. Nama bangunan sahaja belum cukup kerana bilik tutorial dan makmal berada di bahagian yang berbeza. |
| 2 | Navigation & Courtyard | ms | 匿名<br>`demo_tutoran_makmal_002` | `campus_life` | `rounded` | 1° | `#FEF08A` Soft yellow | 无 | — | Laman dalaman boleh dijadikan titik rujukan apabila bertukar kelas, tetapi jangan berkumpul di tengah laluan atau hadapan pintu makmal. |
| 3 | Navigation & Courtyard | en | Eileen M.<br>`demo_tutoran_makmal_003` | `campus_life` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | Take a screenshot of the room code before walking here. It is easier than reopening several class messages in the corridor. |
| 4 | Navigation & Courtyard | zh | 匿名<br>`demo_tutoran_makmal_004` | `campus_life` | `square` | 2° | `#FBCFE8` Soft pink | `tutoran-makmal-tutorial-corridor-01.webp` | `cover` / 1.10 | 第一次来时先确认课表上的房间编号。Tutorial room和lab都在同一大建筑范围，不代表入口完全一样。 |
| 5 | Navigation & Courtyard | ms | Siti Hajar N.<br>`demo_tutoran_makmal_005` | `campus_life` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Gunakan papan tanda dan nombor pintu sebagai rujukan terakhir. Catatan lama di dinding hanya sesuai untuk panduan umum. |
| 6 | Navigation & Courtyard | en | 匿名<br>`demo_tutoran_makmal_006` | `campus_life` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | Move to the side before checking your phone. The corridors become crowded when tutorial and practical sessions end together. |
| 7 | Navigation & Courtyard | ms | Neesha K.<br>`demo_tutoran_makmal_007` | `campus_life` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Kalau tersalah tingkat atau sayap, kembali ke laman tengah dan semak semula arah. Jangan masuk ke makmal yang sedang digunakan tanpa kebenaran. |
| 8 | Tutorial Preparation | ms | Farisya D.<br>`demo_tutoran_makmal_008` | `academic` | `polaroid` | 2° | `#CBD5E1` Grey blue | `tutoran-makmal-question-sheet-01.webp` | `contain` / 1.02 | Bawa soalan yang sudah dicuba, bukan helaian kosong. Pensyarah lebih mudah melihat langkah pertama yang menyebabkan kesilapan. |
| 9 | Tutorial Preparation | ms | 匿名<br>`demo_tutoran_makmal_009` | `academic` | `envelope` | 0° | `#CFFAFE` Soft cyan | 无 | — | Tulis nombor soalan dan bahagian yang tidak faham sebelum kelas tutorial. Masa perbincangan akan digunakan dengan lebih baik. |
| 10 | Tutorial Preparation | en | Nureen H.<br>`demo_tutoran_makmal_010` | `academic` | `rounded` | -1° | `#FDE68A` Golden yellow | 无 | — | Download the worksheet before class and label the questions you want to discuss. Do not rely on a weak connection at the last minute. |
| 11 | Tutorial Preparation | zh | 匿名<br>`demo_tutoran_makmal_011` | `academic` | `square` | 2° | `#BFDBFE` Soft blue | 无 | — | Tutorial之前先把不会的步骤圈起来。只写“全部不会”很难让老师和同学快速帮你。 |
| 12 | Tutorial Preparation | ms | Clarissa P.<br>`demo_tutoran_makmal_012` | `academic` | `torn` | -2° | `#E9D5FF` Soft purple | 无 | — | Saya asingkan nota, latihan dan jawapan semakan dalam tiga bahagian. Meja kecil terasa lebih teratur dan tidak penuh dengan kertas. |
| 13 | Tutorial Preparation | en | 匿名<br>`demo_tutoran_makmal_013` | `academic` | `circle` | 1° | `#CBD5E1` Grey blue | 无 | — | Bring a charged device only when it is needed for the lesson. A notebook and pen are still useful when screens become distracting. |
| 14 | Tutorial Preparation | ms | Jovian C.<br>`demo_tutoran_makmal_014` | `campus_life` | `ticket` | 0° | `#FED7AA` Soft orange | 无 | — | Datang beberapa minit awal supaya boleh memilih tempat yang jelas melihat papan putih tanpa mengganggu kelas sebelumnya. |
| 15 | Tutorial Learning & Heat | ms | Izzati R.<br>`demo_tutoran_makmal_015` | `academic` | `speech` | -1° | `#FFF7ED` Warm cream | 无 | — | Semasa perbincangan, cuba terangkan satu langkah dengan ayat sendiri. Jika penerangan tersekat, itu tanda bahagian tersebut belum benar-benar difahami. |
| 16 | Tutorial Learning & Heat | ms | 匿名<br>`demo_tutoran_makmal_016` | `campus_life` | `polaroid` | 2° | `#CFFAFE` Soft cyan | `tutoran-makmal-afternoon-tutorial-01.webp` | `cover` / 1.08 | Kelas tutorial pada tengah hari hingga petang boleh terasa panas. Bawa air secukupnya dan pilih pakaian yang sesuai dengan peraturan kolej. |
| 17 | Tutorial Learning & Heat | en | Samira W.<br>`demo_tutoran_makmal_017` | `academic` | `rect` | -2° | `#FDE68A` Golden yellow | 无 | — | When the room feels uncomfortable, keep the discussion structured: one question, one explanation, then one short check. |
| 18 | Tutorial Learning & Heat | zh | 匿名<br>`demo_tutoran_makmal_018` | `academic` | `hexagon` | 1° | `#BBF7D0` Soft green | 无 | — | 小班讨论时不要直接抄别人的答案。先说出自己的思路，才知道真正卡住的是公式还是概念。 |
| 19 | Tutorial Learning & Heat | ms | Nor Aina V.<br>`demo_tutoran_makmal_019` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Gunakan papan putih untuk membandingkan dua kaedah, kemudian ambil gambar hanya selepas mendapat kebenaran dan memastikan tiada maklumat peribadi. |
| 20 | Tutorial Learning & Heat | en | 匿名<br>`demo_tutoran_makmal_020` | `emotional` | `envelope` | -1° | `#BFDBFE` Soft blue | 无 | — | A wrong answer during tutorial is useful when the group explains why it is wrong. It is safer to make the mistake here than in an assessment. |
| 21 | Tutorial Learning & Heat | ms | Syarifah M.<br>`demo_tutoran_makmal_021` | `academic` | `square` | 2° | `#E9D5FF` Soft purple | 无 | — | Sebelum keluar, tulis satu ringkasan pendek tentang apa yang sudah faham dan perkara yang masih perlu disemak dengan pensyarah. |
| 22 | Before Practical | ms | Daryl N.<br>`demo_tutoran_makmal_022` | `academic` | `polaroid` | -2° | `#CBD5E1` Grey blue | `tutoran-makmal-lab-entrance-01.webp` | `cover` / 1.10 | Semak arahan amali sebelum datang supaya tahu objektif, pemboleh ubah dan data yang perlu direkodkan. |
| 23 | Before Practical | ms | 匿名<br>`demo_tutoran_makmal_023` | `campus_life` | `ticket` | 1° | `#CFFAFE` Soft cyan | 无 | — | Pakai pakaian dan kasut yang mematuhi arahan makmal. Jika syarat tidak jelas, tanya pensyarah sebelum hari amali. |
| 24 | Before Practical | en | Sanjay B.<br>`demo_tutoran_makmal_024` | `academic` | `rounded` | 0° | `#FEF08A` Soft yellow | 无 | — | Prepare a blank observation table before the practical. Recording data directly is safer than relying on memory afterwards. |
| 25 | Before Practical | zh | 匿名<br>`demo_tutoran_makmal_025` | `campus_life` | `torn` | -1° | `#FED7AA` Soft orange | `tutoran-makmal-practical-kit-01.webp` | `contain` / 1.02 | 进入实验室前先确认需要的服装和安全用品。不同实验可能有不同要求，不要自己猜。 |
| 26 | Before Practical | ms | Roshini E.<br>`demo_tutoran_makmal_026` | `academic` | `circle` | 2° | `#FFF7ED` Warm cream | 无 | — | Bawa alat tulis yang diperlukan dan pastikan kalkulator atau jam randik berfungsi jika diminta dalam arahan kursus. |
| 27 | Before Practical | en | 匿名<br>`demo_tutoran_makmal_027` | `campus_life` | `speech` | -2° | `#BFDBFE` Soft blue | 无 | — | Keep food and drinks outside the laboratory unless the lecturer gives a specific instruction. Do not place them beside apparatus. |
| 28 | Before Practical | ms | Ming Xuan C.<br>`demo_tutoran_makmal_028` | `academic` | `rect` | 1° | `#E9D5FF` Soft purple | 无 | — | Bahagikan tugas kumpulan sebelum eksperimen bermula: seorang membaca prosedur, seorang mengendalikan alat, dan seorang merekod data. |
| 29 | During Practical | ms | Aqilah N.<br>`demo_tutoran_makmal_029` | `academic` | `polaroid` | 0° | `#CBD5E1` Grey blue | 无 | — | Ikut urutan prosedur dan arahan pensyarah. Jangan menukar sukatan, bahan atau sambungan alat hanya untuk mendapatkan keputusan yang kelihatan lebih baik. |
| 30 | During Practical | ms | 匿名<br>`demo_tutoran_makmal_030` | `campus_life` | `hexagon` | -1° | `#CFFAFE` Soft cyan | `tutoran-makmal-apparatus-setup-01.webp` | `cover` / 1.08 | Laporkan tumpahan, kaca pecah atau alat rosak dengan segera. Jangan cuba menyembunyikan masalah atau membersihkan bahan yang tidak dikenal pasti. |
| 31 | During Practical | en | Farah L.<br>`demo_tutoran_makmal_031` | `academic` | `envelope` | 2° | `#FDE68A` Golden yellow | 无 | — | Record the actual observation, even when it differs from the expected result. The discussion should explain the difference, not erase it. |
| 32 | During Practical | zh | 匿名<br>`demo_tutoran_makmal_032` | `academic` | `rounded` | -2° | `#BBF7D0` Soft green | 无 | — | 实验结果不符合预期时，先记录真实观察，再检查步骤和仪器。不要为了“漂亮答案”修改数据。 |
| 33 | During Practical | ms | Tanisha G.<br>`demo_tutoran_makmal_033` | `academic` | `ticket` | 1° | `#FBCFE8` Soft pink | 无 | — | Label setiap sampel atau bekas mengikut arahan. Sampel yang tidak berlabel mudah tertukar apabila beberapa kumpulan bekerja serentak. |
| 34 | During Practical | ms | 匿名<br>`demo_tutoran_makmal_034` | `campus_life` | `square` | 0° | `#FED7AA` Soft orange | 无 | — | Pastikan laluan dan tepi meja tidak dipenuhi beg. Barang peribadi boleh mengganggu pergerakan ketika membawa radas. |
| 35 | During Practical | en | Chen Li W.<br>`demo_tutoran_makmal_035` | `academic` | `torn` | -1° | `#FFF7ED` Warm cream | 无 | — | Read measuring instruments at eye level when required and write the unit immediately. A correct number without a unit is incomplete. |
| 36 | During Practical | ms | 匿名<br>`demo_tutoran_makmal_036` | `academic` | `polaroid` | 2° | `#BFDBFE` Soft blue | `tutoran-makmal-observation-table-01.webp` | `contain` / 1.00 | Jika tidak pasti cara menggunakan radas, berhenti dan minta tunjuk ajar. Meneka boleh merosakkan alat atau membahayakan kumpulan. |
| 37 | After Practical & Shared Safety | ms | Tengku A.<br>`demo_tutoran_makmal_037` | `campus_life` | `circle` | -2° | `#E9D5FF` Soft purple | 无 | — | Selepas amali, pulangkan radas ke tempat yang diarahkan dan bersihkan ruang kerja mengikut prosedur makmal. |
| 38 | After Practical & Shared Safety | ms | 匿名<br>`demo_tutoran_makmal_038` | `academic` | `speech` | 1° | `#CBD5E1` Grey blue | 无 | — | Semak jadual data sebelum keluar. Nilai yang tertinggal sukar diganti apabila alat dan sampel sudah disimpan. |
| 39 | After Practical & Shared Safety | en | Ong Kai Z.<br>`demo_tutoran_makmal_039` | `academic` | `rect` | 0° | `#CFFAFE` Soft cyan | 无 | — | Write the conclusion from the recorded evidence, not from the answer you expected before the experiment. |
| 40 | After Practical & Shared Safety | en | 匿名<br>`demo_tutoran_makmal_040` | `campus_life` | `hexagon` | -1° | `#FDE68A` Golden yellow | 无 | — | Dispose of materials only in the container or location specified by the laboratory. Ordinary bins are not suitable for every type of waste. |
| 41 | After Practical & Shared Safety | en | Devika T.<br>`demo_tutoran_makmal_041` | `emotional` | `rounded` | 2° | `#BBF7D0` Soft green | `tutoran-makmal-clean-workbench-01.webp` | `cover` / 1.08 | A practical that does not work perfectly can still teach something. Review the procedure calmly before blaming a group member. |
| 42 | After Practical & Shared Safety | ms | 匿名<br>`demo_tutoran_makmal_042` | `campus_life` | `envelope` | -2° | `#BFDBFE` Soft blue | 无 | — | Sebelum meninggalkan blok, periksa meja, bawah kerusi dan rak beg. Nota kecil, kalkulator dan botol air mudah tertinggal. |

## 7. Codex导入契约

- `contextType: "building"`、`placeId: "B_BLOK_TUTORAN_MAKMAL"`。
- 使用本表指定的shape、color、rotation，不得重新随机。
- 匿名便贴的authorNickname必须为null；具名便贴使用表内displayName。
- 演示用户统一 `isDemoSeed: true`、`role: "user"`。
- 照片URL未批准前不得写入虚假链接、Base64占位内容或普通相对路径。
- 不得把安全建议替代讲师、课程或实验室的正式规定。
- 本批尚未批准导入；不得修改网站、commit、push或创建PR。

## 8. 验收、停止条件与回滚

- 42条全部归入B_BLOK_TUTORAN_MAKMAL；9条照片便贴与指定编号一致。
- 10种形状和10个颜色预设全部至少出现一次。
- 42个作者ID全部对应演示注册用户；同批次及前四批无重复显示名。
- 刷新、新设备首次打开及重复执行均不产生重复数据。
- 页面不显示内部邮箱、用户ID、isDemoSeed或资产管理字段。
- 照片缺失、字段不兼容、种子不幂等、实验室照片未获许可或页面明显卡顿时停止。
- 回滚只移除本批演示便贴和对应演示用户，不影响原有数据。
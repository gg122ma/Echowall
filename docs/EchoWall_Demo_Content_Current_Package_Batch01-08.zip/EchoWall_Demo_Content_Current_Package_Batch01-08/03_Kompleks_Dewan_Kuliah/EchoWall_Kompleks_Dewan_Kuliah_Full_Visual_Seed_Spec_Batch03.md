# EchoWall 演示便贴视觉配置完整版

## 批次 03：Kompleks Dewan Kuliah

> 状态：42条内容、照片槽位、形状、颜色与旋转已完成；尚未导入网站。

## 1. 总体判断

- 任务类型：`DOC + DATA`
- 风险等级：`L2`
- 变更规模：`S1`（本阶段仅完善文档）
- 准备状态：`READY`
- 执行模式：`DIRECT`

## 2. 地点与代码映射

- 建筑名称：**Kompleks Dewan Kuliah**
- `placeId`：`B_DEWAN_KULIAH`
- `wallKey`：`building:B_DEWAN_KULIAH`
- 当前建筑注册表：3层；多间大型讲堂与导修室环绕中央庭院。
- 学生指南使用DKB与DKK作为讲堂代码；具体教室必须以课表和现场门牌为准。

## 3. 来源边界

- 可确认：这里是进行kuliah或大型课程的讲堂区域，资料显示有DKB与DKK，并有冷气。
- 课程、换室、考试、座位和开放时间均属于时效性资料，不能由模拟留言替代正式通知。
- 文档内容属于地点功能衍生建议与模拟学生经验，不代表42条真实证言。
- 所有姓名、账号及留言均为虚构演示数据，不取自学生名单。

## 4. 数据摘要

- 便贴：42条
- 具名：23条；匿名：19条
- BM：24条；English：13条；中文：5条
- 带照片：9条（21.4%）
- 使用全部10种现有形状和全部10个现有颜色预设

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：3条
- `torn`（撕边）：4条
- `speech`（对话框）：3条
- `polaroid`（拍立得）：8条
- `ticket`（票券）：4条
- `hexagon`（六边形）：3条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

## 5. 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `dewan-kuliah-exterior-courtyard-01.webp` | Kompleks Dewan Kuliah外观或中央庭院，4:3横向；避免拍到清晰人脸。 | 可参考 school-environment PDF 第4及22页；建议用户自行补拍 | `cover` | 1.12 |
| 4 | `dewan-kuliah-room-code-01.webp` | DKB或DKK门牌与方向指示的局部；不得包含学生名单、考试座位表或受限通知。 | 需拍摄／用户自有 | `cover` | 1.08 |
| 9 | `dewan-kuliah-seats-01.webp` | 空讲堂的阶梯座位与讲台，画面整洁，无可辨认学生。 | 可参考 school-environment PDF 第22页；建议用户自行补拍 | `cover` | 1.10 |
| 13 | `dewan-kuliah-class-kit-01.webp` | 笔记本、薄外套、文具和已充电设备的桌面摆拍，不出现真实账号或姓名。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 18 | `dewan-kuliah-slide-notes-01.webp` | 通用讲义标题与学生自己整理的关键词笔记；不复制真实讲师课件或学生资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 25 | `dewan-kuliah-courtyard-break-01.webp` | 中央庭院、走廊或楼梯的空景，用于表现换课休息；不拍清晰人脸。 | 需拍摄／用户自有 | `cover` | 1.12 |
| 32 | `dewan-kuliah-exam-timetable-check-01.webp` | 虚构考试清单，只显示科目、时间和通用DKB/DKK代码；不得使用真实考试表或学生姓名。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 37 | `dewan-kuliah-exam-stationery-01.webp` | 文具、普通计算器、学生卡背面朝下的摆拍；不得显示卡号或个人资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.04 |
| 41 | `dewan-kuliah-clean-aisle-01.webp` | 整齐座位、清洁走道或讲堂出口，强调离场后保持空间整洁。 | 需拍摄／用户自有 | `cover` | 1.08 |

照片统一要求：4:3横向优先、WebP、单张目标不超过450KB；不得出现清晰人脸、学生名单、考试座位表、学号或账号资料。跨设备展示优先使用批准后的Cloudinary HTTPS URL。

## 6. 42条完整视觉字段

| No. | 分区 | 语言 | 显示 | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Finding Hall & Timetable | ms | Aina L.<br>`demo_dewan_kuliah_001` | `academic` | `polaroid` | -2° | `#BFDBFE` Soft blue | `dewan-kuliah-exterior-courtyard-01.webp` | `cover` / 1.12 | Semak kod dewan penuh pada jadual sebelum bergerak. DKB dan DKK berada dalam kompleks yang sama, tetapi pintu masuknya berbeza. |
| 2 | Finding Hall & Timetable | ms | 匿名<br>`demo_dewan_kuliah_002` | `academic` | `ticket` | 1° | `#FEF08A` Soft yellow | 无 | — | Kalau ini kali pertama datang, cari papan tanda dewan dahulu dan jangan ikut orang ramai tanpa menyemak nombor kelas sendiri. |
| 3 | Finding Hall & Timetable | en | Nicole C.<br>`demo_dewan_kuliah_003` | `academic` | `rounded` | 0° | `#BBF7D0` Soft green | 无 | — | Save a screenshot of the timetable before leaving the hostel. It is faster than reopening several messages while walking. |
| 4 | Finding Hall & Timetable | zh | 匿名<br>`demo_dewan_kuliah_004` | `academic` | `square` | 2° | `#FBCFE8` Soft pink | `dewan-kuliah-room-code-01.webp` | `cover` / 1.08 | 第一次来上课时先看完整教室编号。DKB和DKK虽然在同一个建筑群里，但不要只看“大讲堂”三个字。 |
| 5 | Finding Hall & Timetable | ms | Rhea S.<br>`demo_dewan_kuliah_005` | `campus_life` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Saya guna laman dalaman sebagai titik rujukan. Selepas kenal satu tangga dan satu pintu utama, pertukaran kelas jadi lebih mudah. |
| 6 | Finding Hall & Timetable | en | 匿名<br>`demo_dewan_kuliah_006` | `campus_life` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | If a class is moved, follow the lecturer or official notice. Old wall posts should only be treated as orientation tips. |
| 7 | Finding Hall & Timetable | ms | Syafiqa J.<br>`demo_dewan_kuliah_007` | `academic` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Datang beberapa minit awal pada minggu pertama. Masa tambahan itu cukup untuk semak pintu, tingkat dan susunan tempat duduk. |
| 8 | Finding Hall & Timetable | ms | 匿名<br>`demo_dewan_kuliah_008` | `campus_life` | `torn` | 2° | `#CBD5E1` Grey blue | 无 | — | Jangan berhenti lama di tengah laluan untuk membaca jadual. Berdiri di tepi supaya pelajar lain masih boleh lalu. |
| 9 | Before Lecture | en | Aisyah R.<br>`demo_dewan_kuliah_009` | `academic` | `polaroid` | 0° | `#CFFAFE` Soft cyan | `dewan-kuliah-seats-01.webp` | `cover` / 1.10 | Bring the lecture notes or download them before class. Large halls are not the best place to search for files at the last minute. |
| 10 | Before Lecture | ms | 匿名<br>`demo_dewan_kuliah_010` | `campus_life` | `circle` | -1° | `#FDE68A` Golden yellow | 无 | — | Dewan berhawa dingin boleh terasa sejuk selepas duduk lama. Bawa jaket nipis jika anda mudah kesejukan. |
| 11 | Before Lecture | ms | Lydia T.<br>`demo_dewan_kuliah_011` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | Sebelum pensyarah bermula, tulis tajuk dan tarikh pada nota. Perkara kecil ini memudahkan ulang kaji apabila banyak kuliah terkumpul. |
| 12 | Before Lecture | zh | 匿名<br>`demo_dewan_kuliah_012` | `campus_life` | `envelope` | -2° | `#E9D5FF` Soft purple | 无 | — | 大讲堂座位很多，和朋友约好在哪一排见面，不然进场后很容易互相找不到。 |
| 13 | Before Lecture | ms | Jia Hui O.<br>`demo_dewan_kuliah_013` | `academic` | `polaroid` | 1° | `#CBD5E1` Grey blue | `dewan-kuliah-class-kit-01.webp` | `contain` / 1.02 | Saya semak bateri kalkulator, tablet dan telefon sebelum keluar. Soket yang dekat belum tentu kosong atau boleh digunakan. |
| 14 | Before Lecture | ms | 匿名<br>`demo_dewan_kuliah_014` | `campus_life` | `ticket` | 0° | `#FED7AA` Soft orange | 无 | — | Bawa air secukupnya jika dibenarkan, tetapi ikut peraturan kelas tentang makanan dan minuman. |
| 15 | Before Lecture | en | Elaine G.<br>`demo_dewan_kuliah_015` | `academic` | `square` | -1° | `#FFF7ED` Warm cream | 无 | — | Choose a seat where you can see the screen clearly. Sitting too far to the side can make diagrams and small text difficult to read. |
| 16 | Before Lecture | ms | 匿名<br>`demo_dewan_kuliah_016` | `campus_life` | `rect` | 2° | `#CFFAFE` Soft cyan | 无 | — | Masuk dengan teratur dan isi tempat duduk dari bahagian dalam baris jika keadaan sesak. Jangan biarkan orang lain memanjat beg anda. |
| 17 | During Lecture | ms | Karthik V.<br>`demo_dewan_kuliah_017` | `academic` | `torn` | -2° | `#FDE68A` Golden yellow | 无 | — | Untuk kuliah yang laju, catat kata kunci dan tanda bahagian yang perlu disemak kemudian. Jangan cuba menyalin setiap ayat. |
| 18 | During Lecture | en | 匿名<br>`demo_dewan_kuliah_018` | `academic` | `polaroid` | 1° | `#BBF7D0` Soft green | `dewan-kuliah-slide-notes-01.webp` | `contain` / 1.00 | If a slide changes too quickly, note the slide title and continue listening. Ask for clarification after the main explanation. |
| 19 | During Lecture | ms | Fikri Z.<br>`demo_dewan_kuliah_019` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Saya lukis simbol kecil di tepi nota apabila tidak faham. Selepas kelas, saya terus tahu bahagian mana yang perlu ditanya. |
| 20 | During Lecture | zh | 匿名<br>`demo_dewan_kuliah_020` | `academic` | `speech` | -1° | `#BFDBFE` Soft blue | 无 | — | 听不清楚时先记下关键词，不要一直和旁边的人讨论。下课后再确认，比较不会影响其他同学。 |
| 21 | During Lecture | en | Ammar D.<br>`demo_dewan_kuliah_021` | `campus_life` | `hexagon` | 2° | `#E9D5FF` Soft purple | 无 | — | Keep devices on silent mode. Notification sounds travel much farther in a lecture hall than in a small classroom. |
| 22 | During Lecture | ms | 匿名<br>`demo_dewan_kuliah_022` | `academic` | `envelope` | -2° | `#CBD5E1` Grey blue | 无 | — | Jika pensyarah beri contoh tambahan secara lisan, catat terus. Contoh seperti itu kadang-kadang tidak ada dalam slaid. |
| 23 | During Lecture | ms | Ridzwan B.<br>`demo_dewan_kuliah_023` | `campus_life` | `rect` | 1° | `#CFFAFE` Soft cyan | 无 | — | Elakkan meletakkan beg di laluan atau tangga. Laluan perlu kekal jelas apabila ramai pelajar keluar serentak. |
| 24 | During Lecture | en | 匿名<br>`demo_dewan_kuliah_024` | `academic` | `circle` | 0° | `#FEF08A` Soft yellow | 无 | — | At the end of the lecture, write one sentence summarising the main idea. It reveals whether you actually understood the session. |
| 25 | Between Classes & Courtyard | ms | Aqeela M.<br>`demo_dewan_kuliah_025` | `campus_life` | `polaroid` | -1° | `#FED7AA` Soft orange | `dewan-kuliah-courtyard-break-01.webp` | `cover` / 1.12 | Laman dalaman sesuai dijadikan titik berkumpul, tetapi jangan menghalang pintu dewan ketika kelas sedang bertukar. |
| 26 | Between Classes & Courtyard | en | 匿名<br>`demo_dewan_kuliah_026` | `campus_life` | `ticket` | 2° | `#FFF7ED` Warm cream | 无 | — | During a short break, check the next room code before chatting. Ten minutes disappears quickly in a large complex. |
| 27 | Between Classes & Courtyard | ms | Hani S.<br>`demo_dewan_kuliah_027` | `academic` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Saya gunakan masa antara kelas untuk semak satu soalan sahaja. Sasaran kecil lebih realistik daripada cuba mengulang satu bab penuh. |
| 28 | Between Classes & Courtyard | zh | 匿名<br>`demo_dewan_kuliah_028` | `campus_life` | `square` | 1° | `#E9D5FF` Soft purple | 无 | — | 换课时间人很多，先走到走廊旁边再看手机，不要停在门口或楼梯中间。 |
| 29 | Between Classes & Courtyard | ms | Syazana T.<br>`demo_dewan_kuliah_029` | `campus_life` | `torn` | 0° | `#CBD5E1` Grey blue | 无 | — | Jika mahu mengambil gambar kenangan, pilih sudut yang tidak menunjukkan wajah orang lain atau kawasan terhad. |
| 30 | Between Classes & Courtyard | en | 匿名<br>`demo_dewan_kuliah_030` | `emotional` | `speech` | -1° | `#CFFAFE` Soft cyan | 无 | — | A few quiet minutes in the courtyard helped me reset after a difficult lecture. I returned to class less frustrated. |
| 31 | Between Classes & Courtyard | ms | Nur Huda W.<br>`demo_dewan_kuliah_031` | `campus_life` | `envelope` | 2° | `#FDE68A` Golden yellow | 无 | — | Sebelum meninggalkan kawasan ini, semak semula kad matrik, alat tulis dan botol air. Barang kecil mudah tertinggal di bawah kerusi. |
| 32 | Assessment & Exam | en | Eng Wei J.<br>`demo_dewan_kuliah_032` | `academic` | `polaroid` | -2° | `#BBF7D0` Soft green | `dewan-kuliah-exam-timetable-check-01.webp` | `contain` / 1.00 | For tests or examinations, use the official timetable as the source of truth. A familiar building does not guarantee the same room. |
| 33 | Assessment & Exam | ms | 匿名<br>`demo_dewan_kuliah_033` | `academic` | `hexagon` | 1° | `#FBCFE8` Soft pink | 无 | — | Sediakan alat tulis pada malam sebelumnya. Pagi peperiksaan bukan masa yang sesuai untuk mencari pemadam atau bateri kalkulator. |
| 34 | Assessment & Exam | ms | Hariz Q.<br>`demo_dewan_kuliah_034` | `academic` | `rounded` | 0° | `#FED7AA` Soft orange | 无 | — | Saya tulis kod dewan, masa dan subjek pada satu nota kecil. Cara ini mengurangkan risiko tersalah masuk ketika terlalu cemas. |
| 35 | Assessment & Exam | en | 匿名<br>`demo_dewan_kuliah_035` | `emotional` | `ticket` | -1° | `#FFF7ED` Warm cream | 无 | — | Arriving early gave me enough time to settle down and check my materials. Rushing into the hall made simple instructions harder to follow. |
| 36 | Assessment & Exam | ms | Arjun F.<br>`demo_dewan_kuliah_036` | `academic` | `rect` | 2° | `#BFDBFE` Soft blue | 无 | — | Jika nombor tempat duduk ditetapkan, cari dengan tenang dan ikut arahan pengawas. Jangan pindahkan label atau susunan kerusi. |
| 37 | Assessment & Exam | zh | 匿名<br>`demo_dewan_kuliah_037` | `academic` | `polaroid` | -2° | `#E9D5FF` Soft purple | `dewan-kuliah-exam-stationery-01.webp` | `contain` / 1.04 | 考试地点一定要以正式时间表为准。留言墙只能提供经验，不能代替学校最新通知。 |
| 38 | Assessment & Exam | ms | Benjamin S.<br>`demo_dewan_kuliah_038` | `emotional` | `circle` | 1° | `#CBD5E1` Grey blue | 无 | — | Selepas ujian, catat topik yang paling sukar semasa ingatan masih jelas. Itu lebih berguna daripada hanya membandingkan jawapan. |
| 39 | Shared Space & Facilities | en | Qayyum R.<br>`demo_dewan_kuliah_039` | `campus_life` | `square` | 0° | `#CFFAFE` Soft cyan | 无 | — | Report projector, air-conditioning or seat problems to the lecturer or responsible unit. Do not try to dismantle equipment. |
| 40 | Shared Space & Facilities | ms | 匿名<br>`demo_dewan_kuliah_040` | `campus_life` | `torn` | -1° | `#FDE68A` Golden yellow | 无 | — | Selepas kelas, buang sampah dan susun semula kerusi jika diarahkan. Dewan seterusnya akan digunakan oleh kumpulan lain. |
| 41 | Shared Space & Facilities | en | Zehra C.<br>`demo_dewan_kuliah_041` | `campus_life` | `polaroid` | 2° | `#BBF7D0` Soft green | `dewan-kuliah-clean-aisle-01.webp` | `cover` / 1.08 | Take photos only when permitted, and avoid capturing restricted notices, student lists or recognisable faces. |
| 42 | Shared Space & Facilities | ms | Hanif G.<br>`demo_dewan_kuliah_042` | `campus_life` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Jika terjumpa barang tertinggal, serahkan kepada pensyarah atau unit yang ditetapkan. Jangan siarkan butiran barang secara berlebihan. |

## 7. Codex导入契约

- `contextType: "building"`、`placeId: "B_DEWAN_KULIAH"`。
- 使用本表指定的shape、color、rotation，不得重新随机。
- 匿名便贴的authorNickname必须为null；具名便贴使用表内displayName。
- 演示用户统一 `isDemoSeed: true`、`role: "user"`。
- 照片URL未批准前不得写入虚假链接或普通相对路径。
- 本批尚未批准导入；不得修改网站、commit、push或创建PR。

## 8. 验收、停止条件与回滚

- 42条全部归入B_DEWAN_KULIAH；9条照片便贴与指定编号一致。
- 10种形状和10个颜色预设全部至少出现一次。
- 42个作者ID全部对应演示注册用户；同批次无重复显示名。
- 刷新、新设备首次打开及重复执行均不产生重复数据。
- 页面不显示内部邮箱、用户ID、isDemoSeed或资产管理字段。
- 照片缺失、字段不兼容、种子不幂等或页面明显卡顿时停止。
- 回滚只移除本批演示便贴和对应演示用户，不影响原有数据。
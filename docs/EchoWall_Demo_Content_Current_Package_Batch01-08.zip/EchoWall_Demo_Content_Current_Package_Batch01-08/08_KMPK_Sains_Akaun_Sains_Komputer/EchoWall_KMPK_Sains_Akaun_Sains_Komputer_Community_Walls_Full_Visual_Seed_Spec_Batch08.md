# EchoWall KMPK 社区留言墙视觉配置完整版

## 批次 08：Kolej Matrikulasi Perak（KMPK）

> 状态：3个community walls、126条便贴、90个虚构演示用户、24个照片槽位，以及全部形状/颜色配置已完成；尚未导入网站。

## 1. 总体判断

- 任务类型：`DOC + DATA`
- 风险等级：`L2`
- 变更规模：`S2`（3个相关community walls与共享用户池）
- 准备状态：`READY`
- 执行模式：`STANDARD`
- 推荐流程：`Chat生成与审核 → 完成其余学院 → Codex分阶段导入`

## 2. 网站映射

- 机构：**KMPK**；`orgId: 4`
- Community wall按`orgId + majorId`过滤，不按batch建立重复留言墙。

| Major ID | 社区留言墙 | 便贴 | 照片槽位 |
|---:|---|---:|---:|
| 10 | Sains | 42 | 8 |
| 11 | Akaun | 42 | 8 |
| 12 | Sains Komputer | 42 | 8 |

KMPK对应batchId：`10`（Batch 06）、`11`（Batch 07）、`12`（Batch 08）。

## 3. 内容与事实边界

- Sains：学习结构、数学与数据、Biology/Chemistry/Physics联系、实验报告、tutorial、assessment与wellbeing。
- Akaun：交易分析、journal/ledger、adjustment、financial statements、economics/business联系、spreadsheet、assessment与wellbeing。
- Sains Komputer：问题拆解、pseudocode、coding/debugging、data structures、testing、versioning、privacy、项目责任与assessment。
- 不编造KMPK特定建筑、讲师、实验室设备、开放时间、课程规则、考试格式或真实学生经历。
- 具体模块、编程语言、实验安全、考核和学院安排必须以学院及讲师正式资料为准。
- 所有用户、姓名、邮箱和留言均为虚构演示数据；不得称为真实注册、真实采用或真实学生反馈。

## 4. 学院级数据摘要

- Community walls：3
- 便贴：126（每墙42）
- 每墙具名23、匿名19
- 每墙BM 24、English 13、中文5
- 演示用户：90；54人出现1次，36人跨两个墙各出现1次
- 同一用户在同一个墙最多出现一次
- 照片槽位：24（每墙8，约19.0%）
- 每墙均使用全部10种现有形状和全部10个颜色预设
- 126条正文全部不同；显示名不与前七批重复

## 5. KMPK演示注册用户池

> 所有账户必须设为`isDemoSeed: true`、`role: user`。`.invalid`邮箱不用于真实投递。匿名便贴仍保留内部authorUserId。

| User ID | 显示名 | 演示邮箱 | Primary major | Batch ID / Label | 使用次数 |
|---|---|---|---|---|---:|
| `demo_kmpk_001` | Aabidah A. | `kmpk.demo.001@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_002` | Abinesh B. | `kmpk.demo.002@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_003` | Adelia C. | `kmpk.demo.003@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_004` | Afiqah D. | `kmpk.demo.004@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_005` | Akhilesh E. | `kmpk.demo.005@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_006` | Alessia F. | `kmpk.demo.006@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_007` | Alifia G. | `kmpk.demo.007@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_008` | Amirah H. | `kmpk.demo.008@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_009` | Ananthan I. | `kmpk.demo.009@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_010` | Anisah J. | `kmpk.demo.010@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_011` | Arissa K. | `kmpk.demo.011@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_012` | Ashveen L. | `kmpk.demo.012@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_013` | Aurelia M. | `kmpk.demo.013@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_014` | Azhari N. | `kmpk.demo.014@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_015` | Badrul O. | `kmpk.demo.015@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_016` | Beatrice P. | `kmpk.demo.016@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_017` | Cahaya Q. | `kmpk.demo.017@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_018` | Caleb R. | `kmpk.demo.018@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_019` | Chan Yi S. | `kmpk.demo.019@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_020` | Dania T. | `kmpk.demo.020@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_021` | Darwisy U. | `kmpk.demo.021@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_022` | Davin V. | `kmpk.demo.022@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_023` | Diyana W. | `kmpk.demo.023@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_024` | Ehsan X. | `kmpk.demo.024@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_025` | Elisha Y. | `kmpk.demo.025@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_026` | Emir Z. | `kmpk.demo.026@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_027` | Eshal A. | `kmpk.demo.027@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_028` | Fadhlan B. | `kmpk.demo.028@echowall.invalid` | Sains | `10` / Batch 06 | 1 |
| `demo_kmpk_029` | Faye C. | `kmpk.demo.029@echowall.invalid` | Sains | `11` / Batch 07 | 1 |
| `demo_kmpk_030` | Felicia D. | `kmpk.demo.030@echowall.invalid` | Sains | `12` / Batch 08 | 1 |
| `demo_kmpk_031` | Gokul E. | `kmpk.demo.031@echowall.invalid` | Akaun | `10` / Batch 06 | 2 |
| `demo_kmpk_032` | Gwen F. | `kmpk.demo.032@echowall.invalid` | Akaun | `11` / Batch 07 | 2 |
| `demo_kmpk_033` | Hakeem G. | `kmpk.demo.033@echowall.invalid` | Akaun | `12` / Batch 08 | 2 |
| `demo_kmpk_034` | Hannah Mae H. | `kmpk.demo.034@echowall.invalid` | Akaun | `10` / Batch 06 | 2 |
| `demo_kmpk_035` | Harisya I. | `kmpk.demo.035@echowall.invalid` | Akaun | `11` / Batch 07 | 2 |
| `demo_kmpk_036` | Harveen J. | `kmpk.demo.036@echowall.invalid` | Akaun | `12` / Batch 08 | 2 |
| `demo_kmpk_037` | Husaini K. | `kmpk.demo.037@echowall.invalid` | Akaun | `10` / Batch 06 | 2 |
| `demo_kmpk_038` | Imaan L. | `kmpk.demo.038@echowall.invalid` | Akaun | `11` / Batch 07 | 2 |
| `demo_kmpk_039` | Indira M. | `kmpk.demo.039@echowall.invalid` | Akaun | `12` / Batch 08 | 2 |
| `demo_kmpk_040` | Ishaaq N. | `kmpk.demo.040@echowall.invalid` | Akaun | `10` / Batch 06 | 2 |
| `demo_kmpk_041` | Jannah O. | `kmpk.demo.041@echowall.invalid` | Akaun | `11` / Batch 07 | 2 |
| `demo_kmpk_042` | Jaren P. | `kmpk.demo.042@echowall.invalid` | Akaun | `12` / Batch 08 | 2 |
| `demo_kmpk_043` | Jayashree Q. | `kmpk.demo.043@echowall.invalid` | Akaun | `10` / Batch 06 | 1 |
| `demo_kmpk_044` | Jia Ning R. | `kmpk.demo.044@echowall.invalid` | Akaun | `11` / Batch 07 | 1 |
| `demo_kmpk_045` | Kamilia S. | `kmpk.demo.045@echowall.invalid` | Akaun | `12` / Batch 08 | 1 |
| `demo_kmpk_046` | Kavinraj T. | `kmpk.demo.046@echowall.invalid` | Akaun | `10` / Batch 06 | 1 |
| `demo_kmpk_047` | Khairul U. | `kmpk.demo.047@echowall.invalid` | Akaun | `11` / Batch 07 | 1 |
| `demo_kmpk_048` | Kiara V. | `kmpk.demo.048@echowall.invalid` | Akaun | `12` / Batch 08 | 1 |
| `demo_kmpk_049` | Lailatul W. | `kmpk.demo.049@echowall.invalid` | Akaun | `10` / Batch 06 | 2 |
| `demo_kmpk_050` | Lavanya X. | `kmpk.demo.050@echowall.invalid` | Akaun | `11` / Batch 07 | 2 |
| `demo_kmpk_051` | Leonard Y. | `kmpk.demo.051@echowall.invalid` | Akaun | `12` / Batch 08 | 2 |
| `demo_kmpk_052` | Li Xuan Z. | `kmpk.demo.052@echowall.invalid` | Akaun | `10` / Batch 06 | 2 |
| `demo_kmpk_053` | Maisarah Nur A. | `kmpk.demo.053@echowall.invalid` | Akaun | `11` / Batch 07 | 2 |
| `demo_kmpk_054` | Manveen B. | `kmpk.demo.054@echowall.invalid` | Akaun | `12` / Batch 08 | 2 |
| `demo_kmpk_055` | Mikayla C. | `kmpk.demo.055@echowall.invalid` | Akaun | `10` / Batch 06 | 2 |
| `demo_kmpk_056` | Mueez D. | `kmpk.demo.056@echowall.invalid` | Akaun | `11` / Batch 07 | 2 |
| `demo_kmpk_057` | Nadhirah E. | `kmpk.demo.057@echowall.invalid` | Akaun | `12` / Batch 08 | 2 |
| `demo_kmpk_058` | Naren F. | `kmpk.demo.058@echowall.invalid` | Akaun | `10` / Batch 06 | 2 |
| `demo_kmpk_059` | Natasha G. | `kmpk.demo.059@echowall.invalid` | Akaun | `11` / Batch 07 | 2 |
| `demo_kmpk_060` | Naufal H. | `kmpk.demo.060@echowall.invalid` | Akaun | `12` / Batch 08 | 2 |
| `demo_kmpk_061` | Nisha I. | `kmpk.demo.061@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 2 |
| `demo_kmpk_062` | Nurayuni J. | `kmpk.demo.062@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 2 |
| `demo_kmpk_063` | Orked K. | `kmpk.demo.063@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 2 |
| `demo_kmpk_064` | Pavithran L. | `kmpk.demo.064@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 2 |
| `demo_kmpk_065` | Qaleesya M. | `kmpk.demo.065@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 2 |
| `demo_kmpk_066` | Qistina Nur N. | `kmpk.demo.066@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 2 |
| `demo_kmpk_067` | Raihanah O. | `kmpk.demo.067@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 2 |
| `demo_kmpk_068` | Rakesh P. | `kmpk.demo.068@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 2 |
| `demo_kmpk_069` | Reanna Q. | `kmpk.demo.069@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 2 |
| `demo_kmpk_070` | Rifqi R. | `kmpk.demo.070@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 2 |
| `demo_kmpk_071` | Roshan S. | `kmpk.demo.071@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 2 |
| `demo_kmpk_072` | Safiyyah T. | `kmpk.demo.072@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 2 |
| `demo_kmpk_073` | Sakthivel U. | `kmpk.demo.073@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 1 |
| `demo_kmpk_074` | Salsabila V. | `kmpk.demo.074@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 1 |
| `demo_kmpk_075` | Samuel Lee W. | `kmpk.demo.075@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 1 |
| `demo_kmpk_076` | Shaqira X. | `kmpk.demo.076@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 1 |
| `demo_kmpk_077` | Shazwan Y. | `kmpk.demo.077@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 1 |
| `demo_kmpk_078` | Sonia Z. | `kmpk.demo.078@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 1 |
| `demo_kmpk_079` | Tharani A. | `kmpk.demo.079@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 1 |
| `demo_kmpk_080` | Theodore B. | `kmpk.demo.080@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 1 |
| `demo_kmpk_081` | Umairah C. | `kmpk.demo.081@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 1 |
| `demo_kmpk_082` | Vaishnavi D. | `kmpk.demo.082@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 1 |
| `demo_kmpk_083` | Vijayen E. | `kmpk.demo.083@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 1 |
| `demo_kmpk_084` | Wafiq F. | `kmpk.demo.084@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 1 |
| `demo_kmpk_085` | Wan Ning G. | `kmpk.demo.085@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 1 |
| `demo_kmpk_086` | Xavier H. | `kmpk.demo.086@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 1 |
| `demo_kmpk_087` | Yashini I. | `kmpk.demo.087@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 1 |
| `demo_kmpk_088` | Yong Han J. | `kmpk.demo.088@echowall.invalid` | Sains Komputer | `10` / Batch 06 | 1 |
| `demo_kmpk_089` | Zahin K. | `kmpk.demo.089@echowall.invalid` | Sains Komputer | `11` / Batch 07 | 1 |
| `demo_kmpk_090` | Zara Imani L. | `kmpk.demo.090@echowall.invalid` | Sains Komputer | `12` / Batch 08 | 1 |

## 6. Sains（majorId 10）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 4 + majorId`的community wall，不创建建筑、地图地点或batch专属墙。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmpk-sains-weekly-topic-board-01.webp` | 理科每周主题板、文件夹和短任务清单的桌面摆拍；不显示个人日程或账号。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 8 | `kmpk-sains-given-formula-unit-01.webp` | 写有given、wanted、formula和unit的通用计算working，不使用正式考题。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 15 | `kmpk-sains-bio-chem-physics-map-01.webp` | 连接Biology、Chemistry和Physics概念的通用手绘图；不冒充学院课件。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 22 | `kmpk-sains-practical-data-table-01.webp` | 空白观察表、单位栏与实验前检查清单；具体安全要求以正式指示为准。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 25 | `kmpk-sains-graph-review-01.webp` | 虚构数据图表，标有轴、单位、趋势和一个待检查异常点。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 29 | `kmpk-sains-tutorial-working-01.webp` | 已尝试的通用练习working和圈出的第一处疑问；不出现分数或姓名。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 36 | `kmpk-sains-error-categories-01.webp` | 按concept、calculation、unit和instruction分类的错误记录卡。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 40 | `kmpk-sains-active-recall-plan-01.webp` | 包含active recall、短练习、轻复习和睡眠的通用考试周计划。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |

### 42条完整视觉字段

| No. | 分区 | Batch ID | 语言 | 显示 | Author ID | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Weekly Structure & Foundations | `10` | ms | Aabidah A. | `demo_kmpk_001` | `academic` | `polaroid` | -2° | `#BFDBFE` Soft blue | `kmpk-sains-weekly-topic-board-01.webp` | `contain` / 1.02 | Bahagikan minggu kepada sesi memahami konsep, latihan dan semakan kesilapan. Membaca nota sahaja tidak menunjukkan sama ada anda boleh menggunakan idea tersebut. |
| 2 | Weekly Structure & Foundations | `11` | ms | 匿名 | `demo_kmpk_002` | `academic` | `rounded` | 1° | `#FEF08A` Soft yellow | 无 | — | Mulakan topik baharu dengan senarai istilah, hubungan utama dan satu contoh. Struktur awal membantu nota kekal tersusun apabila kandungan semakin banyak. |
| 3 | Weekly Structure & Foundations | `12` | en | Adelia C. | `demo_kmpk_003` | `academic` | `ticket` | 0° | `#BBF7D0` Soft green | 无 | — | Set one measurable result for each study block, such as completing a diagram, checking five calculations or explaining a process aloud. |
| 4 | Weekly Structure & Foundations | `10` | zh | 匿名 | `demo_kmpk_004` | `academic` | `square` | 2° | `#FBCFE8` Soft pink | 无 | — | 理科复习不要只看当天最喜欢的科目。把较弱的章节安排在精神较好的时间，并保留短时间复习已经掌握的内容。 |
| 5 | Weekly Structure & Foundations | `11` | ms | Akhilesh E. | `demo_kmpk_005` | `campus_life` | `hexagon` | -1° | `#FED7AA` Soft orange | 无 | — | Gunakan nama fail dan folder yang konsisten untuk nota, latihan dan laporan. Bahan yang mudah dicari mengurangkan tekanan semasa minggu sibuk. |
| 6 | Weekly Structure & Foundations | `12` | en | 匿名 | `demo_kmpk_006` | `emotional` | `speech` | 1° | `#FFF7ED` Warm cream | 无 | — | When several chapters feel unfinished, identify the earliest missing idea. Fixing one foundation often makes later topics easier. |
| 7 | Weekly Structure & Foundations | `10` | ms | Alifia G. | `demo_kmpk_007` | `academic` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Pada hujung minggu, cuba tulis semula rangka topik tanpa melihat nota. Bahagian yang kosong menunjukkan apa yang perlu diulang. |
| 8 | Mathematics, Graphs & Data | `11` | ms | 匿名 | `demo_kmpk_008` | `academic` | `envelope` | 2° | `#CBD5E1` Grey blue | `kmpk-sains-given-formula-unit-01.webp` | `contain` / 1.00 | Sebelum mengira, tulis kuantiti diberi, perkara yang dicari, formula dan unit. Susunan ini membantu mengelakkan nombor dimasukkan terlalu awal. |
| 9 | Mathematics, Graphs & Data | `12` | ms | Ananthan I. | `demo_kmpk_009` | `academic` | `torn` | 0° | `#CFFAFE` Soft cyan | 无 | — | Semak sama ada jawapan patut positif, negatif, besar atau kecil sebelum menekan kalkulator. Anggaran awal boleh mengesan banyak kesilapan input. |
| 10 | Mathematics, Graphs & Data | `10` | en | Anisah J. | `demo_kmpk_010` | `academic` | `circle` | -1° | `#FDE68A` Golden yellow | 无 | — | For graphs, label both axes and units before plotting. A neat curve cannot repair a graph built from the wrong variables. |
| 11 | Mathematics, Graphs & Data | `11` | zh | 匿名 | `demo_kmpk_011` | `academic` | `rounded` | 2° | `#BFDBFE` Soft blue | 无 | — | 处理数据时先检查单位和有效数字。数值看起来接近，不代表可以直接放在同一张表里比较。 |
| 12 | Mathematics, Graphs & Data | `12` | ms | Ashveen L. | `demo_kmpk_012` | `academic` | `polaroid` | -2° | `#E9D5FF` Soft purple | 无 | — | Jika langkah algebra terlalu panjang, semak setiap perubahan pada satu baris. Melompat beberapa langkah memudahkan tanda negatif atau kuasa hilang. |
| 13 | Mathematics, Graphs & Data | `10` | en | 匿名 | `demo_kmpk_013` | `academic` | `square` | 1° | `#CBD5E1` Grey blue | 无 | — | Separate random variation from a consistent pattern. One unusual point deserves checking, but it should not automatically be deleted. |
| 14 | Mathematics, Graphs & Data | `11` | ms | Azhari N. | `demo_kmpk_014` | `academic` | `ticket` | 0° | `#FED7AA` Soft orange | 无 | — | Simpan log kesilapan mengikut kategori seperti formula, unit, graf dan pembacaan soalan. Setiap kategori memerlukan latihan yang berbeza. |
| 15 | Biology, Chemistry & Physics Links | `12` | ms | Badrul O. | `demo_kmpk_015` | `academic` | `speech` | -1° | `#FFF7ED` Warm cream | `kmpk-sains-bio-chem-physics-map-01.webp` | `contain` / 1.02 | Dalam Biology, susun proses mengikut urutan dan lokasi. Mengetahui apa yang berlaku tanpa mengetahui tempatnya boleh menghasilkan penerangan yang kabur. |
| 16 | Biology, Chemistry & Physics Links | `10` | ms | 匿名 | `demo_kmpk_016` | `academic` | `rect` | 2° | `#CFFAFE` Soft cyan | 无 | — | Untuk Chemistry, hubungkan persamaan dengan zarah, tenaga dan pemerhatian. Simbol menjadi lebih mudah diingat apabila perubahan sebenar difahami. |
| 17 | Biology, Chemistry & Physics Links | `11` | en | Cahaya Q. | `demo_kmpk_017` | `academic` | `hexagon` | -2° | `#FDE68A` Golden yellow | 无 | — | In Physics, draw the system boundary and choose a reference direction before selecting equations. Keep that convention until the end. |
| 18 | Biology, Chemistry & Physics Links | `12` | zh | 匿名 | `demo_kmpk_018` | `academic` | `envelope` | 1° | `#BBF7D0` Soft green | 无 | — | 遇到容易混淆的过程时，可以比较发生条件、位置、输入和结果。对照表比背两段相似文字更清楚。 |
| 19 | Biology, Chemistry & Physics Links | `10` | ms | Chan Yi S. | `demo_kmpk_019` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Gunakan satu peta konsep untuk menunjukkan bagaimana perubahan pada skala kecil menghasilkan kesan yang boleh diperhatikan. |
| 20 | Biology, Chemistry & Physics Links | `11` | en | 匿名 | `demo_kmpk_020` | `academic` | `torn` | -1° | `#BFDBFE` Soft blue | 无 | — | Explain the same idea using a diagram, a sentence and an example. Agreement across all three forms is a useful understanding check. |
| 21 | Biology, Chemistry & Physics Links | `12` | ms | Darwisy U. | `demo_kmpk_021` | `academic` | `polaroid` | 2° | `#E9D5FF` Soft purple | 无 | — | Bezakan fakta yang diperhatikan daripada sebab yang dicadangkan. Pemerhatian dan inferens perlu ditulis sebagai dua perkara berlainan. |
| 22 | Practical Work & Scientific Reports | `10` | ms | 匿名 | `demo_kmpk_022` | `academic` | `circle` | -2° | `#CBD5E1` Grey blue | `kmpk-sains-practical-data-table-01.webp` | `contain` / 1.00 | Sebelum amali, baca objektif dan kenal pasti data yang perlu direkodkan. Jadual kosong yang disediakan awal mengurangkan catatan tergesa-gesa. |
| 23 | Practical Work & Scientific Reports | `11` | ms | Diyana W. | `demo_kmpk_023` | `campus_life` | `square` | 1° | `#CFFAFE` Soft cyan | 无 | — | Ikut arahan pensyarah dan makmal tentang pakaian, radas serta pelupusan. Nasihat komuniti tidak boleh menggantikan peraturan keselamatan rasmi. |
| 24 | Practical Work & Scientific Reports | `12` | en | Ehsan X. | `demo_kmpk_024` | `academic` | `ticket` | 0° | `#FEF08A` Soft yellow | 无 | — | Record the actual observation immediately, including unexpected results. A report should explain the evidence, not rewrite it to match expectations. |
| 25 | Practical Work & Scientific Reports | `10` | zh | 匿名 | `demo_kmpk_025` | `academic` | `rect` | -1° | `#FED7AA` Soft orange | `kmpk-sains-graph-review-01.webp` | `contain` / 1.00 | 画实验图表时把变量、单位、比例和异常点检查清楚。结论必须来自记录的数据，而不是预先想好的答案。 |
| 26 | Practical Work & Scientific Reports | `11` | ms | Emir Z. | `demo_kmpk_026` | `academic` | `speech` | 2° | `#FFF7ED` Warm cream | 无 | — | Dalam perbincangan laporan, terangkan pola, ketidakpastian dan batas kaedah. Jangan hanya menyalin semula jadual keputusan. |
| 27 | Practical Work & Scientific Reports | `12` | en | 匿名 | `demo_kmpk_027` | `academic` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Assign group roles, but make sure every member understands the procedure and result. A report should not depend on one person's memory. |
| 28 | Practical Work & Scientific Reports | `10` | ms | Fadhlan B. | `demo_kmpk_028` | `academic` | `hexagon` | 1° | `#E9D5FF` Soft purple | 无 | — | Sebelum menghantar laporan, semak tajuk jadual, unit, label rajah dan rujukan. Kesilapan kecil boleh mengubah maksud data. |
| 29 | Tutorial, Resources & Peer Learning | `11` | ms | Faye C. | `demo_kmpk_029` | `academic` | `envelope` | 0° | `#CBD5E1` Grey blue | `kmpk-sains-tutorial-working-01.webp` | `contain` / 1.02 | Bawa working yang sudah dicuba ke tutorial dan tandakan langkah pertama yang tidak difahami. Soalan yang khusus mendapat jawapan yang lebih berguna. |
| 30 | Tutorial, Resources & Peer Learning | `12` | ms | 匿名 | `demo_kmpk_030` | `academic` | `polaroid` | -1° | `#CFFAFE` Soft cyan | 无 | — | Dalam kumpulan, minta setiap orang menerangkan satu konsep tanpa membaca nota. Perbezaan penerangan boleh mendedahkan salah faham. |
| 31 | Tutorial, Resources & Peer Learning | `10` | en | Gokul E. | `demo_kmpk_031` | `academic` | `torn` | 2° | `#FDE68A` Golden yellow | 无 | — | When sharing a resource, state the topic, level and reason it helps. A link without context is difficult for others to evaluate. |
| 32 | Tutorial, Resources & Peer Learning | `11` | zh | 匿名 | `demo_kmpk_032` | `academic` | `circle` | -2° | `#BBF7D0` Soft green | 无 | — | 请教别人之前先写下自己尝试过的方法。这样可以避免重复同样的步骤，也更容易找到真正的问题。 |
| 33 | Tutorial, Resources & Peer Learning | `12` | ms | Hakeem G. | `demo_kmpk_033` | `academic` | `square` | 1° | `#FBCFE8` Soft pink | 无 | — | Bandingkan sumber tambahan dengan modul dan kehendak pensyarah. Tajuk yang sama mungkin diterangkan pada tahap yang berbeza. |
| 34 | Tutorial, Resources & Peer Learning | `10` | en | 匿名 | `demo_kmpk_034` | `campus_life` | `rounded` | 0° | `#FED7AA` Soft orange | 无 | — | Keep shared notes organised by date and topic. Clear file names prevent the group from revising an outdated version. |
| 35 | Tutorial, Resources & Peer Learning | `11` | ms | Harisya I. | `demo_kmpk_035` | `koko` | `ticket` | -1° | `#FFF7ED` Warm cream | 无 | — | Aktiviti sains atau sesi perkongsian lebih berguna apabila anda membawa soalan dan menulis perkara yang perlu disahkan selepas program. |
| 36 | Assessment, Wellbeing & Direction | `12` | ms | 匿名 | `demo_kmpk_036` | `academic` | `rect` | 2° | `#BFDBFE` Soft blue | `kmpk-sains-error-categories-01.webp` | `contain` / 1.00 | Selepas penilaian, asingkan kesilapan kepada konsep, pengiraan, unit dan salah membaca arahan. Corak kesilapan membantu menentukan latihan seterusnya. |
| 37 | Assessment, Wellbeing & Direction | `10` | ms | Husaini K. | `demo_kmpk_037` | `emotional` | `speech` | -2° | `#E9D5FF` Soft purple | 无 | — | Jika jadual ulang kaji mula gagal, kurangkan sasaran dan bina semula secara berperingkat. Pelan kecil yang konsisten lebih berguna daripada pelan sempurna yang tidak dijalankan. |
| 38 | Assessment, Wellbeing & Direction | `11` | en | 匿名 | `demo_kmpk_038` | `academic` | `hexagon` | 1° | `#CBD5E1` Grey blue | 无 | — | Use practice questions to retrieve and apply knowledge, not to memorise the appearance of a marking scheme. |
| 39 | Assessment, Wellbeing & Direction | `12` | en | Indira M. | `demo_kmpk_039` | `emotional` | `envelope` | 0° | `#CFFAFE` Soft cyan | 无 | — | A difficult result is information about your current method, not a permanent statement about your ability. |
| 40 | Assessment, Wellbeing & Direction | `10` | ms | 匿名 | `demo_kmpk_040` | `academic` | `polaroid` | -1° | `#FDE68A` Golden yellow | `kmpk-sains-active-recall-plan-01.webp` | `contain` / 1.02 | Pada minggu peperiksaan, seimbangkan latihan aktif, semakan ringan dan tidur. Keletihan menambah kesilapan yang sebenarnya boleh dielakkan. |
| 41 | Assessment, Wellbeing & Direction | `11` | en | Jannah O. | `demo_kmpk_041` | `emotional` | `torn` | 2° | `#BBF7D0` Soft green | 无 | — | When considering future study, notice which scientific questions remain interesting after the test pressure has passed. |
| 42 | Assessment, Wellbeing & Direction | `12` | ms | 匿名 | `demo_kmpk_042` | `campus_life` | `rounded` | -2° | `#BFDBFE` Soft blue | 无 | — | Format peperiksaan, modul dan peraturan rasmi perlu disemak melalui kolej atau pensyarah. Catatan komuniti hanyalah pengalaman umum. |

## 7. Akaun（majorId 11）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 4 + majorId`的community wall，不创建建筑、地图地点或batch专属墙。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmpk-akaun-source-document-analysis-01.webp` | 虚构收据或invoice样式的练习卡，标出日期、主体、金额和用途；不得使用真实企业资料。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 8 | `kmpk-akaun-journal-ledger-flow-01.webp` | 从journal到ledger再到balance的通用流程working，所有数字均为虚构。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 15 | `kmpk-akaun-adjustment-timeline-01.webp` | 用于accrual与prepayment练习的时间线和通用金额。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 22 | `kmpk-akaun-business-case-grid-01.webp` | 写有facts、assumptions、causes和recommendations四栏的商业案例分析纸。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 24 | `kmpk-akaun-rate-base-check-01.webp` | rate、base value、period与interpretation检查卡，使用虚构数据。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 29 | `kmpk-akaun-tutorial-full-working-01.webp` | 完整通用working及第一处不确定交易标记；不使用正式测验题。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 33 | `kmpk-akaun-spreadsheet-backup-01.webp` | 共享表格命名、受保护公式和clean backup的示意摆拍；屏幕不显示真实账号。 | 需拍摄／用户自有摆拍 | `cover` | 1.06 |
| 40 | `kmpk-akaun-reconciliation-checklist-01.webp` | 不平衡时使用的逐步核对清单、短休息提示和重新检查标记。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |

### 42条完整视觉字段

| No. | 分区 | Batch ID | 语言 | 显示 | Author ID | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Documents & Transaction Analysis | `10` | ms | Gokul E. | `demo_kmpk_031` | `academic` | `envelope` | 2° | `#CBD5E1` Grey blue | `kmpk-akaun-source-document-analysis-01.webp` | `contain` / 1.00 | Sebelum membuat catatan, kenal pasti dokumen sumber, tarikh, pihak terlibat dan tujuan transaksi. Maklumat ini menentukan rawatan perakaunan. |
| 2 | Documents & Transaction Analysis | `11` | ms | Gwen F. | `demo_kmpk_032` | `academic` | `torn` | 0° | `#CFFAFE` Soft cyan | 无 | — | Terangkan kesan transaksi terhadap perniagaan sebelum memilih debit dan kredit. Hafalan arah sahaja mudah gagal apabila situasi berubah. |
| 3 | Documents & Transaction Analysis | `12` | en | 匿名 | `demo_kmpk_033` | `academic` | `circle` | -1° | `#FEF08A` Soft yellow | 无 | — | Separate the business event from the accounting entry. Understanding what happened makes account selection more reliable. |
| 4 | Documents & Transaction Analysis | `10` | zh | Hannah Mae H. | `demo_kmpk_034` | `academic` | `rounded` | 2° | `#FED7AA` Soft orange | 无 | — | 判断账户时先确定类别，再看增加或减少。不要把借方和贷方当成固定的“好”或“坏”。 |
| 5 | Documents & Transaction Analysis | `11` | ms | 匿名 | `demo_kmpk_035` | `academic` | `polaroid` | -2° | `#FFF7ED` Warm cream | 无 | — | Gunakan persamaan perakaunan sebagai semakan logik selepas setiap transaksi. Kesan keseluruhan perlu masih boleh diterangkan. |
| 6 | Documents & Transaction Analysis | `12` | en | Harveen J. | `demo_kmpk_036` | `academic` | `square` | 1° | `#BFDBFE` Soft blue | 无 | — | Write a concise narration or explanation beside unfamiliar entries. It helps you review the reasoning instead of only the numbers. |
| 7 | Documents & Transaction Analysis | `10` | ms | 匿名 | `demo_kmpk_037` | `campus_life` | `ticket` | 0° | `#E9D5FF` Soft purple | 无 | — | Simpan salinan latihan dan dokumen contoh mengikut topik. Jangan campurkan bahan rasmi dengan fail kumpulan yang belum disahkan. |
| 8 | Journal, Ledger & Reconciliation | `11` | ms | Imaan L. | `demo_kmpk_038` | `academic` | `speech` | -1° | `#CBD5E1` Grey blue | `kmpk-akaun-journal-ledger-flow-01.webp` | `contain` / 1.02 | Gunakan tarikh, rujukan dan nama akaun secara konsisten ketika memindahkan catatan daripada jurnal ke lejar. |
| 9 | Journal, Ledger & Reconciliation | `12` | ms | 匿名 | `demo_kmpk_039` | `academic` | `rect` | 2° | `#CFFAFE` Soft cyan | 无 | — | Jika baki tidak sama, cari punca secara sistematik: semak jumlah, pemindahan, tanda dan transaksi yang mungkin tertinggal. |
| 10 | Journal, Ledger & Reconciliation | `10` | en | Ishaaq N. | `demo_kmpk_040` | `academic` | `hexagon` | -2° | `#FDE68A` Golden yellow | 无 | — | A balanced trial balance is only one check. Classification errors and omitted entries may still remain. |
| 11 | Journal, Ledger & Reconciliation | `11` | zh | 匿名 | `demo_kmpk_041` | `academic` | `envelope` | 1° | `#BBF7D0` Soft green | 无 | — | 对账时把期初、期间变动和期末余额连接起来。数字之间的关系比单独检查一个总数更有效。 |
| 12 | Journal, Ledger & Reconciliation | `12` | ms | Jaren P. | `demo_kmpk_042` | `academic` | `rounded` | 0° | `#FBCFE8` Soft pink | 无 | — | Jangan masukkan angka pelaras hanya untuk memaksa imbangan sama. Tunjukkan kesan asal dan pembetulan yang sebenar. |
| 13 | Journal, Ledger & Reconciliation | `10` | en | 匿名 | `demo_kmpk_043` | `academic` | `torn` | -1° | `#FED7AA` Soft orange | 无 | — | Trace an error back to the earliest incorrect entry. Fixing only the final balance can leave the underlying problem unchanged. |
| 14 | Journal, Ledger & Reconciliation | `11` | ms | Jia Ning R. | `demo_kmpk_044` | `academic` | `polaroid` | 2° | `#FFF7ED` Warm cream | 无 | — | Selepas posting, semak beberapa transaksi dari awal hingga akhir. Ujian sampel membantu mengesan pola kesilapan berulang. |
| 15 | Adjustments & Financial Statements | `12` | ms | Kamilia S. | `demo_kmpk_045` | `academic` | `circle` | -2° | `#BFDBFE` Soft blue | `kmpk-akaun-adjustment-timeline-01.webp` | `contain` / 1.00 | Untuk pelarasan, tentukan tempoh yang terlibat dan sebab ekonomi sebelum memilih akaun. |
| 16 | Adjustments & Financial Statements | `10` | ms | 匿名 | `demo_kmpk_046` | `academic` | `square` | 1° | `#E9D5FF` Soft purple | 无 | — | Gunakan garis masa untuk membezakan jumlah yang dibayar, digunakan dan masih berkaitan dengan tempoh akan datang. |
| 17 | Adjustments & Financial Statements | `11` | en | Khairul U. | `demo_kmpk_047` | `academic` | `ticket` | 0° | `#CBD5E1` Grey blue | 无 | — | Track how one adjustment affects more than one statement. Related figures should remain consistent across the final accounts. |
| 18 | Adjustments & Financial Statements | `12` | zh | 匿名 | `demo_kmpk_048` | `academic` | `rect` | -1° | `#CFFAFE` Soft cyan | 无 | — | 制作财务报表时保持标题、小计和分类一致。清楚的结构能让错误更容易被发现。 |
| 19 | Adjustments & Financial Statements | `10` | ms | Lailatul W. | `demo_kmpk_049` | `academic` | `speech` | 2° | `#FDE68A` Golden yellow | 无 | — | Catat andaian dan maklumat tambahan yang digunakan. Penyata yang kelihatan kemas masih perlu mempunyai asas yang boleh disemak. |
| 20 | Adjustments & Financial Statements | `11` | en | 匿名 | `demo_kmpk_050` | `academic` | `rounded` | -2° | `#BBF7D0` Soft green | 无 | — | After calculating a figure, write one sentence explaining what it represents. Interpretation prevents the task from becoming pure formatting. |
| 21 | Adjustments & Financial Statements | `12` | ms | Leonard Y. | `demo_kmpk_051` | `academic` | `hexagon` | 1° | `#BFDBFE` Soft blue | 无 | — | Semak hubungan antara keuntungan, modal dan kedudukan kewangan. Angka yang berkaitan perlu menceritakan kisah yang sama. |
| 22 | Economics, Business & Quantitative Links | `10` | ms | 匿名 | `demo_kmpk_052` | `academic` | `envelope` | 0° | `#BFDBFE` Soft blue | `kmpk-akaun-business-case-grid-01.webp` | `contain` / 1.00 | Dalam graf ekonomi, tulis label paksi, lengkung dan arah perubahan sebelum membuat huraian. |
| 23 | Economics, Business & Quantitative Links | `11` | ms | Maisarah Nur A. | `demo_kmpk_053` | `academic` | `polaroid` | -1° | `#FEF08A` Soft yellow | 无 | — | Untuk kajian kes perniagaan, asingkan fakta, andaian, punca dan cadangan. Jangan menulis andaian sebagai bukti yang sudah disahkan. |
| 24 | Economics, Business & Quantitative Links | `12` | en | 匿名 | `demo_kmpk_054` | `academic` | `torn` | 2° | `#BBF7D0` Soft green | `kmpk-akaun-rate-base-check-01.webp` | `contain` / 1.00 | Check the base value, percentage and time period before interpreting a rate. A correct calculation can still answer the wrong question. |
| 25 | Economics, Business & Quantitative Links | `10` | zh | Mikayla C. | `demo_kmpk_055` | `academic` | `circle` | -2° | `#FBCFE8` Soft pink | 无 | — | 解释比率时要考虑行业、期间和比较基础。数字上升不一定自动代表表现改善。 |
| 26 | Economics, Business & Quantitative Links | `11` | ms | 匿名 | `demo_kmpk_056` | `academic` | `square` | 1° | `#FED7AA` Soft orange | 无 | — | Hubungkan maklumat perakaunan dengan keputusan yang mungkin dibuat, tetapi nyatakan juga perkara yang tidak dapat dibuktikan oleh data tersebut. |
| 27 | Economics, Business & Quantitative Links | `12` | en | Nadhirah E. | `demo_kmpk_057` | `academic` | `rounded` | 0° | `#FFF7ED` Warm cream | 无 | — | Use consistent units and rounding rules in quantitative work. Small presentation differences can create large reconciliation problems. |
| 28 | Economics, Business & Quantitative Links | `10` | ms | 匿名 | `demo_kmpk_058` | `campus_life` | `ticket` | -1° | `#E9D5FF` Soft purple | 无 | — | Untuk tugasan kumpulan, setujui satu templat dan satu sumber data. Fail yang bercampur mudah menghasilkan nombor yang tidak konsisten. |
| 29 | Tutorial, Spreadsheet & Team Systems | `11` | ms | Natasha G. | `demo_kmpk_059` | `academic` | `rect` | 2° | `#CBD5E1` Grey blue | `kmpk-akaun-tutorial-full-working-01.webp` | `contain` / 1.02 | Bawa working penuh ke tutorial dan tandakan transaksi pertama yang tidak pasti. Pensyarah boleh menilai proses, bukan hanya jawapan akhir. |
| 30 | Tutorial, Spreadsheet & Team Systems | `12` | ms | 匿名 | `demo_kmpk_060` | `academic` | `speech` | -2° | `#CFFAFE` Soft cyan | 无 | — | Dalam kumpulan, minta setiap ahli menerangkan satu pelarasan atau satu kesilapan. Menerangkan sebab lebih berguna daripada menyalin format. |
| 31 | Tutorial, Spreadsheet & Team Systems | `10` | en | Nisha I. | `demo_kmpk_061` | `academic` | `hexagon` | 1° | `#FDE68A` Golden yellow | 无 | — | Maintain an error log for classification, posting, adjustment and statement presentation. Review the pattern before the next set. |
| 32 | Tutorial, Spreadsheet & Team Systems | `11` | zh | 匿名 | `demo_kmpk_062` | `academic` | `envelope` | 0° | `#BFDBFE` Soft blue | 无 | — | 使用共享表格时统一名称和格式，并保护重要公式。保留一个干净备份，避免误改后无法恢复。 |
| 33 | Tutorial, Spreadsheet & Team Systems | `12` | ms | Orked K. | `demo_kmpk_063` | `academic` | `polaroid` | -1° | `#E9D5FF` Soft purple | `kmpk-akaun-spreadsheet-backup-01.webp` | `cover` / 1.06 | Selepas memahami kaedah, bina kelajuan melalui latihan bermasa yang pendek. Jangan mengorbankan semakan asas semata-mata untuk cepat. |
| 34 | Tutorial, Spreadsheet & Team Systems | `10` | en | 匿名 | `demo_kmpk_064` | `campus_life` | `torn` | 2° | `#CBD5E1` Grey blue | 无 | — | When sharing a reference answer, include its source and date. An unverified file should not become the group's final authority. |
| 35 | Tutorial, Spreadsheet & Team Systems | `11` | ms | Qaleesya M. | `demo_kmpk_065` | `koko` | `rounded` | -2° | `#FED7AA` Soft orange | 无 | — | Aktiviti keusahawanan atau pengurusan boleh dijadikan latihan menganalisis kos dan keputusan, tetapi data sebenar perlu digunakan dengan izin. |
| 36 | Assessment, Wellbeing & Direction | `12` | ms | 匿名 | `demo_kmpk_066` | `academic` | `polaroid` | -2° | `#FFF7ED` Warm cream | 无 | — | Campurkan soalan transaksi, pelarasan dan penyata ketika mengulang kaji. Latihan yang terlalu seragam boleh memberi keyakinan palsu. |
| 37 | Assessment, Wellbeing & Direction | `10` | ms | Raihanah O. | `demo_kmpk_067` | `emotional` | `rounded` | 1° | `#CFFAFE` Soft cyan | 无 | — | Apabila imbangan tidak sama, berhenti seketika dan kembali dengan senarai semakan. Menatap angka yang sama terlalu lama jarang membantu. |
| 38 | Assessment, Wellbeing & Direction | `11` | en | Rakesh P. | `demo_kmpk_068` | `academic` | `ticket` | 0° | `#FDE68A` Golden yellow | 无 | — | Redo a difficult question without the marking guide, then explain every correction and the reason it was needed. |
| 39 | Assessment, Wellbeing & Direction | `12` | en | 匿名 | `demo_kmpk_069` | `emotional` | `square` | 2° | `#BBF7D0` Soft green | 无 | — | Accuracy grows from a repeatable checking process. One weak exercise does not decide whether you belong in accounting. |
| 40 | Assessment, Wellbeing & Direction | `10` | ms | Rifqi R. | `demo_kmpk_070` | `academic` | `hexagon` | -1° | `#FBCFE8` Soft pink | `kmpk-akaun-reconciliation-checklist-01.webp` | `contain` / 1.00 | Tidur dan rehat mempengaruhi ketepatan. Kesilapan pemindahan dan tanda mudah berlaku apabila terlalu letih. |
| 41 | Assessment, Wellbeing & Direction | `11` | en | 匿名 | `demo_kmpk_071` | `emotional` | `speech` | 1° | `#BFDBFE` Soft blue | 无 | — | When exploring future pathways, notice whether you enjoy analysing records, explaining decisions or understanding how organisations work. |
| 42 | Assessment, Wellbeing & Direction | `12` | ms | Safiyyah T. | `demo_kmpk_072` | `campus_life` | `rect` | -2° | `#E9D5FF` Soft purple | 无 | — | Format peperiksaan, kursus dan peraturan rasmi mesti dirujuk kepada kolej atau pensyarah. Pengalaman komuniti bukan pengganti arahan rasmi. |

## 8. Sains Komputer（majorId 12）

- 42条；具名23、匿名19；BM 24、English 13、中文5；照片8。
- 仅作为`orgId: 4 + majorId`的community wall，不创建建筑、地图地点或batch专属墙。

### 形状分布
- `rounded`（圆角便贴）：6条
- `square`（正方形）：4条
- `rect`（长方形）：4条
- `circle`（圆形）：3条
- `envelope`（信封）：4条
- `torn`（撕边）：4条
- `speech`（对话框）：4条
- `polaroid`（拍立得）：5条
- `ticket`（票券）：4条
- `hexagon`（六边形）：4条

### 颜色分布
- `#BFDBFE`（Soft blue）：6条
- `#FEF08A`（Soft yellow）：2条
- `#BBF7D0`（Soft green）：4条
- `#FBCFE8`（Soft pink）：3条
- `#FED7AA`（Soft orange）：4条
- `#FFF7ED`（Warm cream）：4条
- `#E9D5FF`（Soft purple）：5条
- `#CBD5E1`（Grey blue）：5条
- `#CFFAFE`（Soft cyan）：5条
- `#FDE68A`（Golden yellow）：4条

### 照片资产清单

| Note | 文件名 | 画面要求 | 来源状态 | Fit | Scale |
|---:|---|---|---|---|---:|
| 1 | `kmpk-cs-ipo-pseudocode-01.webp` | input-process-output表格、pseudocode和一个手动trace例子；不使用正式作业。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 8 | `kmpk-cs-error-debug-log-01.webp` | 通用错误信息、文件行号和单次修改记录；屏幕不显示账号、路径或私密数据。 | 需拍摄／用户自有摆拍 | `cover` | 1.06 |
| 15 | `kmpk-cs-data-structure-choice-01.webp` | 比较list、set、queue等操作需求的通用决策表，不对应特定课程答案。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 18 | `kmpk-cs-boundary-tests-01.webp` | normal、minimum、maximum、empty与duplicate五类测试案例卡。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 22 | `kmpk-cs-readme-versioning-01.webp` | README提纲、文件结构和小型版本记录的桌面或屏幕摆拍；隐藏仓库与账号。 | 需拍摄／用户自有摆拍 | `cover` | 1.05 |
| 29 | `kmpk-cs-demo-data-privacy-01.webp` | 虚构用户数据与隐私检查表，明确不使用真实姓名、学号或消息。 | 需拍摄／用户自有摆拍 | `contain` | 1.00 |
| 33 | `kmpk-cs-implemented-prototype-future-01.webp` | implemented、prototype和future三栏项目状态板，避免把未完成内容写成已实现。 | 需拍摄／用户自有摆拍 | `contain` | 1.02 |
| 40 | `kmpk-cs-blank-file-rebuild-01.webp` | 空白代码文件、流程草图和逐步重建清单；屏幕不显示真实项目秘密。 | 需拍摄／用户自有摆拍 | `cover` | 1.04 |

### 42条完整视觉字段

| No. | 分区 | Batch ID | 语言 | 显示 | Author ID | 分类 | Shape | Rotation | Color | Photo | Fit/Scale | 内容 |
|---:|---|---:|---|---|---|---|---|---:|---|---|---|---|
| 1 | Problem Decomposition & Pseudocode | `10` | ms | 匿名 | `demo_kmpk_049` | `academic` | `speech` | -1° | `#BFDBFE` Soft blue | `kmpk-cs-ipo-pseudocode-01.webp` | `contain` / 1.00 | Sebelum menulis kod, pecahkan masalah kepada input, proses, output dan kes khas. Struktur ini mengurangkan cubaan rawak. |
| 2 | Problem Decomposition & Pseudocode | `11` | ms | Lavanya X. | `demo_kmpk_050` | `academic` | `rect` | 2° | `#FEF08A` Soft yellow | 无 | — | Tulis pseudokod dengan langkah yang boleh diuji satu demi satu. Ayat seperti 'proses data' terlalu umum untuk diterjemahkan kepada program. |
| 3 | Problem Decomposition & Pseudocode | `12` | en | Leonard Y. | `demo_kmpk_051` | `academic` | `hexagon` | -2° | `#BBF7D0` Soft green | 无 | — | Create one small example by hand before coding. A concrete trace often reveals missing conditions or unclear variable meanings. |
| 4 | Problem Decomposition & Pseudocode | `10` | zh | 匿名 | `demo_kmpk_052` | `academic` | `envelope` | 1° | `#FBCFE8` Soft pink | 无 | — | 开始coding前先列出正常输入、边界情况和错误输入。只测试一个例子很容易漏掉真正的问题。 |
| 5 | Problem Decomposition & Pseudocode | `11` | ms | Maisarah Nur A. | `demo_kmpk_053` | `academic` | `rounded` | 0° | `#FED7AA` Soft orange | 无 | — | Pilih nama pemboleh ubah yang menerangkan tujuan, bukan sekadar satu huruf. Kod yang jelas lebih mudah disemak semula. |
| 6 | Problem Decomposition & Pseudocode | `12` | en | 匿名 | `demo_kmpk_054` | `academic` | `torn` | -1° | `#FFF7ED` Warm cream | 无 | — | State the expected output before running the program. Testing is weaker when the correct result is decided after seeing the screen. |
| 7 | Problem Decomposition & Pseudocode | `10` | ms | Mikayla C. | `demo_kmpk_055` | `campus_life` | `polaroid` | 2° | `#E9D5FF` Soft purple | 无 | — | Simpan soalan asal bersama nota anda. Potongan kod tanpa konteks sukar difahami apabila dibuka semula beberapa minggu kemudian. |
| 8 | Coding & Debugging | `11` | ms | Mueez D. | `demo_kmpk_056` | `academic` | `circle` | -2° | `#CBD5E1` Grey blue | `kmpk-cs-error-debug-log-01.webp` | `cover` / 1.06 | Apabila program gagal, baca mesej ralat dari baris pertama yang berkaitan dan catat fail serta nombor baris. |
| 9 | Coding & Debugging | `12` | ms | 匿名 | `demo_kmpk_057` | `academic` | `square` | 1° | `#CFFAFE` Soft cyan | 无 | — | Ubah satu perkara pada satu masa ketika debugging. Banyak perubahan serentak menjadikan punca sebenar sukar dikenal pasti. |
| 10 | Coding & Debugging | `10` | en | Naren F. | `demo_kmpk_058` | `academic` | `ticket` | 0° | `#FDE68A` Golden yellow | 无 | — | Reduce a bug to the smallest input and smallest code section that still reproduces it. |
| 11 | Coding & Debugging | `11` | zh | 匿名 | `demo_kmpk_059` | `academic` | `rect` | -1° | `#BFDBFE` Soft blue | 无 | — | 程序能运行不代表逻辑正确。用不同输入检查结果，并手动追踪关键变量的变化。 |
| 12 | Coding & Debugging | `12` | ms | Naufal H. | `demo_kmpk_060` | `academic` | `speech` | 2° | `#E9D5FF` Soft purple | 无 | — | Gunakan cetakan sementara atau debugger untuk melihat nilai sebenar. Jangan meneka keadaan program hanya daripada kod. |
| 13 | Coding & Debugging | `10` | en | 匿名 | `demo_kmpk_061` | `academic` | `rounded` | -2° | `#CBD5E1` Grey blue | 无 | — | After fixing a bug, rerun earlier tests. A local repair can accidentally break behaviour that previously worked. |
| 14 | Coding & Debugging | `11` | ms | Nurayuni J. | `demo_kmpk_062` | `emotional` | `hexagon` | 1° | `#FED7AA` Soft orange | 无 | — | Jika terlalu lama melihat ralat yang sama, berhenti seketika dan tulis apa yang sudah diketahui. Jarak pendek boleh membantu melihat andaian yang salah. |
| 15 | Data, Algorithms & Testing | `12` | ms | 匿名 | `demo_kmpk_063` | `academic` | `envelope` | 0° | `#FFF7ED` Warm cream | `kmpk-cs-data-structure-choice-01.webp` | `contain` / 1.00 | Pilih struktur data berdasarkan operasi yang diperlukan, seperti carian, susunan, kemas kini atau pengulangan. |
| 16 | Data, Algorithms & Testing | `10` | ms | Pavithran L. | `demo_kmpk_064` | `academic` | `polaroid` | -1° | `#CFFAFE` Soft cyan | 无 | — | Jejak algoritma menggunakan jadual nilai untuk beberapa langkah. Kaedah ini membantu mencari syarat berhenti atau indeks yang salah. |
| 17 | Data, Algorithms & Testing | `11` | en | Qaleesya M. | `demo_kmpk_065` | `academic` | `torn` | 2° | `#FDE68A` Golden yellow | 无 | — | Compare algorithm choices using the size and shape of the input, not only which version looks shorter. |
| 18 | Data, Algorithms & Testing | `12` | zh | 匿名 | `demo_kmpk_066` | `academic` | `circle` | -2° | `#BBF7D0` Soft green | `kmpk-cs-boundary-tests-01.webp` | `contain` / 1.00 | 测试时包括最小值、最大值、空输入和重复数据。边界情况通常比一般输入更容易暴露错误。 |
| 19 | Data, Algorithms & Testing | `10` | ms | Raihanah O. | `demo_kmpk_067` | `academic` | `square` | 1° | `#FBCFE8` Soft pink | 无 | — | Pisahkan data ujian daripada kod utama supaya kes boleh diulang dengan konsisten selepas perubahan. |
| 20 | Data, Algorithms & Testing | `11` | en | 匿名 | `demo_kmpk_068` | `academic` | `rounded` | 0° | `#BFDBFE` Soft blue | 无 | — | Give every test a purpose and an expected result. A large set of unexplained inputs is difficult to maintain. |
| 21 | Data, Algorithms & Testing | `12` | ms | Reanna Q. | `demo_kmpk_069` | `academic` | `ticket` | -1° | `#E9D5FF` Soft purple | 无 | — | Selepas ujian gagal, tentukan sama ada masalah berada pada input, algoritma, implementasi atau jangkaan output. |
| 22 | Documentation, Versioning & Collaboration | `10` | ms | Rifqi R. | `demo_kmpk_070` | `academic` | `rect` | 2° | `#CBD5E1` Grey blue | `kmpk-cs-readme-versioning-01.webp` | `cover` / 1.05 | Tulis README ringkas yang menerangkan tujuan, cara menjalankan program, input utama dan batas yang diketahui. |
| 23 | Documentation, Versioning & Collaboration | `11` | ms | 匿名 | `demo_kmpk_071` | `campus_life` | `speech` | -2° | `#CFFAFE` Soft cyan | 无 | — | Simpan versi berfungsi sebelum membuat perubahan besar. Jangan menyalin folder dengan nama 'final-final-baru' sebagai satu-satunya sistem versi. |
| 24 | Documentation, Versioning & Collaboration | `12` | en | Safiyyah T. | `demo_kmpk_072` | `academic` | `hexagon` | 1° | `#FEF08A` Soft yellow | 无 | — | Use small, descriptive commits or saved checkpoints. A clear history makes regressions easier to locate. |
| 25 | Documentation, Versioning & Collaboration | `10` | zh | 匿名 | `demo_kmpk_073` | `academic` | `envelope` | 0° | `#FED7AA` Soft orange | 无 | — | 小组coding前先统一文件结构、命名和接口。每个人都改同一个部分，最后很容易发生冲突。 |
| 26 | Documentation, Versioning & Collaboration | `11` | ms | Salsabila V. | `demo_kmpk_074` | `academic` | `polaroid` | -1° | `#FFF7ED` Warm cream | 无 | — | Semasa review kod, komen pada tingkah laku dan bukti, bukan pada individu. Cadangkan perubahan yang boleh diuji. |
| 27 | Documentation, Versioning & Collaboration | `12` | en | 匿名 | `demo_kmpk_075` | `campus_life` | `torn` | 2° | `#BFDBFE` Soft blue | 无 | — | Never paste passwords, private keys or personal data into shared code, screenshots or public repositories. |
| 28 | Documentation, Versioning & Collaboration | `10` | ms | Shaqira X. | `demo_kmpk_076` | `academic` | `rounded` | -2° | `#E9D5FF` Soft purple | 无 | — | Selepas menggabungkan kerja kumpulan, jalankan semula aliran utama. Kod yang berfungsi secara berasingan belum tentu serasi apabila digabungkan. |
| 29 | Responsible Technology & Projects | `11` | ms | 匿名 | `demo_kmpk_077` | `academic` | `polaroid` | -2° | `#CBD5E1` Grey blue | `kmpk-cs-demo-data-privacy-01.webp` | `contain` / 1.00 | Sebelum membina ciri, tulis pengguna sasaran, masalah dan cara mengukur kejayaan. Teknologi tanpa masalah yang jelas sukar dinilai. |
| 30 | Responsible Technology & Projects | `12` | ms | Sonia Z. | `demo_kmpk_078` | `campus_life` | `rounded` | 1° | `#CFFAFE` Soft cyan | 无 | — | Gunakan data contoh yang selamat untuk demonstrasi. Jangan salin nama, nombor matrik, mesej atau akaun sebenar tanpa kebenaran. |
| 31 | Responsible Technology & Projects | `10` | en | 匿名 | `demo_kmpk_079` | `academic` | `ticket` | 0° | `#FDE68A` Golden yellow | 无 | — | Design error messages that help users recover without exposing internal details or sensitive information. |
| 32 | Responsible Technology & Projects | `11` | zh | Theodore B. | `demo_kmpk_080` | `academic` | `square` | 2° | `#BBF7D0` Soft green | 无 | — | 项目展示时要区分已经实现、原型和未来计划。没有完成的功能不能当作已经可以使用。 |
| 33 | Responsible Technology & Projects | `12` | ms | 匿名 | `demo_kmpk_081` | `academic` | `hexagon` | -1° | `#FBCFE8` Soft pink | `kmpk-cs-implemented-prototype-future-01.webp` | `contain` / 1.02 | Uji aliran utama pada saiz skrin dan keadaan berbeza. Demo yang hanya berfungsi pada satu komputer mempunyai risiko tinggi. |
| 34 | Responsible Technology & Projects | `10` | en | Vaishnavi D. | `demo_kmpk_082` | `academic` | `speech` | 1° | `#FED7AA` Soft orange | 无 | — | Collect only the data needed for the task, document why it is needed, and remove it safely when the purpose ends. |
| 35 | Responsible Technology & Projects | `11` | ms | 匿名 | `demo_kmpk_083` | `koko` | `rect` | -2° | `#FFF7ED` Warm cream | 无 | — | Dalam pertandingan atau projek kumpulan, tetapkan pemilik tugas, bukti siap dan syarat berhenti supaya kerja tidak berkembang tanpa kawalan. |
| 36 | Assessment, Wellbeing & Direction | `12` | ms | Wafiq F. | `demo_kmpk_084` | `academic` | `envelope` | 2° | `#BFDBFE` Soft blue | 无 | — | Untuk ujian, berlatih menulis logik tanpa bergantung sepenuhnya pada autocomplete. Fahami dahulu sebelum mempercepat penulisan. |
| 37 | Assessment, Wellbeing & Direction | `10` | ms | 匿名 | `demo_kmpk_085` | `emotional` | `torn` | 0° | `#E9D5FF` Soft purple | 无 | — | Satu bug yang sukar tidak menentukan kebolehan anda. Pecahkan masalah, catat bukti dan minta bantuan dengan contoh yang boleh dijalankan. |
| 38 | Assessment, Wellbeing & Direction | `11` | en | Xavier H. | `demo_kmpk_086` | `academic` | `circle` | -1° | `#CBD5E1` Grey blue | 无 | — | After an assessment, rebuild one solution from a blank file and explain the purpose of each major step. |
| 39 | Assessment, Wellbeing & Direction | `12` | en | 匿名 | `demo_kmpk_087` | `emotional` | `rounded` | 2° | `#CFFAFE` Soft cyan | 无 | — | Progress in programming is often uneven. Compare your current process with your earlier process, not only with someone else's finished project. |
| 40 | Assessment, Wellbeing & Direction | `10` | ms | Yong Han J. | `demo_kmpk_088` | `academic` | `polaroid` | -2° | `#FDE68A` Golden yellow | `kmpk-cs-blank-file-rebuild-01.webp` | `cover` / 1.04 | Campurkan latihan konsep, trace code dan pembinaan program kecil. Mengulang satu jenis soalan sahaja tidak cukup. |
| 41 | Assessment, Wellbeing & Direction | `11` | en | 匿名 | `demo_kmpk_089` | `emotional` | `square` | 1° | `#BBF7D0` Soft green | 无 | — | When considering future pathways, notice whether you enjoy building systems, analysing data, designing interfaces or improving reliability. |
| 42 | Assessment, Wellbeing & Direction | `12` | ms | Zara Imani L. | `demo_kmpk_090` | `campus_life` | `ticket` | 0° | `#BFDBFE` Soft blue | 无 | — | Keperluan kursus, bahasa pengaturcaraan dan format penilaian mesti dirujuk kepada kolej atau pensyarah. Catatan komuniti hanya panduan umum. |

## 9. Codex导入契约

- 当前不要修改网站；本文件先供人工审核。
- Sains固定使用`orgId: 4`、`majorId: 10`。
- Akaun固定使用`orgId: 4`、`majorId: 11`。
- Sains Komputer固定使用`orgId: 4`、`majorId: 12`。
- 每条note使用表内batchId、authorUserId、匿名状态、category、shape、color和rotation，不得重新随机。
- 匿名便贴的authorNickname必须为null；具名便贴使用用户池displayName。
- 演示用户统一`isDemoSeed: true`、`role: user`，并保留primary major与batchId。
- 照片URL未批准前不得写入虚假Cloudinary链接、Base64占位内容或普通相对路径。
- 不得按Batch 06、07、08建立三套重复community walls。
- 不得使用真实学生名单，不得自动commit、push、创建PR或改写Git历史。

## 10. 验收与测试

- Sains、Akaun与Sains Komputer各42条，总计126条。
- 每墙具名23、匿名19；BM 24、English 13、中文5。
- 每墙8条照片、全部10种形状和全部10个颜色预设。
- 90个作者ID全部存在于演示用户池；同一墙无重复作者。
- 54个用户出现1次，36个用户在两个墙各出现1次。
- 全部126条正文无重复；显示名不与前七批重复。
- 刷新、新设备首次载入及重复执行均不产生重复数据。
- 页面不显示演示邮箱、内部用户ID、isDemoSeed或资产管理字段。
- 不把演示内容描述为真实注册、真实使用或真实学生反馈。

## 11. 风险、停止条件与回滚

- 找不到orgId或majorId、batchId不匹配、schema不兼容、种子不幂等或页面明显卡顿时停止。
- Sains Komputer内容不得把密码、个人数据或未实现功能写入公开演示数据。
- 课程模块、实验规则、编程语言、考试格式与实时学院安排不得由演示留言替代。
- 照片文件未拍摄或未批准时保持为空，不得加入假URL。
- 回滚只移除Batch 08的126条演示便贴及90个KMPK演示用户，不影响原有数据。
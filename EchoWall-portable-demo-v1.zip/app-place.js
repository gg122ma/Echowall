function getBuildingNotes(placeId) {
  return getVisibleBuildingNotes(placeId);
}

function getBuildingDescription(building) {
  return getLocalizedBuildingText(building, "description");
}

function getBuildingZoneName(building) {
  const language = I18n.getLanguage();
  return CAMPUS_ZONES[building.zoneId]?.[language] || CAMPUS_ZONES[building.zoneId]?.en || building.zoneId;
}

function buildingPolygonPoints(building) {
  const polygon = Array.isArray(building.overviewPolygon) ? building.overviewPolygon : [];
  return polygon.map(point => `${Number(point[0]).toFixed(2)},${Number(point[1]).toFixed(2)}`).join(" ");
}

function renderBuildingMiniature(building, className = "") {
  return `<svg class="building-miniature ${className}" viewBox="0 0 100 100" role="img" aria-label="Bird's-eye outline of ${escapeHtml(building.name)}">
    <defs><linearGradient id="g-${escapeHtml(building.id)}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".2"/><stop offset="1" stop-color="currentColor" stop-opacity=".06"/></linearGradient></defs>
    <polygon points="${buildingPolygonPoints(building)}" fill="url(#g-${escapeHtml(building.id)})" stroke="currentColor" stroke-width="2.2" vector-effect="non-scaling-stroke" />
  </svg>`;
}

const BUILDING_PHOTO_SRC_PATTERN = /^assets\/buildings\/B_[A-Z0-9_]+\/[a-z0-9-]+\.(?:jpe?g|png|webp)$/i;

function getBuildingPhotos(building) {
  if (!building || !Array.isArray(building.photos)) return [];
  const expectedPrefix = `assets/buildings/${building.id}/`;
  return building.photos.filter(photo => {
    const src = String(photo?.src || '').trim();
    const alt = String(photo?.alt || '').trim();
    return src.startsWith(expectedPrefix) && BUILDING_PHOTO_SRC_PATTERN.test(src) && alt;
  }).map(photo => ({
    src:String(photo.src).trim(),
    alt:String(photo.alt).trim(),
    fit:photo.fit === 'contain' ? 'contain' : 'cover',
  }));
}

function handleBuildingPhotoError(image) {
  if (!image) return;
  image.hidden = true;
  const fallback = image.parentElement?.querySelector('[data-building-photo-fallback]');
  if (fallback) fallback.hidden = false;
}

function renderPlaceCardVisual(building) {
  const cover = getBuildingPhotos(building)[0];
  if (!cover) return renderBuildingMiniature(building);
  return `<img class='place-card-cover' src='${escapeHtml(cover.src)}' alt='${escapeHtml(cover.alt)}' loading='lazy' decoding='async' onerror='handleBuildingPhotoError(this)' />
    <span class='place-card-photo-fallback' data-building-photo-fallback hidden>${renderBuildingMiniature(building)}</span>`;
}

function renderBuildingGallery(building) {
  const photos = getBuildingPhotos(building);
  if (!photos.length) return '';
  const multiple = photos.length > 1;
  const slides = photos.map((photo, index) => `<figure class='building-gallery-slide' aria-label='${index + 1} of ${photos.length}'>
    <img src='${escapeHtml(photo.src)}' alt='${escapeHtml(photo.alt)}' loading='lazy' decoding='async' onerror='handleBuildingPhotoError(this)' />
    <span class='building-gallery-fallback' data-building-photo-fallback hidden>${renderBuildingMiniature(building)}</span>
  </figure>`).join('');
  const controls = multiple ? `<div class='building-gallery-controls'>
    <button type='button' class='building-gallery-arrow' aria-label='Previous building photo' onclick='moveBuildingGallery(this,-1)' disabled>‹</button>
    <span class='building-gallery-count' aria-live='polite'><b data-building-gallery-index>1</b> / ${photos.length}</span>
    <button type='button' class='building-gallery-arrow' aria-label='Next building photo' onclick='moveBuildingGallery(this,1)'>›</button>
  </div>` : '';
  return `<section class='building-gallery${multiple ? ' has-multiple' : ''}' data-building-gallery data-photo-count='${photos.length}' aria-label='Photos of ${escapeHtml(building.name)}'>
    <div class='building-gallery-track' onscroll='syncBuildingGallery(this.parentElement)'>${slides}</div>
    ${controls}
  </section>`;
}

function syncBuildingGallery(gallery) {
  if (!gallery) return;
  const track = gallery.querySelector('.building-gallery-track');
  const count = Number(gallery.dataset.photoCount || 0);
  if (!track || count < 2) return;
  const index = Math.max(0, Math.min(count - 1, Math.round(track.scrollLeft / Math.max(track.clientWidth, 1))));
  const indicator = gallery.querySelector('[data-building-gallery-index]');
  if (indicator) indicator.textContent = String(index + 1);
  const arrows = gallery.querySelectorAll('.building-gallery-arrow');
  if (arrows[0]) arrows[0].disabled = index === 0;
  if (arrows[1]) arrows[1].disabled = index === count - 1;
}

function moveBuildingGallery(button, direction) {
  const gallery = button?.closest('[data-building-gallery]');
  const track = gallery?.querySelector('.building-gallery-track');
  const count = Number(gallery?.dataset.photoCount || 0);
  if (!track || count < 2) return;
  const current = Math.round(track.scrollLeft / Math.max(track.clientWidth, 1));
  const target = Math.max(0, Math.min(count - 1, current + Number(direction || 0)));
  track.scrollTo({ left:target * track.clientWidth, behavior:'smooth' });
}

const BUILDING_DIRECTORY_NOTE_DISPLAY_COUNTS = Object.freeze({
  B_MASJID:42,
  B_PUSTAKA:44,
  B_DEWAN_MAHAWANGSA:18,
  B_DEWAN_KULIAH:24,
  B_LANGKASUKA:17,
  B_ASTAKA:9,
  B_SERI_JERAI:16,
  B_KEDIAMAN_PENGARAH:5,
  B_BLOK_TUTORAN_MAKMAL:23,
  B_PADANG_UTAMA:14,
  B_SERAMBI:11,
  B_GARAJ_BAS:7,
});

function renderPlaceDirectory(container) {
  const orderedBuildings = CAMPUS_BUILDINGS
    .map((building, sourceIndex) => ({
      building,
      sourceIndex,
      rank:building.id === 'B_MASJID' ? 0 : (Array.isArray(building.photos) && building.photos.length ? 1 : 2),
    }))
    .sort((a, b) => a.rank - b.rank || a.sourceIndex - b.sourceIndex)
    .map(entry => entry.building);
  const cards = orderedBuildings.map((building, index) => {
    const count = BUILDING_DIRECTORY_NOTE_DISPLAY_COUNTS[building.id] ?? getBuildingNotes(building.id).length;
    return `<button class="place-card reveal-card" data-reveal style="--reveal-delay:${Math.min(index * 35, 420)}ms" onclick="navigate('#/place/${encodeURIComponent(building.id)}')">
      <div class="place-card-visual" style="--place-color:${escapeHtml({ learning:'#5f74d6','student-life':'#9b70cf',residence:'#dc5b83',sports:'#4ba874',services:'#65748d',mobility:'#8b7867' }[building.zoneId] || '#8b5e3c')}">
        ${renderPlaceCardVisual(building)}
        <span class="place-emoji">${escapeHtml(building.emoji)}</span>
      </div>
      <div class="place-card-copy"><span class="place-zone">${escapeHtml(getBuildingZoneName(building))}</span><h3>${escapeHtml(building.name)}</h3><p>${escapeHtml(getBuildingDescription(building))}</p></div>
      <span class="place-card-foot"><b>${count}</b> notes <span>${I18n.t("home.buildings.open")} →</span></span>
    </button>`;
  }).join("");

  container.innerHTML = `<div class="container places-page page-reveal">
    <button class="page-back" onclick="navigate('#/')">← ${I18n.t("nav.home")}</button>
    <header class="places-header"><p class="eyebrow">${I18n.t("places.eyebrow")}</p><h1>${I18n.t("places.title")}</h1><p>${I18n.t("places.description")}</p></header>
    <div class="place-filter-bar"><span>${CAMPUS_BUILDINGS.length} buildings</span><input id="place-search" class="form-input" type="search" placeholder="Search buildings" oninput="filterPlaceCards(event)" /></div>
    <div id="place-grid" class="place-grid">${cards}</div>
  </div>`;
}

function filterPlaceCards(event) {
  const query = String(event.target.value || "").trim().toLowerCase();
  document.querySelectorAll(".place-card").forEach(card => {
    card.hidden = query && !card.textContent.toLowerCase().includes(query);
  });
}

function renderPlaceProfile(container, placeId) {
  const building = getCampusBuilding(placeId);
  if (!building) {
    container.innerHTML = `<section class="container error-page"><h1>Building not found</h1><button class="btn btn-primary" onclick="navigate('#/places')">${I18n.t("place.back")}</button></section>`;
    return;
  }
  const description = String(getBuildingDescription(building) || '').trim();
  const visibleNoteCount = getBuildingNotes(building.id).length;
  const photos = getBuildingPhotos(building);
  const descriptionMarkup = `${description ? `<p class='place-profile-description'>${escapeHtml(description)}</p>` : ''}<p class='place-profile-note-count'><b>${visibleNoteCount}</b> notes</p>`;
  const mediaMarkup = photos.length
    ? `<div class='place-profile-media'>${renderBuildingGallery(building)}</div>`
    : `<div class="building-overview">
        <div class="building-overview-grid"></div>
        ${renderBuildingMiniature(building, "building-overview-shape")}
      </div>`;
  container.innerHTML = `<div class="container place-profile page-reveal">
    <button class="page-back" onclick="navigate('#/places')">← ${I18n.t("place.back")}</button>
    <section class="place-profile-hero">
      <div class="place-profile-copy">
        <span class="place-profile-icon">${escapeHtml(building.emoji)}</span>
        <h1>${escapeHtml(building.name)}</h1>
        ${descriptionMarkup}
        <section class="place-wall-entry"><div><h2>${escapeHtml(building.name)} Wall</h2></div><button class="btn btn-primary btn-lg btn-round" onclick="navigateToBuildingWall('${escapeHtml(building.id)}')">${I18n.t("place.enterWall")} →</button></section>
      </div>
      ${mediaMarkup}
    </section>
  </div>`;
}

function openPlaceFromMap(placeId) {
  if (!getCampusBuilding(placeId)) return false;
  location.href = `index.html#/place/${encodeURIComponent(placeId)}`;
  return true;
}

window.openPlaceFromMap = openPlaceFromMap;
